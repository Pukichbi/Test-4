package app.nupixel

import android.app.Application
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Rect
import android.net.Uri
import androidx.annotation.StringRes
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import app.nupixel.core.CanvasMath
import app.nupixel.core.Guide
import app.nupixel.core.GuideOps
import app.nupixel.core.Limits
import app.nupixel.data.AppPrefs
import app.nupixel.data.ExportFormat
import app.nupixel.data.ImageIO
import app.nupixel.data.ImportException
import app.nupixel.data.LayerEntry
import app.nupixel.data.LoadedProject
import app.nupixel.data.ProjectFormatException
import app.nupixel.data.ProjectInfo
import app.nupixel.data.ProjectManifest
import app.nupixel.data.ProjectStore
import app.nupixel.data.ProjectTooNewException
import app.nupixel.data.RecoverInfo
import app.nupixel.layers.Blend
import app.nupixel.layers.Layer
import app.nupixel.layers.LayerTree
import app.nupixel.layers.LayerType
import app.nupixel.layers.ShapeParams
import app.nupixel.layers.TextParams
import app.nupixel.render.BitmapOps
import app.nupixel.render.Compositor
import app.nupixel.render.LayerRender
import app.nupixel.render.MaskUtil
import app.nupixel.render.TextRenderer
import app.nupixel.render.TilePyramid
import app.nupixel.tools.Selection
import app.nupixel.tools.Tool
import app.nupixel.tools.ToolSettings
import androidx.compose.runtime.snapshotFlow
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.IOException
import java.util.UUID

class UiMessage(@StringRes val res: Int, val args: List<Any> = emptyList())

/** One-step undo: the layer list as it was (pixel edits keep a pixel copy of the edited layer). */
class UndoState(
    val layers: List<Layer>,
    val activeId: String,
    val guides: List<Guide>,
    val width: Int,
    val height: Int,
)

/**
 * The document open in the editor. [composite] is the flattened picture (what is shown and exported);
 * it is kept up to date incrementally. [dirty] = has changes not yet written to the .npx file.
 */
data class Session(
    val id: String,
    val name: String,
    val createdAt: Long,
    val dirty: Boolean,
    val layers: List<Layer>,
    val activeId: String,
    val composite: Bitmap,
    val guides: List<Guide> = emptyList(),
    val undo: UndoState? = null,
) {
    /** The flattened picture; used for display, export and the document size. */
    val bitmap: Bitmap get() = composite
}

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val store = ProjectStore(app)
    private val prefs = AppPrefs(app)
    private val versionName: String = try {
        app.packageManager.getPackageInfo(app.packageName, 0).versionName ?: "0"
    } catch (e: Exception) { "0" }

    var themeMode by mutableStateOf(prefs.theme); private set
    var session by mutableStateOf<Session?>(null); private set
    var projects by mutableStateOf<List<ProjectInfo>>(emptyList()); private set
    var busy by mutableStateOf(false); private set

    /** Unsaved projects found after a restart (autosave copies). Offered for restoring on the home screen. */
    var recoverable by mutableStateOf<List<RecoverInfo>>(emptyList()); private set

    /** One writer at a time per store: manual save, save as and autosave never overlap. */
    private val writeLock = Mutex()
    private var lastAutosaved: Session? = null

    // ---- Editing tools ----
    val tool = ToolSettings()
    var activeTool by mutableStateOf(Tool.VIEW)
    var selection by mutableStateOf<Selection?>(null)

    /** When true, brush / eraser / selection fills edit the active layer's mask instead of its pixels. */
    var maskEditing by mutableStateOf(false); private set

    /** Incremented whenever pixels change, so thumbnails can refresh. */
    var contentRevision by mutableIntStateOf(0); private set

    /** Set by the editor: tile cache over [Session.composite]. Invalidated on every pixel change. */
    var pyramid: TilePyramid? = null

    private val _messages = MutableSharedFlow<UiMessage>(extraBufferCapacity = 8)
    val messages = _messages.asSharedFlow()

    private fun say(@StringRes res: Int, vararg args: Any) { _messages.tryEmit(UiMessage(res, args.toList())) }
    fun showMessage(@StringRes res: Int) = say(res)
    fun reportMemoryError() = say(R.string.err_memory)

    private fun str(@StringRes res: Int, vararg args: Any): String = getApplication<Application>().getString(res, *args)
    private fun newLayerId(): String = UUID.randomUUID().toString().replace("-", "").take(8)

    fun setTheme(mode: String) { prefs.theme = mode; themeMode = mode }

    fun refreshProjects() {
        viewModelScope.launch { projects = withContext(Dispatchers.IO) { store.list() } }
    }

    /** Runs [block] on IO with the busy overlay shown; maps known failures to user messages. */
    private fun task(@StringRes failure: Int, block: suspend () -> Unit) {
        viewModelScope.launch {
            busy = true
            try {
                withContext(Dispatchers.IO) { block() }
            } catch (e: OutOfMemoryError) {
                say(R.string.err_memory)
            } catch (e: ProjectTooNewException) {
                say(R.string.err_project_new)
            } catch (e: ImportException) {
                say(R.string.err_import)
            } catch (e: ProjectFormatException) {
                say(R.string.err_open_project)
            } catch (e: IOException) {
                say(failure)
            } catch (e: SecurityException) {
                say(failure)
            } finally {
                busy = false
            }
        }
    }

    // ------------------------------------------------------------------ opening and creating documents

    private fun buildSession(id: String, name: String, createdAt: Long, dirty: Boolean, layers: List<Layer>, activeId: String, guides: List<Guide>): Session {
        val first = layers.first { it.bitmap != null }.bitmap!!
        val comp = Bitmap.createBitmap(first.width, first.height, Bitmap.Config.ARGB_8888)
        Compositor.composite(layers, comp, null)
        return Session(id, name, createdAt, dirty, layers, activeId, comp, guides, null)
    }

    private fun openSession(s: Session, onDone: () -> Unit) {
        session = s
        lastAutosaved = null
        selection = null
        maskEditing = false
        undoKey = null
        onDone()
    }

    fun createBlank(name: String, width: Int, height: Int, background: Int, onDone: () -> Unit) {
        task(R.string.err_import) {
            val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            bmp.eraseColor(background)
            val layer = Layer(newLayerId(), str(R.string.layer_background), LayerType.RASTER, bitmap = bmp)
            val s = buildSession(store.newId(), name, System.currentTimeMillis(), true, listOf(layer), layer.id, emptyList())
            withContext(Dispatchers.Main) { openSession(s, onDone) }
        }
    }

    fun importImage(uri: Uri, fallbackName: String, onDone: () -> Unit) {
        task(R.string.err_import) {
            val ctx = getApplication<Application>()
            val d = ImageIO.decode(ctx, uri, Limits.maxPixels(), Limits.MAX_SIDE)
            val name = ImageIO.displayName(ctx, uri)?.takeIf { it.isNotBlank() } ?: fallbackName
            val layer = Layer(newLayerId(), str(R.string.layer_background), LayerType.RASTER, bitmap = d.bitmap)
            val s = buildSession(store.newId(), name, System.currentTimeMillis(), true, listOf(layer), layer.id, emptyList())
            withContext(Dispatchers.Main) {
                openSession(s, onDone)
                if (d.downscaled) say(R.string.msg_downscaled, d.bitmap.width, d.bitmap.height)
            }
        }
    }

    private fun layersFromProject(p: LoadedProject): List<Layer> {
        val w = p.manifest.width
        val h = p.manifest.height
        return p.manifest.layers.map { e ->
            val type = LayerType.fromKey(e.type)
            val bmp: Bitmap? = when (type) {
                LayerType.GROUP -> null
                LayerType.RASTER -> p.images[e.file] ?: throw ProjectFormatException("Missing layer image")
                LayerType.TEXT, LayerType.SHAPE -> Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            }
            val layer = Layer(
                id = e.id, name = e.name, type = type, visible = e.visible, locked = e.locked,
                opacity = e.opacity, blend = Blend.fromKey(e.blend), bitmap = bmp,
                mask = e.maskFile?.let { p.images[it] }, maskEnabled = e.maskEnabled,
                parentId = e.parentId, expanded = e.expanded, text = e.text, shape = e.shape,
            )
            LayerRender.render(layer)
            layer
        }
    }

    private fun sessionFromProject(p: LoadedProject): Session {
        val layers = layersFromProject(p)
        val active = p.manifest.activeLayerId?.takeIf { a -> layers.any { it.id == a } }
            ?: (layers.lastOrNull { it.type != LayerType.GROUP } ?: layers.last()).id
        return buildSession(p.id, p.manifest.name, p.manifest.createdAt, false, layers, active, p.manifest.guides)
    }

    private fun sessionFor(p: LoadedProject): Session {
        val s = sessionFromProject(p)
        return if (p.migratedFrom != null) s.copy(dirty = true) else s // an upgraded project must be saved to keep the upgrade
    }

    fun openProject(id: String, onDone: () -> Unit) {
        task(R.string.err_open_project) {
            val p = store.load(id)
            val s = sessionFor(p)
            withContext(Dispatchers.Main) {
                openSession(s, onDone)
                if (p.migratedFrom != null) say(R.string.msg_project_upgraded)
            }
        }
    }

    fun importProjectFile(uri: Uri, onDone: () -> Unit) {
        task(R.string.err_open_project) {
            val ctx = getApplication<Application>()
            val input = ctx.contentResolver.openInputStream(uri) ?: throw IOException("no stream")
            val id = input.use { store.importFile(it) }
            val p = store.load(id)
            val s = sessionFor(p)
            store.writeThumbnail(id, s.composite)
            withContext(Dispatchers.Main) {
                openSession(s, onDone)
                if (p.migratedFrom != null) say(R.string.msg_project_upgraded)
            }
        }
    }

    // ------------------------------------------------------------------ autosave and recovery

    private suspend fun autosave(s: Session) {
        if (!writeLock.tryLock()) return // a save is running; the next change or tick tries again
        try {
            if (session?.id != s.id) return // the document was closed meanwhile
            withContext(Dispatchers.IO) {
                val (manifest, images) = manifestFor(s, System.currentTimeMillis())
                store.autosave(s.id, manifest, images)
            }
            lastAutosaved = s
        } catch (e: Exception) {
            // Autosave is best effort and must never disturb editing.
        } catch (e: OutOfMemoryError) {
            // Same: skip this round.
        } finally {
            writeLock.unlock()
        }
    }

    /** Called when the app goes to the background: write the recovery copy right away. */
    fun flushAutosave() {
        val s = session ?: return
        if (!s.dirty || s === lastAutosaved) return
        viewModelScope.launch { autosave(s) }
    }

    @OptIn(FlowPreview::class)
    private fun startAutosave() {
        // After 6 s without document changes ...
        viewModelScope.launch {
            snapshotFlow { session }.debounce(6000).collect { s -> if (s != null && s.dirty) autosave(s) }
        }
        // ... and at least every 30 s while changes keep coming.
        viewModelScope.launch {
            while (true) {
                delay(30000)
                val s = session
                if (s != null && s.dirty && s !== lastAutosaved) autosave(s)
            }
        }
    }

    fun restoreRecovery(id: String, onDone: () -> Unit) {
        task(R.string.err_open_project) {
            val p = store.loadRecovery(id)
            val s = sessionFromProject(p).copy(dirty = true)
            withContext(Dispatchers.Main) {
                openSession(s, onDone)
                recoverable = recoverable.filter { it.id != id }
                say(R.string.msg_recovered)
            }
        }
    }

    fun discardRecovery(id: String) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { writeLock.withLock { store.deleteRecovery(id) } }
            recoverable = recoverable.filter { it.id != id }
        }
    }

    // ------------------------------------------------------------------ saving and exporting

    private fun manifestFor(s: Session, now: Long): Pair<ProjectManifest, Map<String, Bitmap>> {
        val images = LinkedHashMap<String, Bitmap>()
        val entries = s.layers.map { l ->
            val file = if (l.type == LayerType.RASTER) "layers/${l.id}.png" else null
            if (file != null) images[file] = l.bitmap!!
            val maskFile = if (l.mask != null) "layers/${l.id}-mask.png" else null
            if (maskFile != null) images[maskFile] = l.mask!!
            LayerEntry(
                id = l.id, name = l.name, type = l.type.key, file = file, visible = l.visible, locked = l.locked,
                opacity = l.opacity, blend = l.blend.key, maskFile = maskFile, maskEnabled = l.maskEnabled,
                parentId = l.parentId, expanded = l.expanded, text = l.text, shape = l.shape,
            )
        }
        val m = ProjectManifest(
            appVersion = versionName, name = s.name, width = s.composite.width, height = s.composite.height,
            createdAt = s.createdAt, modifiedAt = now, layers = entries, guides = s.guides, activeLayerId = s.activeId,
        )
        return Pair(m, images)
    }

    fun saveSession(onResult: (Boolean) -> Unit = {}) {
        val s = session ?: return onResult(false)
        doSave(s, onResult)
    }

    /** Saves the open document as a new project with [newName]; the previous project file stays as it was. */
    fun saveSessionAs(newName: String, onResult: (Boolean) -> Unit = {}) {
        val s = session ?: return onResult(false)
        val name = newName.trim().ifEmpty { s.name }.take(60)
        doSave(s.copy(id = store.newId(), name = name), onResult)
    }

    private fun doSave(s: Session, onResult: (Boolean) -> Unit) {
        val oldId = session?.id
        viewModelScope.launch {
            busy = true
            val ok = try {
                writeLock.withLock {
                    withContext(Dispatchers.IO) {
                        val (manifest, images) = manifestFor(s, System.currentTimeMillis())
                        store.save(s.id, manifest, images, s.composite)
                    }
                }
                true
            } catch (e: OutOfMemoryError) {
                false
            } catch (e: Exception) {
                false
            } finally {
                busy = false
            }
            if (ok) {
                val cur = session
                session = cur?.takeIf { it.layers === s.layers && it.guides == s.guides }?.copy(id = s.id, name = s.name, dirty = false)
                    ?: cur?.copy(id = s.id, name = s.name)
                withContext(Dispatchers.IO) {
                    writeLock.withLock {
                        store.deleteRecovery(s.id)
                        if (oldId != null && oldId != s.id) store.deleteRecovery(oldId)
                    }
                }
                say(R.string.msg_saved)
            } else say(R.string.err_save)
            onResult(ok)
        }
    }

    /** Leaves the editor. The recovery copy is dropped: leaving is a deliberate decision (saved or discarded). */
    fun closeSession() {
        val id = session?.id
        session = null
        selection = null
        maskEditing = false
        activeTool = Tool.VIEW
        pyramid = null
        lastAutosaved = null
        if (id != null) {
            viewModelScope.launch(Dispatchers.IO) { writeLock.withLock { store.deleteRecovery(id) } }
        }
    }

    fun exportImage(uri: Uri, format: ExportFormat, quality: Int, scale: Float) {
        val s = session ?: return
        task(R.string.err_export) {
            Compositor.composite(s.layers, s.composite, null)
            val ctx = getApplication<Application>()
            val out = ctx.contentResolver.openOutputStream(uri) ?: throw IOException("no stream")
            out.use { ImageIO.export(s.composite, format, quality, scale, it) }
            say(R.string.msg_exported)
        }
    }

    fun exportProjectFile(id: String, uri: Uri) {
        task(R.string.err_export) {
            val ctx = getApplication<Application>()
            val out = ctx.contentResolver.openOutputStream(uri) ?: throw IOException("no stream")
            out.use { store.copyTo(id, it) }
            say(R.string.msg_project_exported)
        }
    }

    fun deleteProject(id: String) {
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) { store.delete(id) }
            if (ok) say(R.string.msg_deleted) else say(R.string.err_delete)
            projects = withContext(Dispatchers.IO) { store.list() }
        }
    }

    // ------------------------------------------------------------------ editing plumbing

    val activeLayer: Layer?
        get() {
            val s = session ?: return null
            return s.layers.firstOrNull { it.id == s.activeId }
        }

    /** Recomposes [region] (everything when null) of the flattened picture and redraws the canvas tiles. */
    fun refresh(region: Rect?) {
        val s = session ?: return
        Compositor.composite(s.layers, s.composite, region)
        pyramid?.invalidate(region)
        contentRevision++
    }

    /**
     * Bitmap a paint-type tool edits, or null (with a message) when it cannot: no layer, hidden, locked,
     * not a raster layer, or mask editing requested but the layer has no mask.
     */
    fun paintTarget(allowMask: Boolean): Bitmap? {
        val l = activeLayer ?: return null
        if (l.locked) { say(R.string.err_layer_locked); return null }
        if (!l.visible) { say(R.string.err_layer_hidden); return null }
        if (maskEditing) {
            if (!allowMask) { say(R.string.err_tool_mask); return null }
            val m = l.mask
            if (m == null) { say(R.string.err_no_mask); return null }
            return m
        }
        if (l.type != LayerType.RASTER) { say(R.string.err_layer_type); return null }
        return l.bitmap
    }

    /** Full copy of the bitmap a tool is about to change: baseline for strokes and the undo snapshot. */
    fun beginEdit(): Bitmap? {
        val target = paintTarget(true) ?: return null
        return try {
            target.copy(target.config ?: Bitmap.Config.ARGB_8888, true)
        } catch (e: OutOfMemoryError) {
            say(R.string.err_memory)
            null
        }
    }

    /** Records [snapshot] (the pixels before the edit) as the undo step for the active layer or its mask. */
    fun commitEdit(snapshot: Bitmap) {
        val s = session ?: return
        val id = s.activeId
        val onMask = maskEditing
        val undoLayers = s.layers.map {
            if (it.id != id) it else if (onMask) it.copy(mask = snapshot) else it.copy(bitmap = snapshot)
        }
        undoKey = null
        session = s.copy(dirty = true, undo = UndoState(undoLayers, s.activeId, s.guides, s.composite.width, s.composite.height))
    }

    /** Copies [snapshot] back into the active target (cancel of an edit in progress). */
    fun restoreFrom(snapshot: Bitmap) {
        val target = paintTarget(true) ?: return
        Canvas(target).drawBitmap(snapshot, 0f, 0f, Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC) })
    }

    /** Runs a whole-bitmap pixel operation off the main thread; [onDirty] gets the changed rectangle on the main thread. */
    fun editPixels(op: (Bitmap, Selection?) -> Rect?, onDirty: (Rect?) -> Unit) {
        val target = paintTarget(false) ?: return
        val sel = selection
        viewModelScope.launch {
            busy = true
            try {
                val result = withContext(Dispatchers.Default) {
                    val snap = target.copy(Bitmap.Config.ARGB_8888, true)
                    val r = op(target, sel)
                    if (r == null) { snap.recycle(); null } else Pair(snap, r)
                }
                if (result != null) {
                    commitEdit(result.first)
                    refresh(result.second)
                    onDirty(result.second)
                }
            } catch (e: OutOfMemoryError) {
                say(R.string.err_memory)
            } finally {
                busy = false
            }
        }
    }

    // ------------------------------------------------------------------ structural edits (layers)

    /** Edits that share one undo step while the same [undoKey] keeps coming (sliders, drags). */
    private var undoKey: String? = null

    fun endLiveEdit() { undoKey = null }

    private fun edit(key: String? = null, redraw: Boolean = true, region: Rect? = null, f: (Session) -> Session?) {
        val s = session ?: return
        val ns = f(s) ?: return
        val push = key == null || key != undoKey
        undoKey = key
        val undo = if (push) UndoState(s.layers, s.activeId, s.guides, s.composite.width, s.composite.height) else s.undo
        session = ns.copy(dirty = true, undo = undo)
        if (redraw) refresh(region)
    }

    private fun Session.replace(id: String, change: (Layer) -> Layer): Session =
        copy(layers = layers.map { if (it.id == id) change(it) else it })

    private fun bytesPerPixel(s: Session): Long =
        s.layers.sumOf { (if (it.bitmap != null) 4L else 0L) + (if (it.mask != null) 1L else 0L) } + 12L // + composite, undo copy, stroke layer

    private fun canAfford(s: Session, extraBytesPerPixel: Long): Boolean =
        Limits.fitsBytes(s.composite.width, s.composite.height, bytesPerPixel(s) + extraBytesPerPixel)

    fun selectLayer(id: String) {
        val s = session ?: return
        if (s.layers.none { it.id == id } || s.activeId == id) return
        maskEditing = false
        undoKey = null
        session = s.copy(activeId = id)
    }

    fun editMask(on: Boolean) {
        if (on && activeLayer?.mask == null) { say(R.string.err_no_mask); return }
        maskEditing = on
    }

    private fun parentFor(s: Session): String? = s.layers.firstOrNull { it.id == s.activeId }?.parentId

    private fun insertAboveActive(s: Session, layer: Layer): Session {
        val i = LayerTree.indexOf(s.layers, s.activeId)
        val list = s.layers.toMutableList()
        list.add(if (i < 0) list.size else i + 1, layer)
        return s.copy(layers = list, activeId = layer.id)
    }

    private fun nextNumber(s: Session): Int = s.layers.count { it.type != LayerType.GROUP } + 1

    private fun newBitmap(w: Int, h: Int): Bitmap? = try {
        Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    } catch (e: OutOfMemoryError) {
        say(R.string.err_memory)
        null
    }

    fun addLayer() {
        val s = session ?: return
        if (!canAfford(s, 4)) { say(R.string.err_layer_limit); return }
        val bmp = newBitmap(s.composite.width, s.composite.height) ?: return
        val layer = Layer(newLayerId(), str(R.string.layer_default_name, nextNumber(s)), LayerType.RASTER, bitmap = bmp, parentId = parentFor(s))
        maskEditing = false
        edit(redraw = false) { insertAboveActive(it, layer) }
    }

    fun duplicateLayer(id: String) {
        val s = session ?: return
        val l = s.layers.firstOrNull { it.id == id } ?: return
        if (l.type == LayerType.GROUP) { say(R.string.err_group_dup); return }
        if (!canAfford(s, 4L + (if (l.mask != null) 1L else 0L))) { say(R.string.err_layer_limit); return }
        val copy = try {
            l.copy(
                id = newLayerId(), name = l.name + str(R.string.layer_copy_suffix),
                bitmap = l.bitmap?.copy(Bitmap.Config.ARGB_8888, true), mask = l.mask?.let { MaskUtil.copy(it) },
            )
        } catch (e: OutOfMemoryError) {
            say(R.string.err_memory)
            return
        }
        maskEditing = false
        edit(region = null) { st ->
            val list = st.layers.toMutableList()
            list.add(LayerTree.indexOf(st.layers, id) + 1, copy)
            st.copy(layers = list, activeId = copy.id)
        }
    }

    fun deleteLayer(id: String) {
        val s = session ?: return
        val remaining = LayerTree.remove(s.layers, id)
        if (remaining.none { it.type != LayerType.GROUP }) { say(R.string.err_last_layer); return }
        val next = LayerTree.nextActive(s.layers, id, remaining) ?: return
        maskEditing = false
        edit { it.copy(layers = remaining, activeId = if (remaining.any { l -> l.id == s.activeId }) s.activeId else next) }
    }

    fun renameLayer(id: String, name: String) = edit(key = "name:$id", redraw = false) { s -> s.replace(id) { it.copy(name = name) } }

    fun setVisible(id: String, v: Boolean) = edit { s -> s.replace(id) { it.copy(visible = v) } }

    fun setLocked(id: String, v: Boolean) = edit(redraw = false) { s -> s.replace(id) { it.copy(locked = v) } }

    fun setExpanded(id: String, v: Boolean) {
        val s = session ?: return
        session = s.replace(id) { it.copy(expanded = v) }
    }

    fun setOpacity(id: String, v: Float) = edit(key = "opacity:$id") { s -> s.replace(id) { it.copy(opacity = v.coerceIn(0f, 1f)) } }

    fun setBlend(id: String, b: Blend) = edit { s -> s.replace(id) { it.copy(blend = b) } }

    fun moveLayer(id: String, up: Boolean) = edit { s ->
        LayerTree.move(s.layers, id, up)?.let { s.copy(layers = it) }
    }

    fun groupLayer(id: String) {
        val s = session ?: return
        val l = s.layers.firstOrNull { it.id == id } ?: return
        if (l.type == LayerType.GROUP || l.parentId != null) { say(R.string.err_nested_group); return }
        val group = Layer(newLayerId(), str(R.string.layer_group), LayerType.GROUP)
        edit { st -> LayerTree.group(st.layers, id, group)?.let { st.copy(layers = it) } }
    }

    fun ungroup(groupId: String) = edit { s ->
        val g = s.layers.firstOrNull { it.id == groupId } ?: return@edit null
        if (g.type != LayerType.GROUP) return@edit null
        val list = LayerTree.ungroup(s.layers, groupId)
        val active = if (s.activeId == groupId) list.lastOrNull { it.type != LayerType.GROUP }?.id ?: s.activeId else s.activeId
        s.copy(layers = list, activeId = active)
    }

    fun addToGroup(id: String, groupId: String) = edit { s -> LayerTree.addToGroup(s.layers, id, groupId)?.let { s.copy(layers = it) } }

    fun removeFromGroup(id: String) = edit { s -> LayerTree.removeFromGroup(s.layers, id)?.let { s.copy(layers = it) } }

    fun mergeDown(id: String) {
        val s = session ?: return
        val i = LayerTree.indexOf(s.layers, id)
        val upper = s.layers.getOrNull(i) ?: return
        val lowerIdx = s.layers.indices.lastOrNull { it < i && s.layers[it].parentId == upper.parentId }
        val lower = lowerIdx?.let { s.layers[it] }
        if (upper.type != LayerType.RASTER || lower == null || lower.type != LayerType.RASTER || upper.mask != null || lower.mask != null) {
            say(R.string.err_merge)
            return
        }
        if (lower.locked) { say(R.string.err_layer_locked); return }
        val snapshot = try {
            lower.bitmap!!.copy(Bitmap.Config.ARGB_8888, true)
        } catch (e: OutOfMemoryError) {
            say(R.string.err_memory)
            return
        }
        val undoLayers = s.layers.map { if (it.id == lower.id) it.copy(bitmap = snapshot) else it }
        Compositor.mergeInto(lower.bitmap!!, upper)
        maskEditing = false
        undoKey = null
        session = s.copy(
            layers = s.layers.filter { it.id != id }, activeId = lower.id, dirty = true,
            undo = UndoState(undoLayers, s.activeId, s.guides, s.composite.width, s.composite.height),
        )
        refresh(null)
    }

    fun addMask(id: String) {
        val s = session ?: return
        val l = s.layers.firstOrNull { it.id == id } ?: return
        if (l.type == LayerType.GROUP || l.mask != null) return
        if (!canAfford(s, 1)) { say(R.string.err_layer_limit); return }
        val mask = try {
            MaskUtil.newMask(s.composite.width, s.composite.height, visible = true)
        } catch (e: OutOfMemoryError) {
            say(R.string.err_memory)
            return
        }
        edit(redraw = false) { st -> st.replace(id) { it.copy(mask = mask, maskEnabled = true) } }
        maskEditing = true
    }

    fun removeMask(id: String) {
        maskEditing = false
        edit { s -> s.replace(id) { it.copy(mask = null) } }
    }

    fun setMaskEnabled(id: String, v: Boolean) = edit { s -> s.replace(id) { it.copy(maskEnabled = v) } }

    fun rasterize(id: String) = edit(redraw = false) { s ->
        val l = s.layers.firstOrNull { it.id == id } ?: return@edit null
        if (l.type != LayerType.TEXT && l.type != LayerType.SHAPE) return@edit null
        s.replace(id) { it.copy(type = LayerType.RASTER, text = null, shape = null) }
    }

    // ------------------------------------------------------------------ text and shape layers

    fun addTextLayer(p: TextParams) {
        val s = session ?: return
        if (!canAfford(s, 4)) { say(R.string.err_layer_limit); return }
        val bmp = newBitmap(s.composite.width, s.composite.height) ?: return
        val layer = Layer(newLayerId(), str(R.string.layer_text), LayerType.TEXT, bitmap = bmp, text = p, parentId = parentFor(s))
        LayerRender.render(layer)
        maskEditing = false
        edit(region = LayerRender.contentBounds(layer)) { insertAboveActive(it, layer) }
    }

    /** Changes the active text layer's parameters live; one undo step per layer until another kind of edit. */
    fun updateActiveText(change: (TextParams) -> TextParams) {
        val l = activeLayer ?: return
        if (l.type != LayerType.TEXT) return
        if (l.locked) { say(R.string.err_layer_locked); return }
        val old = l.text ?: return
        val nl = l.copy(text = change(old))
        LayerRender.render(nl)
        val region = LayerRender.contentBounds(l)?.also { r -> LayerRender.contentBounds(nl)?.let { r.union(it) } }
        edit(key = "text:${l.id}", region = region) { st -> st.replace(l.id) { nl } }
    }

    fun addShapeLayer(p: ShapeParams) {
        val s = session ?: return
        if (!canAfford(s, 4)) { say(R.string.err_layer_limit); return }
        val bmp = newBitmap(s.composite.width, s.composite.height) ?: return
        val layer = Layer(newLayerId(), str(R.string.layer_shape), LayerType.SHAPE, bitmap = bmp, shape = p, parentId = parentFor(s))
        LayerRender.render(layer)
        maskEditing = false
        edit(region = LayerRender.contentBounds(layer)) { insertAboveActive(it, layer) }
    }

    fun updateActiveShape(change: (ShapeParams) -> ShapeParams) {
        val l = activeLayer ?: return
        if (l.type != LayerType.SHAPE) return
        if (l.locked) { say(R.string.err_layer_locked); return }
        val old = l.shape ?: return
        val nl = l.copy(shape = change(old))
        LayerRender.render(nl)
        val region = LayerRender.contentBounds(l)?.also { r -> LayerRender.contentBounds(nl)?.let { r.union(it) } }
        edit(key = "shape:${l.id}", region = region) { st -> st.replace(l.id) { nl } }
    }

    /** Moves the active text or shape layer by (dx, dy) document pixels. */
    fun moveActiveLayerBy(dx: Float, dy: Float) {
        val l = activeLayer ?: return
        when (l.type) {
            LayerType.TEXT -> updateActiveText { it.shifted(dx, dy) }
            LayerType.SHAPE -> updateActiveShape { it.shifted(dx, dy) }
            else -> Unit
        }
    }

    /** Topmost visible text layer whose text covers the point, or null. */
    fun hitTextLayer(x: Float, y: Float): String? {
        val s = session ?: return null
        return s.layers.lastOrNull { l ->
            l.type == LayerType.TEXT && l.visible && isShown(s, l) && l.text?.let { TextRenderer.bounds(it).contains(x, y) } == true
        }?.id
    }

    private fun isShown(s: Session, l: Layer): Boolean {
        val parent = l.parentId?.let { pid -> s.layers.firstOrNull { it.id == pid } }
        return parent == null || parent.visible
    }

    fun deleteBlankTextLayer() {
        val l = activeLayer ?: return
        if (l.type == LayerType.TEXT && l.text?.text.isNullOrBlank()) deleteLayer(l.id)
    }

    /** Text dialog confirmed with blank text: remove the layer, or empty it if the user had text before. */
    fun deleteBlankTextLayerOrClear() {
        val id = activeLayer?.id ?: return
        deleteLayer(id)
    }

    // ------------------------------------------------------------------ undo

    fun undo() {
        val s = session ?: return
        val u = s.undo ?: return
        val comp = if (u.width == s.composite.width && u.height == s.composite.height) s.composite
        else Bitmap.createBitmap(u.width, u.height, Bitmap.Config.ARGB_8888)
        u.layers.forEach { LayerRender.render(it) } // text and shape pixels are derived from parameters
        selection = null
        maskEditing = false
        undoKey = null
        val active = if (u.layers.any { it.id == u.activeId }) u.activeId else u.layers.last().id
        session = s.copy(layers = u.layers, activeId = active, composite = comp, guides = u.guides, undo = null, dirty = true)
        refresh(null)
    }

    // ------------------------------------------------------------------ canvas operations (all layers)

    private fun maskOp(f: (Bitmap) -> Bitmap): (Bitmap) -> Bitmap = { m ->
        val a = MaskUtil.toArgb(m)
        val r = f(a)
        a.recycle()
        val out = MaskUtil.fromArgb(r)
        r.recycle()
        out
    }

    /** Applies a size/content change to every layer. Text and shape layers get transformed parameters and are redrawn. */
    private fun transformDocument(
        newW: Int,
        newH: Int,
        pixels: (Bitmap, Boolean) -> Bitmap,
        mask: (Bitmap) -> Bitmap,
        text: (TextParams) -> TextParams,
        shape: (ShapeParams) -> ShapeParams,
        guides: (Session) -> List<Guide>,
    ) {
        val s = session ?: return
        val lowestRaster = s.layers.firstOrNull { it.type == LayerType.RASTER && it.parentId == null }?.id
        task(R.string.err_memory) {
            val newLayers = s.layers.map { l ->
                val bmp: Bitmap? = when (l.type) {
                    LayerType.RASTER -> pixels(l.bitmap!!, l.id == lowestRaster)
                    LayerType.TEXT, LayerType.SHAPE -> Bitmap.createBitmap(newW, newH, Bitmap.Config.ARGB_8888)
                    LayerType.GROUP -> null
                }
                val nl = l.copy(bitmap = bmp, mask = l.mask?.let(mask), text = l.text?.let(text), shape = l.shape?.let(shape))
                LayerRender.render(nl)
                nl
            }
            val comp = Bitmap.createBitmap(newW, newH, Bitmap.Config.ARGB_8888)
            Compositor.composite(newLayers, comp, null)
            withContext(Dispatchers.Main) {
                selection = null
                maskEditing = false
                undoKey = null
                session = s.copy(
                    layers = newLayers, composite = comp, guides = guides(s), dirty = true,
                    undo = UndoState(s.layers, s.activeId, s.guides, s.composite.width, s.composite.height),
                )
            }
        }
    }

    fun cropCanvas(x: Int, y: Int, w: Int, h: Int) = transformDocument(
        w, h,
        pixels = { b, _ -> BitmapOps.crop(b, x, y, w, h) },
        mask = maskOp { BitmapOps.crop(it, x, y, w, h) },
        text = { it.shifted(-x.toFloat(), -y.toFloat()) },
        shape = { it.shifted(-x.toFloat(), -y.toFloat()) },
        guides = { GuideOps.translate(it.guides, -x, -y, w, h) },
    )

    fun resizeCanvas(w: Int, h: Int, anchorX: Int, anchorY: Int, fill: Int) {
        val s = session ?: return
        val ox = CanvasMath.anchorOffset(s.composite.width, w, anchorX)
        val oy = CanvasMath.anchorOffset(s.composite.height, h, anchorY)
        transformDocument(
            w, h,
            pixels = { b, lowest -> BitmapOps.resizeCanvas(b, w, h, anchorX, anchorY, if (lowest) fill else 0) },
            mask = maskOp { BitmapOps.resizeCanvas(it, w, h, anchorX, anchorY, 0xFFFFFFFF.toInt()) },
            text = { it.shifted(ox.toFloat(), oy.toFloat()) },
            shape = { it.shifted(ox.toFloat(), oy.toFloat()) },
            guides = { GuideOps.translate(it.guides, ox, oy, w, h) },
        )
    }

    fun resample(w: Int, h: Int) {
        val s = session ?: return
        val sx = w / s.composite.width.toFloat()
        val sy = h / s.composite.height.toFloat()
        transformDocument(
            w, h,
            pixels = { b, _ -> BitmapOps.resample(b, w, h) },
            mask = maskOp { BitmapOps.resample(it, w, h) },
            text = { it.scaled(sx, sy) },
            shape = { it.scaled(sx, sy) },
            guides = { GuideOps.scale(it.guides, sx, sy, w, h) },
        )
    }

    // ------------------------------------------------------------------ guides

    private fun updateGuides(change: (Session) -> List<Guide>) {
        val s = session ?: return
        val g = change(s)
        if (g != s.guides) session = s.copy(guides = g, dirty = true)
    }

    fun addGuide(vertical: Boolean, position: Int) = updateGuides { s ->
        val max = if (vertical) s.composite.width else s.composite.height
        val g = Guide(vertical, position.coerceIn(0, max))
        if (g in s.guides) s.guides else s.guides + g
    }

    fun addCenterGuides() = updateGuides { s ->
        (s.guides + Guide(true, s.composite.width / 2) + Guide(false, s.composite.height / 2)).distinct()
    }

    fun removeGuide(index: Int) = updateGuides { s -> s.guides.filterIndexed { i, _ -> i != index } }

    fun clearGuides() = updateGuides { emptyList() }

    init {
        viewModelScope.launch { recoverable = withContext(Dispatchers.IO) { store.listRecoverable() } }
        startAutosave()
    }
}
