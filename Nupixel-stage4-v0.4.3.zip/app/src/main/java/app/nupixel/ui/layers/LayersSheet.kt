package app.nupixel.ui.layers

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowDownward
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.CallMerge
import androidx.compose.material.icons.rounded.Category
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.CreateNewFolder
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.TextFields
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import app.nupixel.AppViewModel
import app.nupixel.R
import app.nupixel.layers.Blend
import app.nupixel.layers.Layer
import app.nupixel.layers.LayerTree
import app.nupixel.layers.LayerType
import app.nupixel.tools.ToolController
import app.nupixel.ui.components.NxChip
import app.nupixel.ui.components.NxSectionLabel
import app.nupixel.ui.components.NxSliderRow
import app.nupixel.ui.theme.LocalNx
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.roundToInt

private fun blendLabel(b: Blend): Int = when (b) {
    Blend.NORMAL -> R.string.blend_normal
    Blend.MULTIPLY -> R.string.blend_multiply
    Blend.SCREEN -> R.string.blend_screen
    Blend.OVERLAY -> R.string.blend_overlay
    Blend.DARKEN -> R.string.blend_darken
    Blend.LIGHTEN -> R.string.blend_lighten
    Blend.ADD -> R.string.blend_add
}

private fun typeLabel(t: LayerType): Int = when (t) {
    LayerType.RASTER -> R.string.layer_type_raster
    LayerType.TEXT -> R.string.layer_type_text
    LayerType.SHAPE -> R.string.layer_type_shape
    LayerType.GROUP -> R.string.layer_type_group
}

/** Layer list on top, properties of the active layer below. */
@Composable
fun LayersSheet(vm: AppViewModel, controller: ToolController, onClose: () -> Unit) {
    val s = vm.session ?: return
    val active = s.layers.firstOrNull { it.id == s.activeId }
    val revision = vm.contentRevision

    Column(
        Modifier.padding(horizontal = 16.dp).padding(bottom = 16.dp).navigationBarsPadding()
            .verticalScroll(rememberScrollState()),
    ) {
        Text(stringResource(R.string.layers_title), style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(10.dp))

        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            NxChip(stringResource(R.string.layers_add), { vm.addLayer() }, leading = { Icon(Icons.Rounded.Add, null, Modifier.size(18.dp)) })
            NxChip(
                stringResource(R.string.layers_group), { active?.let { vm.groupLayer(it.id) } },
                enabled = active != null && active.type != LayerType.GROUP && active.parentId == null,
                leading = { Icon(Icons.Rounded.CreateNewFolder, null, Modifier.size(18.dp)) },
            )
            NxChip(
                stringResource(R.string.layers_duplicate), { active?.let { vm.duplicateLayer(it.id) } },
                enabled = active != null && active.type != LayerType.GROUP,
                leading = { Icon(Icons.Rounded.ContentCopy, null, Modifier.size(18.dp)) },
            )
            NxChip(
                stringResource(R.string.layers_merge), { active?.let { vm.mergeDown(it.id) } },
                enabled = active != null && active.type == LayerType.RASTER,
                leading = { Icon(Icons.Rounded.CallMerge, null, Modifier.size(18.dp)) },
            )
            NxChip(
                stringResource(R.string.layers_delete), { active?.let { vm.deleteLayer(it.id) } },
                enabled = active != null,
                leading = { Icon(Icons.Rounded.Delete, null, Modifier.size(18.dp)) },
            )
        }

        Spacer(Modifier.height(10.dp))
        LayerTree.rows(s.layers).forEach { row ->
            LayerRow(vm, controller, row, row.layer.id == s.activeId, if (row.layer.id == s.activeId) revision else 0)
        }

        if (active != null) {
            Properties(vm, controller, s.layers, active, onClose)
        }
    }
}

@Composable
private fun LayerRow(vm: AppViewModel, controller: ToolController, row: LayerTree.Row, isActive: Boolean, revision: Int) {
    val l = row.layer
    val cs = MaterialTheme.colorScheme
    Surface(
        onClick = { controller.finishPending(); vm.selectLayer(l.id) },
        shape = MaterialTheme.shapes.small,
        color = if (isActive) cs.primary.copy(alpha = 0.16f) else Color.Transparent,
        modifier = Modifier.fillMaxWidth().padding(start = (row.depth * 22).dp, top = 2.dp, bottom = 2.dp),
    ) {
        Row(Modifier.padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { vm.setVisible(l.id, !l.visible) }, modifier = Modifier.size(40.dp)) {
                Icon(
                    if (l.visible) Icons.Rounded.Visibility else Icons.Rounded.VisibilityOff,
                    contentDescription = stringResource(if (l.visible) R.string.cd_hide_layer else R.string.cd_show_layer),
                    tint = if (l.visible) cs.onSurface else cs.onSurfaceVariant,
                )
            }
            LayerThumb(l, revision)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(l.name, style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                val extra = buildString {
                    append(stringResource(typeLabel(l.type)))
                    if (l.mask != null) append(" · ").append(stringResource(R.string.layer_mask_short))
                    if (l.opacity < 0.995f) append(" · ").append((l.opacity * 100).roundToInt()).append('%')
                }
                Text(extra, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            if (l.locked) Icon(Icons.Rounded.Lock, null, Modifier.size(18.dp), tint = cs.onSurfaceVariant)
            if (l.type == LayerType.GROUP) {
                IconButton(onClick = { vm.setExpanded(l.id, !l.expanded) }, modifier = Modifier.size(40.dp)) {
                    Icon(if (l.expanded) Icons.Rounded.ExpandMore else Icons.Rounded.ChevronRight, null)
                }
            }
        }
    }
}

@Composable
private fun LayerThumb(l: Layer, revision: Int) {
    val cs = MaterialTheme.colorScheme
    val nx = LocalNx.current
    val thumb by produceState<ImageBitmap?>(null, l.id, l.bitmap, revision) {
        val b = l.bitmap
        value = if (b == null) null else withContext(Dispatchers.Default) {
            try {
                val k = 96f / max(b.width, b.height)
                Bitmap.createScaledBitmap(b, max(1, (b.width * k).roundToInt()), max(1, (b.height * k).roundToInt()), true).asImageBitmap()
            } catch (e: OutOfMemoryError) {
                null
            }
        }
    }
    Box(
        Modifier.size(44.dp).clip(RoundedCornerShape(8.dp)).background(nx.checkerDark)
            .border(1.dp, cs.outlineVariant, RoundedCornerShape(8.dp)),
        contentAlignment = Alignment.Center,
    ) {
        val img = thumb
        if (img != null) {
            Image(img, contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
        } else {
            val icon = when (l.type) {
                LayerType.GROUP -> Icons.Rounded.Folder
                LayerType.TEXT -> Icons.Rounded.TextFields
                LayerType.SHAPE -> Icons.Rounded.Category
                LayerType.RASTER -> Icons.Rounded.Image
            }
            Icon(icon, null, tint = cs.onSurfaceVariant)
        }
    }
}

@Composable
private fun Properties(vm: AppViewModel, controller: ToolController, layers: List<Layer>, l: Layer, onClose: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    var name by remember(l.id) { mutableStateOf(l.name) }
    var blendMenu by remember { mutableStateOf(false) }
    var groupMenu by remember { mutableStateOf(false) }
    val groups = layers.filter { it.type == LayerType.GROUP }

    NxSectionLabel(stringResource(R.string.layer_properties))
    OutlinedTextField(
        value = name,
        onValueChange = { name = it.take(40); vm.renameLayer(l.id, name) },
        label = { Text(stringResource(R.string.layer_name)) },
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
    )
    NxSliderRow(stringResource(R.string.opt_opacity), l.opacity, 0f..1f, "${(l.opacity * 100).roundToInt()}%") { vm.setOpacity(l.id, it) }

    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(stringResource(R.string.layer_blend), Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
        Box {
            NxChip(stringResource(blendLabel(l.blend)), { blendMenu = true })
            DropdownMenu(expanded = blendMenu, onDismissRequest = { blendMenu = false }) {
                Blend.entries.forEach { b ->
                    DropdownMenuItem(text = { Text(stringResource(blendLabel(b))) }, onClick = { blendMenu = false; vm.setBlend(l.id, b) })
                }
            }
        }
    }

    Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        NxChip(stringResource(R.string.layer_up), { vm.moveLayer(l.id, true) }, leading = { Icon(Icons.Rounded.ArrowUpward, null, Modifier.size(18.dp)) })
        NxChip(stringResource(R.string.layer_down), { vm.moveLayer(l.id, false) }, leading = { Icon(Icons.Rounded.ArrowDownward, null, Modifier.size(18.dp)) })
        NxChip(stringResource(if (l.locked) R.string.layer_unlock else R.string.layer_lock), { vm.setLocked(l.id, !l.locked) }, primary = l.locked)
        if (l.type == LayerType.GROUP) NxChip(stringResource(R.string.layer_ungroup), { vm.ungroup(l.id) })
        if (l.parentId != null) {
            NxChip(stringResource(R.string.layer_remove_from_group), { vm.removeFromGroup(l.id) })
        } else if (l.type != LayerType.GROUP && groups.isNotEmpty()) {
            Box {
                NxChip(stringResource(R.string.layer_add_to_group), { groupMenu = true })
                DropdownMenu(expanded = groupMenu, onDismissRequest = { groupMenu = false }) {
                    groups.forEach { g ->
                        DropdownMenuItem(text = { Text(g.name) }, onClick = { groupMenu = false; vm.addToGroup(l.id, g.id) })
                    }
                }
            }
        }
        if (l.type == LayerType.TEXT || l.type == LayerType.SHAPE) NxChip(stringResource(R.string.layer_rasterize), { vm.rasterize(l.id) })
    }

    if (l.type != LayerType.GROUP) {
        NxSectionLabel(stringResource(R.string.layer_mask))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (l.mask == null) {
                NxChip(stringResource(R.string.mask_add), { vm.addMask(l.id) })
            } else {
                NxChip(stringResource(if (vm.maskEditing) R.string.mask_stop_edit else R.string.mask_edit), { vm.editMask(!vm.maskEditing) }, primary = vm.maskEditing)
                NxChip(stringResource(if (l.maskEnabled) R.string.mask_disable else R.string.mask_enable), { vm.setMaskEnabled(l.id, !l.maskEnabled) })
                NxChip(stringResource(R.string.mask_remove), { vm.removeMask(l.id) })
            }
        }
        if (l.mask != null) {
            Text(stringResource(R.string.mask_hint), style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, modifier = Modifier.padding(top = 6.dp))
        }
    }

    val sp = l.shape
    if (l.type == LayerType.SHAPE && sp != null) {
        NxSectionLabel(stringResource(R.string.layer_shape_settings))
        NxSliderRow(stringResource(R.string.opt_stroke), sp.stroke, 1f..100f, "${sp.stroke.roundToInt()}") { v -> vm.updateActiveShape { it.copy(stroke = v) } }
        if (sp.kind != "line") {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(stringResource(R.string.opt_filled), Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
                Switch(checked = sp.filled, onCheckedChange = { f -> vm.updateActiveShape { it.copy(filled = f) } })
            }
        }
        Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            NxChip(stringResource(R.string.shape_use_color), { vm.updateActiveShape { it.copy(color = vm.tool.color) } })
        }
    }

    val tp = l.text
    if (l.type == LayerType.TEXT && tp != null) {
        NxSectionLabel(stringResource(R.string.layer_text_settings))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            NxChip(stringResource(R.string.text_edit), { onClose(); controller.editingText = true })
        }
    }
    Spacer(Modifier.height(8.dp))
}
