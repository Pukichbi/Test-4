# Nupixel design system (stage 0.5)

Source of tokens: `ui/theme/Theme.kt`. Direction from `branding/ui_reference.png`.

**Colors (dark default).** Background `#0B1020`, cards `#131C33`, raised `#18233F`, outline `#26334F`, text `#E8EDF8`, secondary text `#93A1BF`. Brand: blue `#2F7BFF` (primary), cyan `#22D3EE`, violet `#8B5CF6`. States: success `#34D399`, warning `#FBBF24`, error `#FF5C7A`. Light theme has matching tokens (primary `#1F63E6`, background `#F4F6FB`).
**Type.** System sans. Display 36 bold, headline 24, title 20/16, body 16/14, caption 12, label 14/12 medium.
**Spacing.** 4 / 8 / 12 / 16 / 24 dp. Minimum touch target 48 dp; primary buttons 56 dp.
**Shape.** Radius 6 / 10 / 14 (cards, buttons) / 20 / 28 dp.
**Components.** `NxButton` (primary/secondary), `NxCard`, `NxSegmented`, `NxSectionLabel`, `NxTopBar`, `NxScreen`.
**States.** Pressed/disabled (40% alpha), selected (blue outline + tint), empty (icon + text), busy (scrim + spinner), error (snackbar).
**Motion.** Material defaults for navigation and sheets; no decorative animation yet.
**Icons.** Material Rounded set, one weight, 22–24 dp.
**Brand.** Ribbon "N" icon; adaptive icon background `#161926`, foreground centred inside the safe zone.
