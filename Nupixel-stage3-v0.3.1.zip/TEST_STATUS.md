# Test status

| Check | Command | Last result |
|-------|---------|-------------|
| Unit tests (`ViewTransformTest`, `TileGridTest`, `CanvasMathTest`, `ToolMathTest`, `ManifestCodecTest`) | `./gradlew testDebugUnitTest` | **Not run** |
| Debug build | `./gradlew assembleDebug` | **Not run** |
| On-device / emulator run | — | **Not run** |
| Screenshots / visual check | — | **Not done** |
| Launcher icon on device | — | **Not checked** |

## Stage 1 and 2 status correction
Earlier notes said stages 1 and 2 were built and accepted. The GitHub Actions history shows all runs failing (the first 7 runs), so no version has been proven to compile. Last known failure: unresolved `ProjectStore` caused by a nested-comment bug (fixed in 0.3.1).

## Unverified stage 3 scenarios
Brush/eraser strokes at several sizes and hardness · opacity not building up inside one stroke · stroke cancelled by a second finger · painting on a large (~8000 px) canvas · fill and remove-background tolerance · rectangle/lasso selection limiting every tool · move/scale/rotate then Apply/Cancel · text add/edit/move/apply · colour sheet · one-step undo after each tool · save → reopen → export of edited image.

## Unverified stage 2 scenarios
Two-finger rotate without jumps · panning/zooming an ~8000 px image · tile seams · pyramid level switch while zooming · crop / canvas size (all anchors) / resolution · one-step undo · guides persisted and reloaded · grid at several zoom levels · out-of-memory path.

## Unverified stage 1 scenarios (not re-tested)
Import image (incl. EXIF rotation, huge images) · blank canvas presets · save → close → reopen · overwrite safety · export PNG/JPEG at each size · unsaved-changes dialog · language switch and persistence · light/dark · .npx import/export · pinch/pan behaviour.

## Not covered by any test yet
`ProjectStore` (needs instrumented test), `ImageIO`, UI.

## Static review (2026-10-19, no compiler available in the authoring environment)
Scripted scan for missing imports in UI files: no real findings. This is not a compile check.
