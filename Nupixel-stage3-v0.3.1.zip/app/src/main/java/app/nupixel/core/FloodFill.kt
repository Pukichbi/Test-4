package app.nupixel.core

import java.util.BitSet
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt

/** Pixel-region search used by Fill and Remove background. Pure Kotlin (testable on the JVM). */
object FloodFill {
    private fun channelDiff(a: Int, b: Int): Int = max(
        max(abs((a ushr 24) - (b ushr 24)), abs(((a shr 16) and 0xFF) - ((b shr 16) and 0xFF))),
        max(abs(((a shr 8) and 0xFF) - ((b shr 8) and 0xFF)), abs((a and 0xFF) - (b and 0xFF))),
    )

    /**
     * Pixels (index = y * w + x) whose colour is within [tolerance] (0..255, per channel incl. alpha)
     * of the seed pixel. [contiguous] = only the connected area (4-neighbourhood). [allowed] (optional)
     * restricts the search to pixels whose byte is non-zero, e.g. a selection mask.
     */
    fun region(pixels: IntArray, w: Int, h: Int, sx: Int, sy: Int, tolerance: Int, contiguous: Boolean, allowed: ByteArray? = null): BitSet {
        val out = BitSet(w * h)
        if (sx !in 0 until w || sy !in 0 until h) return out
        val target = pixels[sy * w + sx]
        fun permitted(i: Int) = allowed == null || allowed[i].toInt() != 0
        if (!permitted(sy * w + sx)) return out

        if (!contiguous) {
            for (i in 0 until w * h) if (permitted(i) && channelDiff(pixels[i], target) <= tolerance) out.set(i)
            return out
        }

        fun ok(i: Int) = !out.get(i) && permitted(i) && channelDiff(pixels[i], target) <= tolerance
        var stack = IntArray(1024)
        var sp = 0
        fun push(v: Int) {
            if (sp == stack.size) stack = stack.copyOf(stack.size * 2)
            stack[sp++] = v
        }
        push(sy * w + sx)
        while (sp > 0) {
            val seed = stack[--sp]
            if (out.get(seed)) continue
            val y = seed / w
            val x = seed % w
            var l = x
            while (l > 0 && ok(y * w + l - 1)) l--
            var r = x
            while (r < w - 1 && ok(y * w + r + 1)) r++
            for (i in l..r) out.set(y * w + i)
            for (ny in intArrayOf(y - 1, y + 1)) {
                if (ny < 0 || ny >= h) continue
                var i = l
                while (i <= r) {
                    if (ok(ny * w + i)) {
                        push(ny * w + i)
                        while (i <= r && ok(ny * w + i)) i++
                    } else i++
                }
            }
        }
        return out
    }

    /** Straight-alpha "source over destination" of [src] (ARGB) with extra [opacity] 0..1. */
    fun over(dst: Int, src: Int, opacity: Float): Int {
        val sa = (src ushr 24) / 255f * opacity
        val da = (dst ushr 24) / 255f
        val oa = sa + da * (1f - sa)
        if (oa <= 0f) return 0
        fun ch(shift: Int): Int {
            val s = (src shr shift) and 0xFF
            val d = (dst shr shift) and 0xFF
            return ((s * sa + d * da * (1f - sa)) / oa).roundToInt().coerceIn(0, 255)
        }
        return ((oa * 255f).roundToInt().coerceIn(0, 255) shl 24) or (ch(16) shl 16) or (ch(8) shl 8) or ch(0)
    }
}
