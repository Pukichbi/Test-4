package app.nupixel.core

import kotlin.math.hypot

/** Emits evenly spaced stamp positions along a polyline as points arrive. */
class StampWalker(private val spacing: Float) {
    private var carry = 0f
    private var lastX = 0f
    private var lastY = 0f

    fun begin(x: Float, y: Float, emit: (Float, Float) -> Unit) {
        lastX = x; lastY = y; carry = 0f
        emit(x, y)
    }

    fun moveTo(x: Float, y: Float, emit: (Float, Float) -> Unit) {
        val dx = x - lastX
        val dy = y - lastY
        val dist = hypot(dx, dy)
        if (dist == 0f) return
        var d = spacing - carry
        while (d <= dist) {
            val t = d / dist
            emit(lastX + dx * t, lastY + dy * t)
            d += spacing
        }
        carry = dist - (d - spacing)
        lastX = x; lastY = y
    }
}
