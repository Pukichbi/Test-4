package app.nupixel.core

import kotlin.math.roundToInt

/** A guide line in document pixels. [vertical] = runs top to bottom at x = [position]. */
data class Guide(val vertical: Boolean, val position: Int)

object GuideOps {
    /** Shift guides by (dx, dy) and drop those that fall outside a [newW] x [newH] canvas. */
    fun translate(guides: List<Guide>, dx: Int, dy: Int, newW: Int, newH: Int): List<Guide> =
        guides.map { if (it.vertical) it.copy(position = it.position + dx) else it.copy(position = it.position + dy) }
            .filter { if (it.vertical) it.position in 0..newW else it.position in 0..newH }

    /** Scale guide positions when the image is resampled. */
    fun scale(guides: List<Guide>, sx: Float, sy: Float, newW: Int, newH: Int): List<Guide> =
        guides.map {
            if (it.vertical) it.copy(position = (it.position * sx).roundToInt()) else it.copy(position = (it.position * sy).roundToInt())
        }.filter { if (it.vertical) it.position in 0..newW else it.position in 0..newH }
}

object CanvasMath {
    /** Offset of the old content inside the new canvas. [anchor]: 0 = start, 1 = center, 2 = end. */
    fun anchorOffset(oldSize: Int, newSize: Int, anchor: Int): Int = ((newSize - oldSize) * anchor / 2f).roundToInt()
}
