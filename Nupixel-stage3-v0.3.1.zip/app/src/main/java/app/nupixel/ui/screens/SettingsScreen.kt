package app.nupixel.ui.screens

import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.os.LocaleListCompat
import app.nupixel.AppViewModel
import app.nupixel.R
import app.nupixel.ui.components.NxScreen
import app.nupixel.ui.components.NxSectionLabel
import app.nupixel.ui.components.NxSegmented

@Composable
fun SettingsScreen(vm: AppViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val version = remember {
        try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "" } catch (e: Exception) { "" }
    }
    var lang by remember {
        val tags = AppCompatDelegate.getApplicationLocales().toLanguageTags()
        mutableStateOf(if (tags.startsWith("ru")) "ru" else if (tags.startsWith("en")) "en" else "system")
    }

    NxScreen(title = stringResource(R.string.settings_title), onBack = onBack) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp)) {
            NxSectionLabel(stringResource(R.string.settings_theme))
            NxSegmented(
                options = listOf(
                    "dark" to stringResource(R.string.theme_dark),
                    "light" to stringResource(R.string.theme_light),
                    "system" to stringResource(R.string.theme_system),
                ),
                selected = vm.themeMode, onSelect = { vm.setTheme(it) },
            )

            NxSectionLabel(stringResource(R.string.settings_language))
            NxSegmented(
                options = listOf(
                    "system" to stringResource(R.string.lang_system),
                    "en" to stringResource(R.string.lang_en),
                    "ru" to stringResource(R.string.lang_ru),
                ),
                selected = lang,
                onSelect = {
                    lang = it
                    // Recreates the activity and persists the choice via AppCompat's locale storage service.
                    AppCompatDelegate.setApplicationLocales(
                        if (it == "system") LocaleListCompat.getEmptyLocaleList() else LocaleListCompat.forLanguageTags(it)
                    )
                },
            )

            NxSectionLabel(stringResource(R.string.settings_about))
            Text(stringResource(R.string.about_version, version), style = MaterialTheme.typography.titleMedium)
            Text(
                stringResource(R.string.about_text),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 4.dp),
            )
        }
    }
}
