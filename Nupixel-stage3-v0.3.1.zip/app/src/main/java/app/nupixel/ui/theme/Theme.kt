package app.nupixel.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Design tokens, see docs/DESIGN_SYSTEM.md. */
object NxDimens {
    val spaceXs = 4.dp
    val spaceSm = 8.dp
    val spaceMd = 12.dp
    val spaceLg = 16.dp
    val spaceXl = 24.dp
    val touchMin = 48.dp
    val buttonHeight = 56.dp
}

@Immutable
class NxExtraColors(
    val brandCyan: Color,
    val brandViolet: Color,
    val success: Color,
    val warning: Color,
    val canvasBackground: Color,
    val checkerLight: Color,
    val checkerDark: Color,
    val homeGlow: Color,
)

val LocalNx = staticCompositionLocalOf<NxExtraColors> { error("NupixelTheme missing") }

private val Blue = Color(0xFF2F7BFF)
private val Cyan = Color(0xFF22D3EE)
private val Violet = Color(0xFF8B5CF6)

private val DarkScheme: ColorScheme = darkColorScheme(
    primary = Blue, onPrimary = Color.White,
    primaryContainer = Color(0xFF173A7A), onPrimaryContainer = Color(0xFFD9E6FF),
    secondary = Cyan, onSecondary = Color(0xFF00363D),
    tertiary = Violet, onTertiary = Color.White,
    background = Color(0xFF0B1020), onBackground = Color(0xFFE8EDF8),
    surface = Color(0xFF0B1020), onSurface = Color(0xFFE8EDF8),
    surfaceVariant = Color(0xFF18233F), onSurfaceVariant = Color(0xFF93A1BF),
    surfaceContainerLowest = Color(0xFF080C19),
    surfaceContainerLow = Color(0xFF0F1629),
    surfaceContainer = Color(0xFF131C33),
    surfaceContainerHigh = Color(0xFF18233F),
    surfaceContainerHighest = Color(0xFF1F2B4A),
    outline = Color(0xFF3A4868), outlineVariant = Color(0xFF26334F),
    error = Color(0xFFFF5C7A), onError = Color.White,
)

private val LightScheme: ColorScheme = lightColorScheme(
    primary = Color(0xFF1F63E6), onPrimary = Color.White,
    primaryContainer = Color(0xFFDCE7FF), onPrimaryContainer = Color(0xFF0A2A66),
    secondary = Color(0xFF0891B2), onSecondary = Color.White,
    tertiary = Color(0xFF7C3AED), onTertiary = Color.White,
    background = Color(0xFFF4F6FB), onBackground = Color(0xFF0F1730),
    surface = Color(0xFFF4F6FB), onSurface = Color(0xFF0F1730),
    surfaceVariant = Color(0xFFE6ECF7), onSurfaceVariant = Color(0xFF5B6885),
    surfaceContainerLowest = Color(0xFFFFFFFF),
    surfaceContainerLow = Color(0xFFF9FAFD),
    surfaceContainer = Color(0xFFFFFFFF),
    surfaceContainerHigh = Color(0xFFEEF2FA),
    surfaceContainerHighest = Color(0xFFE6ECF7),
    outline = Color(0xFF9AA6C0), outlineVariant = Color(0xFFD5DCEB),
    error = Color(0xFFD92D4F), onError = Color.White,
)

private val DarkExtra = NxExtraColors(
    brandCyan = Cyan, brandViolet = Violet,
    success = Color(0xFF34D399), warning = Color(0xFFFBBF24),
    canvasBackground = Color(0xFF070B16),
    checkerLight = Color(0xFF3A4260), checkerDark = Color(0xFF2E3550),
    homeGlow = Color(0xFF2F7BFF),
)
private val LightExtra = NxExtraColors(
    brandCyan = Color(0xFF0891B2), brandViolet = Color(0xFF7C3AED),
    success = Color(0xFF059669), warning = Color(0xFFD97706),
    canvasBackground = Color(0xFFDDE3F0),
    checkerLight = Color(0xFFFFFFFF), checkerDark = Color(0xFFD5DBE8),
    homeGlow = Color(0xFF1F63E6),
)

private val NxTypography = Typography(
    headlineLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 36.sp, lineHeight = 42.sp, letterSpacing = (-0.5).sp),
    headlineSmall = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 24.sp, lineHeight = 30.sp),
    titleLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 20.sp, lineHeight = 26.sp),
    titleMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Medium, fontSize = 16.sp, lineHeight = 22.sp),
    bodyLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontSize = 16.sp, lineHeight = 22.sp),
    bodyMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontSize = 14.sp, lineHeight = 20.sp),
    bodySmall = TextStyle(fontFamily = FontFamily.SansSerif, fontSize = 12.sp, lineHeight = 16.sp),
    labelLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Medium, fontSize = 14.sp, lineHeight = 20.sp),
    labelMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Medium, fontSize = 12.sp, lineHeight = 16.sp),
)

private val NxShapes = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(20.dp),
    extraLarge = RoundedCornerShape(28.dp),
)

@Composable
fun NupixelTheme(dark: Boolean, content: @Composable () -> Unit) {
    CompositionLocalProvider(LocalNx provides if (dark) DarkExtra else LightExtra) {
        MaterialTheme(
            colorScheme = if (dark) DarkScheme else LightScheme,
            typography = NxTypography,
            shapes = NxShapes,
            content = content,
        )
    }
}
