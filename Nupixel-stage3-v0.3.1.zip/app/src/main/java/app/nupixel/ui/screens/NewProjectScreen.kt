package app.nupixel.ui.screens

import android.graphics.Color as AColor
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import app.nupixel.AppViewModel
import app.nupixel.R
import app.nupixel.core.Limits
import app.nupixel.ui.components.NxButton
import app.nupixel.ui.components.NxCard
import app.nupixel.ui.components.NxScreen
import app.nupixel.ui.components.NxSectionLabel
import app.nupixel.ui.components.NxSegmented

private class Preset(val key: String, val labelRes: Int, val w: Int, val h: Int)

private val presets = listOf(
    Preset("hd", R.string.preset_hd, 1920, 1080),
    Preset("4k", R.string.preset_4k, 3840, 2160),
    Preset("square", R.string.preset_square, 1080, 1080),
    Preset("portrait", R.string.preset_portrait, 1080, 1920),
    Preset("custom", R.string.preset_custom, 0, 0),
)

@Composable
fun NewProjectScreen(vm: AppViewModel, onBack: () -> Unit, onOpenEditor: () -> Unit) {
    val fallbackName = stringResource(R.string.default_project_name)
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.importImage(uri, fallbackName, onOpenEditor)
    }

    var preset by remember { mutableStateOf("hd") }
    var widthText by remember { mutableStateOf("1920") }
    var heightText by remember { mutableStateOf("1080") }
    var background by remember { mutableStateOf("white") }
    var name by remember { mutableStateOf("") }

    val w = widthText.toIntOrNull()
    val h = heightText.toIntOrNull()
    val maxPixels = Limits.maxPixels()
    val error: String? = when {
        w == null || h == null || w < 1 || h < 1 || w > Limits.MAX_SIDE || h > Limits.MAX_SIDE ->
            stringResource(R.string.err_size_range, Limits.MAX_SIDE)
        w.toLong() * h > maxPixels -> stringResource(R.string.err_size_limit, Limits.maxMegapixels())
        else -> null
    }

    NxScreen(title = stringResource(R.string.new_title), onBack = onBack) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp)) {
            NxCard(
                title = stringResource(R.string.new_from_image),
                subtitle = stringResource(R.string.new_from_image_sub),
                icon = Icons.Rounded.Image,
                onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
            )

            NxSectionLabel(stringResource(R.string.new_blank))
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                presets.forEach { p ->
                    NxCard(
                        title = stringResource(p.labelRes),
                        subtitle = if (p.key == "custom") null else "${p.w} × ${p.h}",
                        selected = preset == p.key,
                        onClick = {
                            preset = p.key
                            if (p.key != "custom") { widthText = p.w.toString(); heightText = p.h.toString() }
                        },
                        trailing = {
                            if (preset == p.key) Icon(Icons.Rounded.Check, null, tint = MaterialTheme.colorScheme.primary)
                        },
                    )
                }
            }

            if (preset == "custom") {
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = widthText, onValueChange = { widthText = it.filter(Char::isDigit).take(5) },
                        label = { Text(stringResource(R.string.label_width)) }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                    )
                    OutlinedTextField(
                        value = heightText, onValueChange = { heightText = it.filter(Char::isDigit).take(5) },
                        label = { Text(stringResource(R.string.label_height)) }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                    )
                }
            }
            if (error != null) {
                Text(error, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 8.dp))
            }

            NxSectionLabel(stringResource(R.string.label_background))
            NxSegmented(
                options = listOf(
                    "white" to stringResource(R.string.bg_white),
                    "transparent" to stringResource(R.string.bg_transparent),
                    "black" to stringResource(R.string.bg_black),
                ),
                selected = background, onSelect = { background = it },
            )

            NxSectionLabel(stringResource(R.string.label_name))
            OutlinedTextField(
                value = name, onValueChange = { name = it.take(60) },
                placeholder = { Text(fallbackName) }, singleLine = true,
                modifier = Modifier.fillMaxWidthCompat(),
            )

            Spacer(Modifier.height(24.dp))
            NxButton(
                text = stringResource(R.string.action_create),
                icon = Icons.Rounded.Add,
                enabled = error == null,
                onClick = {
                    val color = when (background) {
                        "transparent" -> AColor.TRANSPARENT
                        "black" -> AColor.BLACK
                        else -> AColor.WHITE
                    }
                    vm.createBlank(name.trim().ifEmpty { fallbackName }, w!!, h!!, color, onOpenEditor)
                },
            )
            Spacer(Modifier.height(16.dp))
        }
    }
}

private fun Modifier.fillMaxWidthCompat(): Modifier = this.then(Modifier.fillMaxWidth())
