package app.nupixel.render

import android.graphics.Canvas
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import app.nupixel.tools.TextObject
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max

object TextRenderer {
    private fun typeface(t: TextObject): Typeface {
        val family = when (t.font) {
            "serif" -> Typeface.SERIF
            "mono" -> Typeface.MONOSPACE
            else -> Typeface.SANS_SERIF
        }
        val style = when {
            t.bold && t.italic -> Typeface.BOLD_ITALIC
            t.bold -> Typeface.BOLD
            t.italic -> Typeface.ITALIC
            else -> Typeface.NORMAL
        }
        return Typeface.create(family, style)
    }

    private fun layout(t: TextObject): StaticLayout {
        val paint = TextPaint(TextPaint.ANTI_ALIAS_FLAG).apply {
            color = t.color
            textSize = max(1f, t.size)
            typeface = typeface(t)
        }
        val text = t.text.ifEmpty { " " }
        val width = ceil(text.split("\n").maxOf { paint.measureText(it) }).toInt().coerceAtLeast(1) + 2
        return StaticLayout.Builder.obtain(text, 0, text.length, paint, width)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL).build()
    }

    fun bounds(t: TextObject): RectF {
        val l = layout(t)
        return RectF(t.x, t.y, t.x + l.width, t.y + l.height)
    }

    fun draw(canvas: Canvas, t: TextObject) {
        canvas.save()
        canvas.translate(t.x, t.y)
        layout(t).draw(canvas)
        canvas.restore()
    }

    fun dirtyRect(t: TextObject): Rect {
        val b = bounds(t)
        return Rect(floor(b.left).toInt() - 2, floor(b.top).toInt() - 2, ceil(b.right).toInt() + 2, ceil(b.bottom).toInt() + 2)
    }
}
