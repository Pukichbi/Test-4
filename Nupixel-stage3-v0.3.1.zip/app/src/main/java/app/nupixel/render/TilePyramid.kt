package app.nupixel.render

import android.graphics.Bitmap
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import app.nupixel.core.TileGrid
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min

/** LRU cache of 512 px tiles cut from one bitmap. Used only from the draw thread. */
class TileCache(private val source: Bitmap, private val maxTiles: Int = 96) {
    private val tiles = object : LinkedHashMap<Long, ImageBitmap>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<Long, ImageBitmap>?): Boolean = size > maxTiles
    }

    /** Drops cached tiles that overlap [r] (document pixels), or all tiles when [r] is null. */
    fun invalidate(r: android.graphics.Rect?) {
        if (r == null) { tiles.clear(); return }
        val t = TileGrid.TILE
        val cols = (source.width + t - 1) / t
        val rows = (source.height + t - 1) / t
        val x0 = max(0, r.left / t)
        val x1 = min(cols - 1, (r.right - 1) / t)
        val y0 = max(0, r.top / t)
        val y1 = min(rows - 1, (r.bottom - 1) / t)
        for (ty in y0..y1) for (tx in x0..x1) tiles.remove(ty.toLong() * 100_000L + tx)
    }

    fun tile(tx: Int, ty: Int): ImageBitmap {
        val key = ty.toLong() * 100_000L + tx
        return tiles.getOrPut(key) {
            val t = TileGrid.TILE
            val x = tx * t
            val y = ty * t
            val w = min(t, source.width - x)
            val h = min(t, source.height - y)
            Bitmap.createBitmap(source, x, y, w, h).asImageBitmap()
        }
    }
}

/**
 * Half-resolution levels of a document bitmap, built lazily in the background, so zoomed-out views
 * draw few tiles. Level 0 is the document bitmap itself.
 */
class TilePyramid(val source: Bitmap) {
    val maxLevel: Int = run {
        var l = 0
        var m = max(source.width, source.height)
        while (m / 2 >= 256) { m /= 2; l++ }
        l
    }

    private val lock = Any()
    private val bitmaps = arrayOfNulls<Bitmap>(maxLevel + 1).also { it[0] = source }
    private val caches = arrayOfNulls<TileCache>(maxLevel + 1)
    private var generation = 0 // bumped by invalidate() so a rebuild started before an edit cannot store stale levels

    /** Incremented when a new level becomes available, so drawing can pick it up. */
    var readyVersion by mutableIntStateOf(0)
        private set

    fun bestLevel(wanted: Int): Int = synchronized(lock) {
        var l = min(wanted, maxLevel)
        while (l > 0 && bitmaps[l] == null) l--
        l
    }

    fun levelBitmap(level: Int): Bitmap = synchronized(lock) { bitmaps[level]!! }

    fun cache(level: Int): TileCache = synchronized(lock) {
        caches[level] ?: TileCache(bitmaps[level]!!).also { caches[level] = it }
    }

    /** Incremented by [invalidate]; drawing code uses it to schedule a pyramid rebuild. */
    var invalidations by mutableIntStateOf(0)
        private set

    /**
     * Call on the main thread after the source bitmap was edited. Level-0 tiles in [dirty] are dropped
     * (all of them when null); half-resolution levels are discarded and rebuilt in the background.
     */
    fun invalidate(dirty: android.graphics.Rect?) {
        synchronized(lock) {
            generation++
            caches[0]?.invalidate(dirty)
            for (l in 1..maxLevel) { bitmaps[l] = null; caches[l] = null }
        }
        invalidations++
        readyVersion++
    }

    suspend fun ensureLevel(level: Int) {
        val target = min(level, maxLevel)
        if (target <= 0) return
        withContext(Dispatchers.Default) {
            for (l in 1..target) {
                var gen = 0
                var exists = false
                var prevBitmap: Bitmap? = null
                synchronized(lock) {
                    exists = bitmaps[l] != null
                    gen = generation
                    prevBitmap = bitmaps[l - 1]
                }
                if (exists) continue
                val prev = prevBitmap ?: return@withContext
                val next = Bitmap.createScaledBitmap(prev, max(1, prev.width / 2), max(1, prev.height / 2), true)
                val stored = synchronized(lock) {
                    if (generation == gen) { bitmaps[l] = next; true } else false
                }
                if (!stored) return@withContext
                withContext(Dispatchers.Main) { readyVersion++ }
            }
        }
    }

    companion object {
        /** Pyramid level whose pixels are still at least one screen pixel at view scale [scale]. */
        fun levelFor(scale: Float, maxLevel: Int): Int =
            if (scale >= 1f) 0 else min(maxLevel, (ln(1f / scale) / ln(2f)).toInt())
    }
}
