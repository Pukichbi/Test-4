package app.nupixel.render

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Rect
import app.nupixel.core.CanvasMath

/** Whole-document raster operations. Every function returns a new mutable ARGB_8888 bitmap and never modifies or recycles [src]. */
object BitmapOps {
    fun crop(src: Bitmap, x: Int, y: Int, w: Int, h: Int): Bitmap {
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        Canvas(out).drawBitmap(src, Rect(x, y, x + w, y + h), Rect(0, 0, w, h), null)
        return out
    }

    fun resizeCanvas(src: Bitmap, newW: Int, newH: Int, anchorX: Int, anchorY: Int, fill: Int): Bitmap {
        val out = Bitmap.createBitmap(newW, newH, Bitmap.Config.ARGB_8888)
        out.eraseColor(fill)
        val ox = CanvasMath.anchorOffset(src.width, newW, anchorX)
        val oy = CanvasMath.anchorOffset(src.height, newH, anchorY)
        Canvas(out).drawBitmap(src, ox.toFloat(), oy.toFloat(), null)
        return out
    }

    /** Resample to [w] x [h]; large reductions are done in halving steps to avoid aliasing. */
    fun resample(src: Bitmap, w: Int, h: Int): Bitmap {
        var cur = src
        while (cur.width / 2 >= w && cur.height / 2 >= h) {
            val next = Bitmap.createScaledBitmap(cur, cur.width / 2, cur.height / 2, true)
            if (cur !== src) cur.recycle()
            cur = next
        }
        var out = if (cur.width == w && cur.height == h) cur else Bitmap.createScaledBitmap(cur, w, h, true)
        if (cur !== src && cur !== out) cur.recycle()
        if (out === src || !out.isMutable || out.config != Bitmap.Config.ARGB_8888) {
            val copy = out.copy(Bitmap.Config.ARGB_8888, true)
            if (out !== src) out.recycle()
            out = copy
        }
        return out
    }
}
