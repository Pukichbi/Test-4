package app.nupixel

import android.app.Application
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import androidx.annotation.StringRes
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import app.nupixel.core.CanvasMath
import app.nupixel.core.Guide
import app.nupixel.core.GuideOps
import app.nupixel.core.Limits
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Rect
import app.nupixel.render.BitmapOps
import app.nupixel.tools.Selection
import app.nupixel.tools.Tool
import app.nupixel.tools.ToolSettings
import app.nupixel.data.AppPrefs
import app.nupixel.data.ExportFormat
import app.nupixel.data.ImageIO
import app.nupixel.data.ImportException
import app.nupixel.data.LayerEntry
import app.nupixel.data.ProjectFormatException
import app.nupixel.data.ProjectInfo
import app.nupixel.data.ProjectManifest
import app.nupixel.data.ProjectStore
import app.nupixel.data.ProjectTooNewException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.IOException

class UiMessage(@StringRes val res: Int, val args: List<Any> = emptyList())

/** One-step undo for whole-document canvas operations (full history arrives in stage 5). */
class UndoState(val bitmap: Bitmap, val guides: List<Guide>)

/** The document currently open in the editor. [dirty] = has changes not yet written to the .npx file. */
data class Session(
    val id: String,
    val name: String,
    val bitmap: Bitmap,
    val createdAt: Long,
    val dirty: Boolean,
    val guides: List<Guide> = emptyList(),
    val undo: UndoState? = null,
)

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val store = ProjectStore(app)
    private val prefs = AppPrefs(app)
    private val versionName: String = try {
        app.packageManager.getPackageInfo(app.packageName, 0).versionName ?: "0"
    } catch (e: Exception) { "0" }

    var themeMode by mutableStateOf(prefs.theme); private set
    var session by mutableStateOf<Session?>(null); private set
    var projects by mutableStateOf<List<ProjectInfo>>(emptyList()); private set
    var busy by mutableStateOf(false); private set

    // ---- Editing tools (stage 3) ----
    val tool = ToolSettings()
    var activeTool by mutableStateOf(Tool.VIEW)
    var selection by mutableStateOf<Selection?>(null)

    private val _messages = MutableSharedFlow<UiMessage>(extraBufferCapacity = 8)
    val messages = _messages.asSharedFlow()

    private fun say(@StringRes res: Int, vararg args: Any) { _messages.tryEmit(UiMessage(res, args.toList())) }

    fun setTheme(mode: String) { prefs.theme = mode; themeMode = mode }

    fun refreshProjects() {
        viewModelScope.launch { projects = withContext(Dispatchers.IO) { store.list() } }
    }

    /** Runs [block] on IO with the busy overlay shown; maps known failures to user messages. */
    private fun task(@StringRes failure: Int, block: suspend () -> Unit) {
        viewModelScope.launch {
            busy = true
            try {
                withContext(Dispatchers.IO) { block() }
            } catch (e: OutOfMemoryError) {
                say(R.string.err_memory)
            } catch (e: ProjectTooNewException) {
                say(R.string.err_project_new)
            } catch (e: ImportException) {
                say(R.string.err_import)
            } catch (e: ProjectFormatException) {
                say(R.string.err_open_project)
            } catch (e: IOException) {
                say(failure)
            } catch (e: SecurityException) {
                say(failure)
            } finally {
                busy = false
            }
        }
    }

    fun createBlank(name: String, width: Int, height: Int, background: Int, onDone: () -> Unit) {
        task(R.string.err_import) {
            val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            bmp.eraseColor(background)
            val s = Session(store.newId(), name, bmp, System.currentTimeMillis(), dirty = true)
            withContext(Dispatchers.Main) { session = s; onDone() }
        }
    }

    fun importImage(uri: Uri, fallbackName: String, onDone: () -> Unit) {
        task(R.string.err_import) {
            val ctx = getApplication<Application>()
            val d = ImageIO.decode(ctx, uri, Limits.maxPixels(), Limits.MAX_SIDE)
            val name = ImageIO.displayName(ctx, uri)?.takeIf { it.isNotBlank() } ?: fallbackName
            val s = Session(store.newId(), name, d.bitmap, System.currentTimeMillis(), dirty = true)
            withContext(Dispatchers.Main) {
                session = s
                if (d.downscaled) say(R.string.msg_downscaled, d.bitmap.width, d.bitmap.height)
                onDone()
            }
        }
    }

    fun openProject(id: String, onDone: () -> Unit) {
        task(R.string.err_open_project) {
            val p = store.load(id)
            val s = Session(p.id, p.manifest.name, p.bitmap, p.manifest.createdAt, dirty = false, guides = p.manifest.guides)
            withContext(Dispatchers.Main) { session = s; onDone() }
        }
    }

    fun importProjectFile(uri: Uri, onDone: () -> Unit) {
        task(R.string.err_open_project) {
            val ctx = getApplication<Application>()
            val input = ctx.contentResolver.openInputStream(uri) ?: throw IOException("no stream")
            val id = input.use { store.importFile(it) }
            val p = store.load(id)
            store.writeThumbnail(id, p.bitmap)
            val s = Session(p.id, p.manifest.name, p.bitmap, p.manifest.createdAt, dirty = false, guides = p.manifest.guides)
            withContext(Dispatchers.Main) { session = s; onDone() }
        }
    }

    fun saveSession(onResult: (Boolean) -> Unit = {}) {
        val s = session ?: return onResult(false)
        viewModelScope.launch {
            busy = true
            val ok = try {
                withContext(Dispatchers.IO) {
                    val now = System.currentTimeMillis()
                    store.save(
                        s.id,
                        ProjectManifest(
                            appVersion = versionName, name = s.name,
                            width = s.bitmap.width, height = s.bitmap.height,
                            createdAt = s.createdAt, modifiedAt = now,
                            layers = listOf(LayerEntry("layer-1", "Layer 1", "raster", "layers/layer-1.png")),
                            guides = s.guides,
                        ),
                        s.bitmap,
                    )
                }
                true
            } catch (e: IOException) {
                false
            } catch (e: OutOfMemoryError) {
                false
            } finally {
                busy = false
            }
            if (ok) {
                session = session?.takeIf { it.bitmap === s.bitmap && it.guides == s.guides }?.copy(dirty = false) ?: session
                say(R.string.msg_saved)
            } else say(R.string.err_save)
            onResult(ok)
        }
    }


    // ---- Canvas operations (stage 2). All are whole-document, with one-step undo. ----

    private fun bitmapOp(newBitmap: (Bitmap) -> Bitmap, newGuides: (Session, Bitmap) -> List<Guide>) {
        val s = session ?: return
        task(R.string.err_memory) {
            val nb = newBitmap(s.bitmap)
            val ng = newGuides(s, nb)
            withContext(Dispatchers.Main) {
                selection = null
                session = s.copy(bitmap = nb, guides = ng, dirty = true, undo = UndoState(s.bitmap, s.guides))
            }
        }
    }

    fun cropCanvas(x: Int, y: Int, w: Int, h: Int) = bitmapOp(
        { BitmapOps.crop(it, x, y, w, h) },
        { s, _ -> GuideOps.translate(s.guides, -x, -y, w, h) },
    )

    fun resizeCanvas(w: Int, h: Int, anchorX: Int, anchorY: Int, fill: Int) = bitmapOp(
        { BitmapOps.resizeCanvas(it, w, h, anchorX, anchorY, fill) },
        { s, _ ->
            GuideOps.translate(
                s.guides,
                CanvasMath.anchorOffset(s.bitmap.width, w, anchorX),
                CanvasMath.anchorOffset(s.bitmap.height, h, anchorY),
                w, h,
            )
        },
    )

    fun resample(w: Int, h: Int) = bitmapOp(
        { BitmapOps.resample(it, w, h) },
        { s, _ -> GuideOps.scale(s.guides, w / s.bitmap.width.toFloat(), h / s.bitmap.height.toFloat(), w, h) },
    )

    fun undoCanvasOp() {
        val s = session ?: return
        val u = s.undo ?: return
        selection = null
        session = s.copy(bitmap = u.bitmap, guides = u.guides, undo = null, dirty = true)
    }

    private fun updateGuides(change: (Session) -> List<Guide>) {
        val s = session ?: return
        val g = change(s)
        if (g != s.guides) session = s.copy(guides = g, dirty = true)
    }

    fun addGuide(vertical: Boolean, position: Int) = updateGuides { s ->
        val max = if (vertical) s.bitmap.width else s.bitmap.height
        val g = Guide(vertical, position.coerceIn(0, max))
        if (g in s.guides) s.guides else s.guides + g
    }

    fun addCenterGuides() = updateGuides { s ->
        (s.guides + Guide(true, s.bitmap.width / 2) + Guide(false, s.bitmap.height / 2)).distinct()
    }

    fun removeGuide(index: Int) = updateGuides { s -> s.guides.filterIndexed { i, _ -> i != index } }

    fun clearGuides() = updateGuides { emptyList() }


    // ---- Edit plumbing for tools. Tools change session.bitmap in place; one undo snapshot is kept. ----

    /** Full mutable copy of the document: baseline for a stroke and the undo snapshot. Null when memory is short. */
    fun beginEdit(): Bitmap? {
        val s = session ?: return null
        return try {
            s.bitmap.copy(Bitmap.Config.ARGB_8888, true)
        } catch (e: OutOfMemoryError) {
            say(R.string.err_memory)
            null
        }
    }

    fun commitEdit(snapshot: Bitmap) {
        val s = session ?: return
        session = s.copy(dirty = true, undo = UndoState(snapshot, s.guides))
    }

    /** Copies [snapshot] pixels back into the document (cancel of an edit in progress). */
    fun restoreFrom(snapshot: Bitmap) {
        val s = session ?: return
        Canvas(s.bitmap).drawBitmap(snapshot, 0f, 0f, Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC) })
    }

    fun reportMemoryError() = say(R.string.err_memory)

    /** Runs a whole-bitmap pixel operation off the main thread; [onDirty] gets the changed rectangle on the main thread. */
    fun editPixels(op: (Bitmap, Selection?) -> Rect?, onDirty: (Rect?) -> Unit) {
        val s = session ?: return
        val sel = selection
        viewModelScope.launch {
            busy = true
            try {
                val result = withContext(Dispatchers.Default) {
                    val snap = s.bitmap.copy(Bitmap.Config.ARGB_8888, true)
                    val r = op(s.bitmap, sel)
                    if (r == null) { snap.recycle(); null } else Pair(snap, r)
                }
                if (result != null) {
                    commitEdit(result.first)
                    onDirty(result.second)
                }
            } catch (e: OutOfMemoryError) {
                say(R.string.err_memory)
            } finally {
                busy = false
            }
        }
    }

    fun closeSession() { session = null; selection = null; activeTool = Tool.VIEW }

    fun exportImage(uri: Uri, format: ExportFormat, quality: Int, scale: Float) {
        val s = session ?: return
        task(R.string.err_export) {
            val ctx = getApplication<Application>()
            val out = ctx.contentResolver.openOutputStream(uri) ?: throw IOException("no stream")
            out.use { ImageIO.export(s.bitmap, format, quality, scale, it) }
            say(R.string.msg_exported)
        }
    }

    fun exportProjectFile(id: String, uri: Uri) {
        task(R.string.err_export) {
            val ctx = getApplication<Application>()
            val out = ctx.contentResolver.openOutputStream(uri) ?: throw IOException("no stream")
            out.use { store.copyTo(id, it) }
            say(R.string.msg_project_exported)
        }
    }

    fun deleteProject(id: String) {
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) { store.delete(id) }
            if (ok) say(R.string.msg_deleted) else say(R.string.err_delete)
            projects = withContext(Dispatchers.IO) { store.list() }
        }
    }

    companion object {
        val TRANSPARENT = Color.TRANSPARENT
        val WHITE = Color.WHITE
        val BLACK = Color.BLACK
    }
}
