package app.nupixel.tools

import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

enum class Tool { VIEW, BRUSH, ERASER, EYEDROPPER, FILL, MAGIC_ERASER, LINE, RECT, ELLIPSE, SELECT_RECT, SELECT_FREE, MOVE, TEXT }

/** Tool options that survive screen rotation (held by the ViewModel). */
class ToolSettings {
    var color by mutableIntStateOf(0xFF2F7BFF.toInt())

    var brushSize by mutableFloatStateOf(24f)
    var brushOpacity by mutableFloatStateOf(1f)
    var brushHardness by mutableFloatStateOf(0.8f)

    var eraserSize by mutableFloatStateOf(40f)
    var eraserOpacity by mutableFloatStateOf(1f)
    var eraserHardness by mutableFloatStateOf(0.8f)

    var fillTolerance by mutableIntStateOf(32)
    var fillContiguous by mutableStateOf(true)
    var fillOpacity by mutableFloatStateOf(1f)

    var bgTolerance by mutableIntStateOf(24)
    var bgContiguous by mutableStateOf(true)

    var shapeStroke by mutableFloatStateOf(6f)
    var shapeFilled by mutableStateOf(false)
    var shapeOpacity by mutableFloatStateOf(1f)
}

/** A selection in document pixels. Not saved with the project. */
class Selection(val path: Path, val bounds: RectF)

/** Content lifted out of the document for moving / scaling / rotating. */
class Floating(val bitmap: Bitmap, val origin: Rect, cx: Float, cy: Float) {
    var cx by mutableFloatStateOf(cx)
    var cy by mutableFloatStateOf(cy)
    var scale by mutableFloatStateOf(1f)
    var rotation by mutableFloatStateOf(0f) // degrees
}

/** Editable text until it is applied (rasterized) into the document. */
class TextObject(text: String, x: Float, y: Float, size: Float, color: Int) {
    var text by mutableStateOf(text)
    var x by mutableFloatStateOf(x)
    var y by mutableFloatStateOf(y)
    var size by mutableFloatStateOf(size)
    var color by mutableIntStateOf(color)
    var bold by mutableStateOf(false)
    var italic by mutableStateOf(false)
    var font by mutableStateOf("sans") // sans | serif | mono
}

data class ShapeDraft(val tool: Tool, val x0: Float, val y0: Float, val x1: Float, val y1: Float)
