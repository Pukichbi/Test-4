package app.nupixel.tools

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Rect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import app.nupixel.AppViewModel
import app.nupixel.render.BrushStamp
import app.nupixel.render.PixelOps
import app.nupixel.render.SelectionOps
import app.nupixel.render.ShapeRenderer
import app.nupixel.render.StrokeRenderer
import app.nupixel.render.TextRenderer
import app.nupixel.render.TilePyramid
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Turns pointer events (already converted to document coordinates) into edits of the open document.
 * Whole-document edits take a snapshot first, which becomes the one-step undo (full history: stage 5).
 */
class ToolController(private val vm: AppViewModel) {
    /** Set by the editor; edited regions are invalidated here so the canvas redraws them. */
    var pyramid: TilePyramid? = null

    /** Movement below this many document pixels counts as a tap. Set by the editor from the zoom level. */
    var tapSlop: Float = 6f

    var draft by mutableStateOf<ShapeDraft?>(null); private set
    var lasso by mutableStateOf<List<Pair<Float, Float>>>(emptyList()); private set
    var floating by mutableStateOf<Floating?>(null); private set
    var text by mutableStateOf<TextObject?>(null); private set
    var editingText by mutableStateOf(false)

    private var strokeLayer: Bitmap? = null
    private var stroke: StrokeRenderer? = null
    private var snapshot: Bitmap? = null
    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var textDrag = false
    private var textMoved = false

    private val tool get() = vm.activeTool

    private fun invalidate(r: Rect?) { pyramid?.invalidate(r) }
    private fun invalidateAll() { pyramid?.invalidate(null) }

    // ---------------------------------------------------------------- pointer events

    /** Returns true when the tool takes this gesture (otherwise the editor treats it as a view gesture). */
    fun onDown(x: Float, y: Float): Boolean {
        val session = vm.session ?: return false
        downX = x; downY = y; lastX = x; lastY = y
        return when (tool) {
            Tool.VIEW -> false
            Tool.BRUSH, Tool.ERASER -> startStroke(x, y)
            Tool.EYEDROPPER -> { pick(session.bitmap, x, y); true }
            Tool.FILL, Tool.MAGIC_ERASER -> true
            Tool.LINE, Tool.RECT, Tool.ELLIPSE, Tool.SELECT_RECT -> { draft = ShapeDraft(tool, x, y, x, y); true }
            Tool.SELECT_FREE -> { lasso = listOf(x to y); true }
            Tool.MOVE -> startMove()
            Tool.TEXT -> startText(x, y)
        }
    }

    fun onMove(x: Float, y: Float) {
        val session = vm.session ?: return
        when (tool) {
            Tool.BRUSH, Tool.ERASER -> stroke?.moveTo(x, y)?.let { invalidate(it) }
            Tool.EYEDROPPER -> pick(session.bitmap, x, y)
            Tool.LINE, Tool.RECT, Tool.ELLIPSE, Tool.SELECT_RECT -> draft = draft?.copy(x1 = x, y1 = y)
            Tool.SELECT_FREE -> lasso = lasso + (x to y)
            Tool.MOVE -> floating?.let { it.cx += x - lastX; it.cy += y - lastY }
            Tool.TEXT -> if (textDrag) {
                text?.let { it.x += x - lastX; it.y += y - lastY }
                if (hypot(x - downX, y - downY) > tapSlop) textMoved = true
            }
            else -> Unit
        }
        lastX = x; lastY = y
    }

    fun onUp() {
        val session = vm.session ?: return
        when (tool) {
            Tool.BRUSH, Tool.ERASER -> finishStroke()
            Tool.FILL -> {
                val t = vm.tool
                val x = lastX.toInt(); val y = lastY.toInt()
                vm.editPixels({ bmp, sel -> PixelOps.floodFill(bmp, x, y, t.color, t.fillOpacity, t.fillTolerance, t.fillContiguous, sel) }, ::invalidate)
            }
            Tool.MAGIC_ERASER -> {
                val t = vm.tool
                val x = lastX.toInt(); val y = lastY.toInt()
                vm.editPixels({ bmp, sel -> PixelOps.removeColor(bmp, x, y, t.bgTolerance, t.bgContiguous, sel) }, ::invalidate)
            }
            Tool.LINE, Tool.RECT, Tool.ELLIPSE -> {
                draft?.let { commitShape(it) }
                draft = null
            }
            Tool.SELECT_RECT -> {
                val d = draft
                draft = null
                val r = d?.let { ShapeRenderer.normalized(it) }
                vm.selection = if (r != null && r.width() >= 2f && r.height() >= 2f) SelectionOps.rectSelection(r.left, r.top, r.right, r.bottom) else null
            }
            Tool.SELECT_FREE -> {
                vm.selection = if (lasso.size >= 3) SelectionOps.polygonSelection(lasso) else null
                lasso = emptyList()
            }
            Tool.TEXT -> {
                if (!textMoved && text != null) editingText = true
                textDrag = false
            }
            else -> Unit
        }
    }

    /** A second finger arrived: undo whatever this one-finger gesture started. */
    fun onCancel() {
        when (tool) {
            Tool.BRUSH, Tool.ERASER -> {
                val r = stroke?.cancel()
                stroke = null
                snapshot?.recycle(); snapshot = null
                if (r != null) invalidate(r)
            }
            Tool.LINE, Tool.RECT, Tool.ELLIPSE, Tool.SELECT_RECT -> draft = null
            Tool.SELECT_FREE -> lasso = emptyList()
            Tool.TEXT -> {
                textDrag = false
                if (text?.text.isNullOrEmpty()) text = null
            }
            else -> Unit
        }
    }

    // ---------------------------------------------------------------- brush and eraser

    private fun ensureLayer(w: Int, h: Int): Bitmap? {
        strokeLayer?.let { if (it.width == w && it.height == h) return it }
        strokeLayer?.recycle()
        strokeLayer = null
        return try {
            Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888).also { strokeLayer = it }
        } catch (e: OutOfMemoryError) {
            vm.reportMemoryError()
            null
        }
    }

    private fun startStroke(x: Float, y: Float): Boolean {
        val session = vm.session ?: return false
        val t = vm.tool
        val eraser = tool == Tool.ERASER
        val size = if (eraser) t.eraserSize else t.brushSize
        val opacity = if (eraser) t.eraserOpacity else t.brushOpacity
        val hardness = if (eraser) t.eraserHardness else t.brushHardness
        val snap = vm.beginEdit() ?: return false
        val layer = ensureLayer(session.bitmap.width, session.bitmap.height)
        if (layer == null) { snap.recycle(); return false }
        val stamp = try {
            BrushStamp.create(size.roundToInt(), hardness, if (eraser) 0xFF000000.toInt() else t.color)
        } catch (e: OutOfMemoryError) {
            vm.reportMemoryError(); snap.recycle(); return false
        }
        snapshot = snap
        stroke = StrokeRenderer(session.bitmap, snap, layer, stamp, size, opacity, eraser, vm.selection?.path)
        stroke?.begin(x, y)?.let { invalidate(it) }
        return true
    }

    private fun finishStroke() {
        val r = stroke?.end()
        val snap = snapshot
        stroke = null
        snapshot = null
        if (r != null && snap != null) {
            vm.commitEdit(snap)
            invalidate(r)
        } else snap?.recycle()
    }

    // ---------------------------------------------------------------- eyedropper, shapes

    private fun pick(bmp: Bitmap, x: Float, y: Float) {
        val px = x.toInt().coerceIn(0, bmp.width - 1)
        val py = y.toInt().coerceIn(0, bmp.height - 1)
        vm.tool.color = bmp.getPixel(px, py) or 0xFF000000.toInt()
    }

    private fun commitShape(d: ShapeDraft) {
        if (hypot(d.x1 - d.x0, d.y1 - d.y0) < 1f) return
        val session = vm.session ?: return
        val snap = vm.beginEdit() ?: return
        val t = vm.tool
        val canvas = Canvas(session.bitmap)
        val sel = vm.selection
        if (sel != null) { canvas.save(); canvas.clipPath(sel.path) }
        val dirty = ShapeRenderer.draw(canvas, d, t.color, t.shapeOpacity, t.shapeStroke, t.shapeFilled)
        if (sel != null) canvas.restore()
        vm.commitEdit(snap)
        invalidate(dirty)
    }

    // ---------------------------------------------------------------- selection actions

    fun selectAll() {
        val s = vm.session ?: return
        finishPending()
        vm.selection = SelectionOps.rectSelection(0f, 0f, s.bitmap.width.toFloat(), s.bitmap.height.toFloat())
    }

    fun deselect() { finishPending(); vm.selection = null }

    fun clearSelectionPixels() {
        val s = vm.session ?: return
        val sel = vm.selection ?: return
        val snap = vm.beginEdit() ?: return
        SelectionOps.clear(s.bitmap, sel)
        vm.commitEdit(snap)
        invalidate(SelectionOps.clippedBounds(sel, s.bitmap.width, s.bitmap.height)?.also { it.inset(-2, -2) })
    }

    fun fillSelection() {
        val s = vm.session ?: return
        val sel = vm.selection ?: return
        val snap = vm.beginEdit() ?: return
        val t = vm.tool
        val color = (t.color and 0x00FFFFFF) or ((t.fillOpacity * 255f).roundToInt().coerceIn(0, 255) shl 24)
        SelectionOps.fill(s.bitmap, sel, color)
        vm.commitEdit(snap)
        invalidate(SelectionOps.clippedBounds(sel, s.bitmap.width, s.bitmap.height)?.also { it.inset(-2, -2) })
    }

    fun cropToSelection() {
        val s = vm.session ?: return
        val sel = vm.selection ?: return
        val b = SelectionOps.clippedBounds(sel, s.bitmap.width, s.bitmap.height) ?: return
        vm.cropCanvas(b.left, b.top, b.width(), b.height())
    }

    // ---------------------------------------------------------------- move / scale / rotate selection

    private fun startMove(): Boolean {
        if (floating != null) return true
        val s = vm.session ?: return false
        val sel = vm.selection ?: return false
        val snap = vm.beginEdit() ?: return false
        val f = SelectionOps.lift(s.bitmap, sel)
        if (f == null) { snap.recycle(); return false }
        snapshot = snap
        floating = f
        invalidate(f.origin)
        return true
    }

    fun applyFloating() {
        val f = floating ?: return
        val s = vm.session ?: return
        val snap = snapshot
        val r = SelectionOps.drawFloating(s.bitmap, f)
        r.union(f.origin)
        vm.selection = SelectionOps.floatingSelection(f)
        if (snap != null) vm.commitEdit(snap)
        floating = null
        snapshot = null
        invalidate(r)
    }

    fun cancelFloating() {
        if (floating == null) return
        snapshot?.let { vm.restoreFrom(it); it.recycle() }
        floating = null
        snapshot = null
        invalidateAll()
    }

    // ---------------------------------------------------------------- text

    private fun startText(x: Float, y: Float): Boolean {
        val s = vm.session ?: return false
        val current = text
        textMoved = false
        if (current != null && TextRenderer.bounds(current).contains(x, y)) {
            textDrag = true
            return true
        }
        if (current != null) commitText()
        val size = (min(s.bitmap.width, s.bitmap.height) / 10f).coerceIn(24f, 400f)
        text = TextObject("", x, y, size, vm.tool.color)
        textDrag = false
        return true
    }

    /** Called by the text dialog. Empty text removes the object. */
    fun setText(value: String) {
        val t = text ?: return
        if (value.isBlank()) text = null else t.text = value
        editingText = false
    }

    fun deleteText() { text = null; editingText = false }

    fun commitText() {
        val t = text ?: return
        if (t.text.isBlank()) { text = null; return }
        val s = vm.session ?: return
        val snap = vm.beginEdit() ?: return
        val canvas = Canvas(s.bitmap)
        val sel = vm.selection
        if (sel != null) { canvas.save(); canvas.clipPath(sel.path) }
        TextRenderer.draw(canvas, t)
        if (sel != null) canvas.restore()
        vm.commitEdit(snap)
        invalidate(TextRenderer.dirtyRect(t))
        text = null
    }

    // ---------------------------------------------------------------- tool switching

    /** Applies anything still floating or editable. Call before switching tools, saving or exporting. */
    fun finishPending() {
        applyFloating()
        commitText()
    }

    fun selectTool(t: Tool) {
        if (t != tool) finishPending()
        vm.activeTool = t
    }

    fun release() {
        strokeLayer?.recycle()
        strokeLayer = null
    }
}
