package app.nupixel

import app.nupixel.core.ViewTransform
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.PI

class ViewTransformTest {
    private val eps = 0.01f
    private val rotated = ViewTransform(scale = 2.5f, offsetX = 40f, offsetY = -10f, rotation = 0.6f)

    @Test fun docToScreenAndBack() {
        for (v in listOf(ViewTransform(2.5f, 40f, -10f), rotated)) {
            val s = v.docToScreen(100f, 60f)
            val d = v.screenToDoc(s.x, s.y)
            assertEquals(100f, d.x, eps)
            assertEquals(60f, d.y, eps)
        }
    }

    @Test fun rotationByQuarterTurnMapsAxes() {
        val v = ViewTransform(1f, 0f, 0f, (PI / 2).toFloat())
        val p = v.docToScreen(10f, 0f)
        assertEquals(0f, p.x, eps)
        assertEquals(10f, p.y, eps)
    }

    @Test fun zoomKeepsFocusPointFixed() {
        val focusX = 200f
        val focusY = 150f
        val before = rotated.screenToDoc(focusX, focusY)
        val z = rotated.zoomAround(focusX, focusY, 3f)
        val after = z.docToScreen(before.x, before.y)
        assertEquals(focusX, after.x, eps)
        assertEquals(focusY, after.y, eps)
    }

    @Test fun rotateAroundKeepsFocusPointFixed() {
        val focusX = 320f
        val focusY = 410f
        val before = rotated.screenToDoc(focusX, focusY)
        val r = rotated.rotateAround(focusX, focusY, 0.9f)
        assertEquals(rotated.rotation + 0.9f, r.rotation, 1e-5f)
        val after = r.docToScreen(before.x, before.y)
        assertEquals(focusX, after.x, eps)
        assertEquals(focusY, after.y, eps)
    }

    @Test fun transformByKeepsCentroidOnSameDocPointPlusPan() {
        val fx = 100f
        val fy = 100f
        val d = rotated.screenToDoc(fx, fy)
        val t = rotated.transformBy(fx, fy, panX = 15f, panY = -7f, zoom = 1.5f, rotationDelta = 0.3f)
        val s = t.docToScreen(d.x, d.y)
        assertEquals(fx + 15f, s.x, eps)
        assertEquals(fy - 7f, s.y, eps)
    }

    @Test fun zoomIsClamped() {
        assertEquals(ViewTransform.MAX_SCALE, ViewTransform().zoomAround(0f, 0f, 1000f).scale, eps)
        assertEquals(ViewTransform.MIN_SCALE, ViewTransform().zoomAround(0f, 0f, 0.00001f).scale, 1e-4f)
    }

    @Test fun fitCentersAndContains() {
        val v = ViewTransform.fit(1000f, 2000f, 4000f, 1000f, padding = 50f)
        assertEquals(0.225f, v.scale, eps)
        assertEquals(50f, v.docToScreen(0f, 0f).x, eps)
        assertEquals(950f, v.docToScreen(4000f, 0f).x, eps)
        assertEquals(1000f, v.docToScreen(0f, 500f).y, eps)
        assertEquals(0f, v.rotation, 0f)
    }

    @Test fun centerOnMovesDocCenterToViewCenter() {
        val c = rotated.centerOn(800f, 1200f, 500f, 300f)
        val p = c.docToScreen(250f, 150f)
        assertEquals(400f, p.x, eps)
        assertEquals(600f, p.y, eps)
        assertEquals(rotated.scale, c.scale, 0f)
        assertEquals(rotated.rotation, c.rotation, 0f)
    }

    @Test fun viewportBoundsCoverAllCorners() {
        val b = rotated.viewportBounds(800f, 1200f)
        for ((sx, sy) in listOf(0f to 0f, 800f to 0f, 0f to 1200f, 800f to 1200f)) {
            val d = rotated.screenToDoc(sx, sy)
            assertTrue(d.x >= b.left - eps && d.x <= b.right + eps && d.y >= b.top - eps && d.y <= b.bottom + eps)
        }
    }
}
