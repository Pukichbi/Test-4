package app.nupixel

import app.nupixel.core.CanvasMath
import app.nupixel.core.Guide
import app.nupixel.core.GuideOps
import org.junit.Assert.assertEquals
import org.junit.Test

class CanvasMathTest {
    @Test fun anchorOffsets() {
        assertEquals(0, CanvasMath.anchorOffset(100, 300, 0))
        assertEquals(100, CanvasMath.anchorOffset(100, 300, 1))
        assertEquals(200, CanvasMath.anchorOffset(100, 300, 2))
        assertEquals(-50, CanvasMath.anchorOffset(300, 200, 1)) // shrinking crops around the center
    }

    @Test fun cropShiftsAndDropsGuides() {
        val g = listOf(Guide(true, 100), Guide(true, 600), Guide(false, 50))
        val out = GuideOps.translate(g, dx = -200, dy = -20, newW = 500, newH = 300)
        assertEquals(listOf(Guide(true, 400), Guide(false, 30)), out) // x=100 fell off the left edge
    }

    @Test fun resampleScalesGuides() {
        val out = GuideOps.scale(listOf(Guide(true, 100), Guide(false, 40)), sx = 0.5f, sy = 2f, newW = 500, newH = 500)
        assertEquals(listOf(Guide(true, 50), Guide(false, 80)), out)
    }
}
