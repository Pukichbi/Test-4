# Progress — stage 4 (layers + Project Engine)

**Version:** 0.4.2. **Status: implemented, not yet built or run.** Nothing below is claimed as passed until the
GitHub Actions build and a device test confirm it.

## 4A — groundwork (done)
- Document model: `Session` (UI-independent data: layers, composite, guides, one-step undo) in `AppViewModel.kt`;
  layer types in `layers/Layers.kt`; rendering in `render/Compositor.kt`.
- Format `.nupixel`, version 2 (`docs/PROJECT_FORMAT.md`). Legacy `.npx` (same container) is still read.
- `data/SafeWriter.kt` — tmp → verify → swap with `.bak`, crash recovery (`recover`).
- `data/ProjectArchive.kt` — read + validate archives (empty, truncated, foreign, missing entries, future version).
- Migration framework with a real v1 → v2 step; the source file is never modified by reading.

## 4B — completion
| Area | State |
|------|-------|
| Layers: add, duplicate, delete, rename, reorder, group/ungroup, visibility, lock, opacity, 7 blend modes, masks (add/edit/disable/remove), merge down, text and shape layers, rasterize | written |
| Layers panel UI (list with thumbnails, properties, mask controls) | written |
| Save to `<id>.nupixel` through `SafeWriter`; layers, masks, text/shape parameters, guides, active layer stored | written |
| Open project, import project file, legacy `.npx` read; replaced by `.nupixel` on first save | written |
| Save as (new project, old one untouched) | written |
| Unsaved-changes dot and leave dialog | existing, kept |
| Autosave: 6 s after the last change, at least every 30 s while editing, immediately when the app goes to background; never on every touch; one writer at a time (mutex) | written |
| Restore after restart: dialog on the home screen (Restore / Discard); recovery copy removed on save, leave or discard | written |
| Errors: broken / empty / foreign / future-version / incomplete files give messages, not crashes | written |
| Migration notice: upgraded projects open as "unsaved" with a message | written |

## Automatic tests (JVM, written, **not run by me**; run by GitHub Actions `testDebugUnitTest`)
`SafeWriterTest` (9), `ProjectArchiveTest` (11), `ManifestCodecTest`, `LayerTreeTest` (9), plus earlier tests.

## Not covered by any automatic test
Saving and loading real bitmaps (needs an Android device), compositing and blend modes, autosave timing, the
recovery dialog, the layers panel. These need a manual test on the phone (checklist in `TEST_STATUS.md`).

## Known limits
- Groups cannot be nested; groups have no mask or blend inheritance beyond opacity/blend of the group itself.
- Layers are full-canvas bitmaps: the layer count is limited by memory (message shown when exceeded).
- Blend modes are those of `PorterDuff` (Normal, Multiply, Screen, Overlay, Darken, Lighten, Add).
- Text and shape layers are saved as parameters and redrawn on load; fonts are the system generic families.
- Autosave copies can contain a stroke that was being drawn at the moment of writing.
- One-step undo only (history is stage 5). Undo restores the layer list; text/shape pixels are redrawn from parameters.
- No cloud, no external storage location for projects: files live in the app's private storage; use
  "Export project file" for backups.

## Next action
Build with GitHub Actions, fix compile errors from the Summary page, run the unit tests, then the manual checklist.
