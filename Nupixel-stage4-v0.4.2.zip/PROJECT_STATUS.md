# Project status

**Stage 4 (layers + Project Engine) — code written, not yet built or run.** Version 0.4.2.
Details, checklist and limits: `PROGRESS.md`. Roadmap: `ROADMAP.md`. Decisions: `TECHNICAL_DECISIONS.md`.

**Next action:** build with GitHub Actions, fix compile errors from the Summary page, run unit tests, then the manual
checklist in `TEST_STATUS.md`.
