# Technical decisions

| # | Decision | Reason / consequence |
|---|----------|----------------------|
| 1 | Kotlin + Jetpack Compose, single Gradle module, packages per future engine | Fast to build; split into modules when engines appear (stage 2+). |
| 2 | `AppCompatActivity` as host | Needed for per-app language switching with persistence (`AppCompatDelegate.setApplicationLocales` + `autoStoreLocales`). |
| 3 | Project = zip `.npx` (`manifest.json` + `layers/*.png`) | Documented, inspectable, extensible to many layers; PNG is lossless. See `docs/PROJECT_FORMAT.md`. |
| 4 | Safe save: tmp file → verify → rename with `.bak`, recovered on start | A failed save never destroys the previous version. |
| 5 | `org.json` for the manifest | Built into Android, no plugin; JVM tests use the `org.json` artifact. |
| 6 | Max 8192 px side and ≤24 MP, further capped by heap (`core/Limits.kt`) | One full bitmap is drawn by Compose; above ~100 MB the canvas refuses to draw. Replaced by tiles in stage 2. |
| 7 | Photo Picker / system file dialogs, no storage permissions | Fewer permissions; works offline. |
| 8 | Theme and language stored separately (prefs / AppCompat) | Theme default is dark as required. |
| 9 | Only working UI is shown | No placeholders for layers/tools until they exist. |
| 10 | minSdk 24, targetSdk/compileSdk 35 | Wide device coverage, current platform. |
| 11 | Rendering split: `DocumentLayer` (checkerboard + tiles) and `OverlayLayer` (outline, grid, guides); gestures live in the editor | Editor aids never touch document pixels; later tools add their own overlays. |
| 12 | Tiles of 512 px cut lazily from the bitmap, LRU of 96 per level; half-resolution pyramid levels built in the background | Keeps draw calls and textures small on large documents. Costs up to ~33% extra memory for levels. Tiles are drawn without anti-aliasing to avoid seams. |
| 13 | View transform has rotation; 100% = 1 document px per screen px | Rotation by two-finger twist; reset chip appears when rotated. |
| 14 | Canvas operations (crop / canvas size / resolution) replace the whole bitmap and keep ONE undo step | Real history is stage 5; the single step avoids irreversible edits meanwhile. |
| 15 | Guides stored in `manifest.json` as optional `guides` | Backward compatible, no format version bump. |
| 16 | Crop is numeric (X, Y, W, H), no on-canvas handle yet | Handle-based crop arrives with the stage 3 selection tools. |
| 17 | Tools edit `session.bitmap` in place; every edit first copies the bitmap (snapshot) which becomes the single undo step | Simple and safe until the stage 5 history engine; costs one full copy per edit. No redo yet. |
| 18 | Brush strokes go into a per-stroke layer; the document region is rebuilt as snapshot + layer × opacity | Stroke opacity does not build up where the stroke overlaps itself; the eraser uses the same path with DST_OUT. Costs two extra document-size bitmaps while painting. |
| 19 | One finger = tool, two fingers = pan / zoom / rotate; a second finger cancels the stroke in progress | Same canvas can be painted and navigated without a mode switch. |
| 20 | Selection = Path in document space (rect or lasso polygon); tools clip to it, masks are rendered on demand | Anti-aliased edges, no extra persistent bitmap. Selections are not saved. |
| 21 | Move/Scale/Rotate: pixels are lifted into a floating bitmap, edited with sliders and a drag, applied on Apply or tool change | Pinch stays reserved for the view. |
| 22 | Text is editable until applied, then rasterized into the document | Persistent editable text needs layers (stage 4). |
| 23 | Fill and Remove background use a tolerance flood fill over an IntArray copy on a background thread | Edges are hard (no feathering) — known limit. |
| 24 | Pyramid levels are invalidated and rebuilt (400 ms debounce) after edits; level-0 tiles are invalidated per dirty rectangle | Painting stays responsive; zoomed-out views briefly use full-resolution tiles. |
| 25 | Layers are flat list + `parentId` (one group level), composited bottom to top by `Compositor` into a cached `composite` bitmap | Simple undo/serialization; tools only touch the active layer's bitmap. Cost: one full-size bitmap per raster layer. |
| 26 | Text/shape layers keep parameters; pixels are a cache redrawn on load/edit | Editable after save; no font files stored (system families). |
| 27 | `.nupixel` extension, legacy `.npx` read and replaced on next save | Matches the spec; old files stay readable and untouched until a save succeeds. |
| 28 | Atomic writes in a pure-JVM `SafeWriter`; archive validation in `ProjectArchive` | Failure behaviour is unit-testable without a device. |
| 29 | Autosave to `recovery/<id>.nupixel` (debounce 6 s, tick 30 s, on background), one `Mutex` for all writes, never writes the project file | No stroke-by-stroke I/O; recovery copy is dropped on save/leave/discard. |
