# Test status

| Check | Command | Last result |
|-------|---------|-------------|
| Unit tests (`ViewTransformTest`, `TileGridTest`, `CanvasMathTest`, `ToolMathTest`, `ManifestCodecTest`) | `./gradlew testDebugUnitTest` | **Not run** |
| Debug build | `./gradlew assembleDebug` | **Not run** |
| On-device / emulator run | — | **Not run** |
| Screenshots / visual check | — | **Not done** |
| Launcher icon on device | — | **Not checked** |

## Stage 1 and 2 status correction
Earlier notes said stages 1 and 2 were built and accepted. The GitHub Actions history shows all runs failing (the first 7 runs), so no version has been proven to compile. Last known failure: unresolved `ProjectStore` caused by a nested-comment bug (fixed in 0.3.1).

## Stage 4 (0.4.0) — nothing has been run yet
Automatic (JVM, run by GitHub Actions `testDebugUnitTest`): SafeWriterTest, ProjectArchiveTest, ManifestCodecTest,
LayerTreeTest, ViewTransformTest, TileGridTest, CanvasMathTest, ToolMathTest. Result: **not run by me**.

Manual checklist for the phone:
1. New canvas → add 2 layers, paint on each, change opacity and blend mode, hide one, lock one (painting on it is refused).
2. Add a mask, paint with brush and eraser in mask mode, disable/remove it.
3. Add text and a shape (they appear as layers), edit text, move it, rasterize it.
4. Group a layer, collapse the group, ungroup, merge down.
5. Save → leave → open from Projects: layers, order, masks, text, guides unchanged.
6. Save as new name: both projects exist.
7. Edit, wait ~10 s, force-stop the app → reopen: restore dialog → Restore returns the work. Repeat and choose Discard.
8. Open a project saved by 0.3.x (`.npx`): opens, "upgraded" message, unsaved; save, reopen.
9. Export PNG/JPEG shows the flattened result (masks, opacity, blend modes included).
10. Undo after a stroke, after delete layer, after crop.

Not testable without a device: real PNG layer I/O, compositor output, UI behaviour.
