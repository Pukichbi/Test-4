# Nupixel roadmap

Numbering follows the user's recovery document of the stage 4 work. Stage 4 covers the layer model **and** the
Project Engine, because the project file has to store layers. Items marked in the old roadmap as stage 5
(autosave, recovery, format migration) were pulled into stage 4; undo/redo history stays in stage 5.

| Stage | Content | Status |
|-------|---------|--------|
| 0.5 | Design system, screen plan | done, in use |
| 1 | App foundation, import, save/open, PNG/JPEG export | built and installed by the user |
| 2 | Canvas engine: rotation, tiles, grid, guides, crop/size/resolution | built (0.2.x–0.3.x) |
| 3 | Raster tools | accepted by the user (0.3.3) |
| **4A** | Project Engine groundwork: layer model, format v2, `SafeWriter`, `ProjectArchive`, docs | written |
| **4B** | Layers UI, save / save as / open, autosave, restore after restart, migration notice, tests | written, **not yet built or run** (0.4.0) |
| 5 | Undo / redo history engine, cached states | planned |
| 6 | Colour correction and filters | planned |
| 7 | Digital painting (brush engine v2) | planned |
| 8 | Selection refinement, retouch, liquify | planned |
| 9 | Vector graphics | planned |
| 10 | Typography and design tools | planned |
| 11 | Animation and timeline | planned |
| 12 | 3D | planned |
| 13 | Colour management and print | planned |
| 14+ | Format exchange, batch processing, release | planned |

Stage 4 is complete only when the criteria in `PROGRESS.md` are checked off after a real build and device test.
