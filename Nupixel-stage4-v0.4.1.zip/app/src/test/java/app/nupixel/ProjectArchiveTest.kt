package app.nupixel

import app.nupixel.data.CURRENT_FORMAT_VERSION
import app.nupixel.data.LayerEntry
import app.nupixel.data.ManifestCodec
import app.nupixel.data.ProjectArchive
import app.nupixel.data.ProjectFormatException
import app.nupixel.data.ProjectManifest
import app.nupixel.data.ProjectTooNewException
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class ProjectArchiveTest {
    @get:Rule val tmp = TemporaryFolder()

    private val manifest = ProjectManifest(
        appVersion = "0.4.0", name = "Test", width = 10, height = 5, createdAt = 1L, modifiedAt = 2L,
        layers = listOf(
            LayerEntry("bg", "Background", "raster", "layers/bg.png", maskFile = "layers/bg-mask.png"),
            LayerEntry("t", "Text", "text", null, text = app.nupixel.layers.TextParams("Hi", 1f, 2f, 12f, 0xFF000000.toInt())),
        ),
    )

    private fun zip(name: String, entries: Map<String, ByteArray>): File {
        val f = tmp.newFile(name)
        ZipOutputStream(f.outputStream()).use { z ->
            for ((n, b) in entries) { z.putNextEntry(ZipEntry(n)); z.write(b); z.closeEntry() }
        }
        return f
    }

    private fun valid(): File = zip(
        "ok.nupixel",
        mapOf("manifest.json" to ManifestCodec.encode(manifest).toByteArray(), "layers/bg.png" to byteArrayOf(1), "layers/bg-mask.png" to byteArrayOf(2)),
    )

    private fun expectBroken(f: File) {
        try { ProjectArchive.readManifest(f); fail("expected ProjectFormatException") } catch (e: ProjectFormatException) {
            assertFalse(e is ProjectTooNewException)
        }
        assertFalse(ProjectArchive.isValid(f))
    }

    @Test fun readsAValidArchive() {
        val f = valid()
        assertEquals(manifest, ProjectArchive.readManifest(f))
        assertTrue(ProjectArchive.isValid(f))
    }

    @Test fun emptyFileIsRejected() = expectBroken(tmp.newFile("empty.nupixel"))

    @Test fun missingFileIsRejected() = expectBroken(File(tmp.root, "nope.nupixel"))

    @Test fun randomBytesAreRejected() {
        val f = tmp.newFile("junk.nupixel")
        f.writeBytes(ByteArray(2048) { (it * 31).toByte() })
        expectBroken(f)
    }

    @Test fun truncatedArchiveIsRejected() {
        val bytes = valid().readBytes()
        val f = tmp.newFile("cut.nupixel")
        f.writeBytes(bytes.copyOf(bytes.size / 2))
        expectBroken(f)
    }

    @Test fun archiveWithoutManifestIsRejected() = expectBroken(zip("nomanifest.nupixel", mapOf("layers/bg.png" to byteArrayOf(1))))

    @Test fun manifestOfAnotherFormatIsRejected() =
        expectBroken(zip("foreign.nupixel", mapOf("manifest.json" to "{\"hello\":1}".toByteArray())))

    @Test fun missingLayerDataIsRejectedButManifestStillReadableWithoutCheck() {
        val f = zip("nolayer.nupixel", mapOf("manifest.json" to ManifestCodec.encode(manifest).toByteArray(), "layers/bg.png" to byteArrayOf(1)))
        expectBroken(f) // layers/bg-mask.png is missing
        assertEquals("Test", ProjectArchive.readManifest(f, checkEntries = false).name)
    }

    @Test fun futureVersionGivesTooNewError() {
        val json = JSONObject(ManifestCodec.encode(manifest)).put("formatVersion", CURRENT_FORMAT_VERSION + 1).toString()
        val f = zip("future.nupixel", mapOf("manifest.json" to json.toByteArray()))
        try { ProjectArchive.readManifest(f); fail() } catch (e: ProjectTooNewException) {
            assertEquals(CURRENT_FORMAT_VERSION + 1, e.version)
        }
        try { ProjectArchive.isValid(f); fail() } catch (e: ProjectTooNewException) { }
    }

    @Test fun oldVersionIsMigratedInMemoryAndReportsItsSourceVersion() {
        val v1 = """{"format":"nupixel-project","formatVersion":1,"appVersion":"0.1.0","name":"Old",
            "canvas":{"width":10,"height":5,"colorSpace":"sRGB"},"createdAt":1,"modifiedAt":2,
            "layers":[{"id":"layer-1","name":"Layer 1","type":"raster","file":"layers/layer-1.png","visible":true,"opacity":1.0}]}"""
        val f = zip("old.npx", mapOf("manifest.json" to v1.toByteArray(), "layers/layer-1.png" to byteArrayOf(1)))
        val before = f.readBytes()
        val m = ProjectArchive.readManifest(f)
        assertEquals(1, m.sourceVersion)
        assertEquals(CURRENT_FORMAT_VERSION, m.formatVersion)
        assertEquals("normal", m.layers[0].blend)
        assertTrue(before.contentEquals(f.readBytes())) // reading never modifies the source file
    }

    @Test fun oversizedManifestIsRejected() {
        val big = ByteArray(5 * 1024 * 1024) { ' '.code.toByte() }
        expectBroken(zip("big.nupixel", mapOf("manifest.json" to big)))
    }
}
