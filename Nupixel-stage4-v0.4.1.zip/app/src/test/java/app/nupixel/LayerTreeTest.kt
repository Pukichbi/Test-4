package app.nupixel

import app.nupixel.layers.Layer
import app.nupixel.layers.LayerTree
import app.nupixel.layers.LayerType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class LayerTreeTest {
    private fun l(id: String, type: LayerType = LayerType.RASTER, parent: String? = null) =
        Layer(id = id, name = id, type = type, parentId = parent)

    private fun ids(list: List<Layer>) = list.map { it.id }

    private val abc = listOf(l("a"), l("b"), l("c"))

    @Test fun moveSwapsWithSibling() {
        assertEquals(listOf("b", "a", "c"), ids(LayerTree.move(abc, "a", up = true)!!))
        assertEquals(listOf("a", "c", "b"), ids(LayerTree.move(abc, "c", up = false)!!))
        assertNull(LayerTree.move(abc, "c", up = true))
        assertNull(LayerTree.move(abc, "a", up = false))
    }

    @Test fun groupWrapsLayerAndKeepsPosition() {
        val out = LayerTree.group(abc, "b", l("g", LayerType.GROUP))!!
        assertEquals(listOf("a", "b", "g", "c"), ids(out))
        assertEquals("g", out.first { it.id == "b" }.parentId)
        // the only member of its group cannot be moved among siblings
        assertNull(LayerTree.move(out, "b", up = true))
    }

    @Test fun groupRefusesNestingAndGroups() {
        val grouped = LayerTree.group(abc, "b", l("g", LayerType.GROUP))!!
        assertNull(LayerTree.group(grouped, "b", l("g2", LayerType.GROUP)))
        assertNull(LayerTree.group(grouped, "g", l("g2", LayerType.GROUP)))
    }

    @Test fun ungroupRestoresChildrenInPlace() {
        val grouped = LayerTree.group(abc, "b", l("g", LayerType.GROUP))!!
        val out = LayerTree.ungroup(grouped, "g")
        assertEquals(listOf("a", "b", "c"), ids(out))
        assertNull(out.first { it.id == "b" }.parentId)
    }

    @Test fun removingGroupRemovesItsChildren() {
        val grouped = LayerTree.group(abc, "b", l("g", LayerType.GROUP))!!
        assertEquals(listOf("a", "c"), ids(LayerTree.remove(grouped, "g")))
        assertEquals(listOf("a", "g", "c"), ids(LayerTree.remove(grouped, "b")))
    }

    @Test fun removeFromGroupPutsLayerAboveGroup() {
        val grouped = LayerTree.group(abc, "b", l("g", LayerType.GROUP))!!
        val out = LayerTree.removeFromGroup(grouped, "b")!!
        assertEquals(listOf("a", "g", "b", "c"), ids(out))
        assertNull(out.first { it.id == "b" }.parentId)
        assertNull(LayerTree.removeFromGroup(abc, "a"))
    }

    @Test fun addToGroupOnlyForPlainLayers() {
        val withGroup = listOf(l("a"), l("g", LayerType.GROUP), l("c"))
        val out = LayerTree.addToGroup(withGroup, "a", "g")!!
        assertEquals("g", out.first { it.id == "a" }.parentId)
        assertNull(LayerTree.addToGroup(withGroup, "g", "g"))
        assertNull(LayerTree.addToGroup(withGroup, "a", "c"))
    }

    @Test fun rowsAreTopFirstWithIndentedChildren() {
        val grouped = LayerTree.group(abc, "b", l("g", LayerType.GROUP))!!
        val rows = LayerTree.rows(grouped)
        assertEquals(listOf("c", "g", "b", "a"), rows.map { it.layer.id })
        assertEquals(listOf(0, 0, 1, 0), rows.map { it.depth })
        val collapsed = grouped.map { if (it.id == "g") it.copy(expanded = false) else it }
        assertEquals(listOf("c", "g", "a"), LayerTree.rows(collapsed).map { it.layer.id })
    }

    @Test fun nextActiveAfterDelete() {
        val remaining = LayerTree.remove(abc, "b")
        assertEquals("a", LayerTree.nextActive(abc, "b", remaining))
        assertEquals("b", LayerTree.nextActive(abc, "a", LayerTree.remove(abc, "a")))
        assertNull(LayerTree.nextActive(abc, "a", emptyList()))
    }
}
