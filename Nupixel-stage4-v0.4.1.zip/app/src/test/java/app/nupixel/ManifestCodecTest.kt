package app.nupixel

import app.nupixel.core.Guide
import app.nupixel.layers.ShapeParams
import app.nupixel.layers.TextParams
import app.nupixel.data.CURRENT_FORMAT_VERSION
import app.nupixel.data.LayerEntry
import app.nupixel.data.ManifestCodec
import app.nupixel.data.ProjectFormatException
import app.nupixel.data.ProjectManifest
import app.nupixel.data.ProjectTooNewException
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.fail
import org.junit.Test

class ManifestCodecTest {
    private val sample = ProjectManifest(
        appVersion = "0.1.0", name = "Тест / Test", width = 1920, height = 1080,
        createdAt = 1L, modifiedAt = 2L,
        layers = listOf(LayerEntry("layer-1", "Layer 1", "raster", "layers/layer-1.png", visible = false, opacity = 0.5f)),
    )

    @Test fun roundTrip() {
        val back = ManifestCodec.decode(ManifestCodec.encode(sample))
        assertEquals(sample, back)
        assertEquals(CURRENT_FORMAT_VERSION, back.formatVersion)
    }

    @Test fun guidesRoundTripAndAreOptional() {
        val withGuides = sample.copy(guides = listOf(Guide(true, 960), Guide(false, 540)))
        assertEquals(withGuides, ManifestCodec.decode(ManifestCodec.encode(withGuides)))
        val old = JSONObject(ManifestCodec.encode(sample))
        old.remove("guides")
        assertEquals(emptyList<Guide>(), ManifestCodec.decode(old.toString()).guides)
    }

    @Test fun layerFeaturesRoundTrip() {
        val m = sample.copy(
            layers = listOf(
                LayerEntry("bg", "Background", "raster", "layers/bg.png", maskFile = "layers/bg-mask.png", maskEnabled = false, locked = true, blend = "multiply", parentId = "grp"),
                LayerEntry("grp", "Group", "group", null, opacity = 0.4f, expanded = false),
                LayerEntry("t1", "Text", "text", null, text = TextParams("Hello", 10f, 20f, 48f, 0xFF112233.toInt(), bold = true, italic = true, font = "serif")),
                LayerEntry("s1", "Shape", "shape", null, shape = ShapeParams("rect", 1f, 2f, 30f, 40f, 0xFFFF0000.toInt(), 5f, true, 0.5f)),
            ),
            activeLayerId = "t1",
        )
        assertEquals(m, ManifestCodec.decode(ManifestCodec.encode(m)))
    }

    @Test fun version1ProjectsAreMigrated() {
        val v1 = """{"format":"nupixel-project","formatVersion":1,"appVersion":"0.1.0","name":"Old",
            "canvas":{"width":10,"height":5,"colorSpace":"sRGB"},"createdAt":1,"modifiedAt":2,
            "layers":[{"id":"layer-1","name":"Layer 1","type":"raster","file":"layers/layer-1.png","visible":true,"opacity":1.0}]}"""
        val m = ManifestCodec.decode(v1)
        assertEquals(CURRENT_FORMAT_VERSION, m.formatVersion)
        assertEquals(1, m.sourceVersion)
        assertEquals("normal", m.layers[0].blend)
        assertEquals(false, m.layers[0].locked)
        assertEquals(emptyList<Guide>(), m.guides)
    }

    @Test fun rejectsUnsafeLayerIdsAndBrokenLayers() {
        val badId = JSONObject(ManifestCodec.encode(sample))
        badId.getJSONArray("layers").getJSONObject(0).put("id", "../x")
        try { ManifestCodec.decode(badId.toString()); fail() } catch (e: ProjectFormatException) { }
        val noParams = JSONObject(ManifestCodec.encode(sample))
        noParams.getJSONArray("layers").getJSONObject(0).put("type", "text").remove("file")
        try { ManifestCodec.decode(noParams.toString()); fail() } catch (e: ProjectFormatException) { }
        val onlyGroups = JSONObject(ManifestCodec.encode(sample))
        onlyGroups.getJSONArray("layers").getJSONObject(0).put("type", "group").remove("file")
        try { ManifestCodec.decode(onlyGroups.toString()); fail() } catch (e: ProjectFormatException) { }
    }

    @Test fun rejectsNewerVersion() {
        val json = JSONObject(ManifestCodec.encode(sample)).put("formatVersion", CURRENT_FORMAT_VERSION + 1).toString()
        try { ManifestCodec.decode(json); fail() } catch (e: ProjectTooNewException) { assertEquals(CURRENT_FORMAT_VERSION + 1, e.version) }
    }

    @Test fun rejectsForeignJson() {
        try { ManifestCodec.decode("{\"hello\":1}"); fail() } catch (e: ProjectFormatException) { assertFalse(e is ProjectTooNewException) }
    }

    @Test fun rejectsGarbage() {
        try { ManifestCodec.decode("not json"); fail() } catch (e: ProjectFormatException) { }
    }

    @Test fun rejectsPathTraversalInLayerFile() {
        val bad = JSONObject(ManifestCodec.encode(sample))
        bad.getJSONArray("layers").getJSONObject(0).put("file", "layers/../../evil.png")
        try { ManifestCodec.decode(bad.toString()); fail() } catch (e: ProjectFormatException) { }
    }

    @Test fun rejectsEmptyLayersAndBadCanvas() {
        val noLayers = JSONObject(ManifestCodec.encode(sample)).put("layers", org.json.JSONArray())
        try { ManifestCodec.decode(noLayers.toString()); fail() } catch (e: ProjectFormatException) { }
        val badCanvas = JSONObject(ManifestCodec.encode(sample))
        badCanvas.getJSONObject("canvas").put("width", 0)
        try { ManifestCodec.decode(badCanvas.toString()); fail() } catch (e: ProjectFormatException) { }
    }
}
