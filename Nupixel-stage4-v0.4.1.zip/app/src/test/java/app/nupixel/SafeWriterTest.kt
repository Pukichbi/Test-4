package app.nupixel

import app.nupixel.data.SafeWriter
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File
import java.io.IOException

class SafeWriterTest {
    @get:Rule val tmp = TemporaryFolder()

    private fun write(f: File, text: String, verify: (File) -> Boolean = { true }) =
        SafeWriter.write(f, verify) { it.write(text.toByteArray()) }

    private fun leftovers(dir: File) = dir.listFiles().orEmpty().map { it.name }.filter { it.endsWith(".tmp") || it.endsWith(".bak") }

    @Test fun createsNewFileWithoutLeftovers() {
        val f = File(tmp.root, "a.nupixel")
        write(f, "one")
        assertEquals("one", f.readText())
        assertTrue(leftovers(tmp.root).isEmpty())
    }

    @Test fun createsMissingDirectory() {
        val f = File(tmp.root, "sub/dir/a.nupixel")
        write(f, "x")
        assertEquals("x", f.readText())
    }

    @Test fun replacesExistingFile() {
        val f = File(tmp.root, "a.nupixel")
        write(f, "old")
        write(f, "new")
        assertEquals("new", f.readText())
        assertTrue(leftovers(tmp.root).isEmpty())
    }

    @Test fun failedWriteKeepsPreviousVersion() {
        val f = File(tmp.root, "a.nupixel")
        write(f, "good")
        try {
            SafeWriter.write(f, { true }) { out ->
                out.write("half a fi".toByteArray())
                throw IOException("disk full")
            }
            fail()
        } catch (e: IOException) {
            assertEquals("disk full", e.message)
        }
        assertEquals("good", f.readText())
        assertTrue(leftovers(tmp.root).isEmpty())
    }

    @Test fun failedVerificationKeepsPreviousVersion() {
        val f = File(tmp.root, "a.nupixel")
        write(f, "good")
        try {
            write(f, "corrupt") { false }
            fail()
        } catch (e: IOException) {
        }
        assertEquals("good", f.readText())
        assertTrue(leftovers(tmp.root).isEmpty())
    }

    @Test fun failedFirstWriteLeavesNothing() {
        val f = File(tmp.root, "a.nupixel")
        try {
            SafeWriter.write(f, { true }) { throw IOException("boom") }
            fail()
        } catch (e: IOException) {
        }
        assertFalse(f.exists())
        assertTrue(leftovers(tmp.root).isEmpty())
    }

    @Test fun verifierSeesTheCompleteTempFile() {
        val f = File(tmp.root, "a.nupixel")
        var seen = ""
        write(f, "payload") { seen = it.readText(); true }
        assertEquals("payload", seen)
    }

    @Test fun recoverRestoresLastGoodVersionAfterCrashBetweenRenames() {
        // crash after the old file was moved aside but before the new one was moved in
        File(tmp.root, "a.nupixel.bak").writeText("last good")
        File(tmp.root, "a.nupixel.tmp").writeText("partial")
        SafeWriter.recover(tmp.root)
        assertEquals("last good", File(tmp.root, "a.nupixel").readText())
        assertTrue(leftovers(tmp.root).isEmpty())
    }

    @Test fun recoverDropsStaleBackupWhenTargetExists() {
        File(tmp.root, "a.nupixel").writeText("current")
        File(tmp.root, "a.nupixel.bak").writeText("older")
        SafeWriter.recover(tmp.root)
        assertEquals("current", File(tmp.root, "a.nupixel").readText())
        assertTrue(leftovers(tmp.root).isEmpty())
    }
}
