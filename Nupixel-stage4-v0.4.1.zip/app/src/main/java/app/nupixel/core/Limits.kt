package app.nupixel.core

/** Device-dependent limits for document size. */
object Limits {
    const val MAX_SIDE = 8192
    private const val HARD_MAX_PIXELS = 24_000_000L // 96 MB as ARGB_8888

    /** Pixels allowed for a single in-memory layer, from the app heap limit (~1/6 of heap for one bitmap). */
    fun maxPixels(): Long {
        val budgetBytes = Runtime.getRuntime().maxMemory() / 6
        return (budgetBytes / 4).coerceIn(2_000_000L, HARD_MAX_PIXELS)
    }

    fun maxMegapixels(): Int = (maxPixels() / 1_000_000L).toInt()

    /** True when [bytesPerPixel] bytes for every pixel of a [w] x [h] document fit the memory budget (about half the heap). */
    fun fitsBytes(w: Int, h: Int, bytesPerPixel: Long): Boolean =
        w.toLong() * h * bytesPerPixel <= Runtime.getRuntime().maxMemory() * 55 / 100

    fun fits(w: Int, h: Int): Boolean =
        w in 1..MAX_SIDE && h in 1..MAX_SIDE && w.toLong() * h <= maxPixels()
}
