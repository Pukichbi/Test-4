package app.nupixel.render

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import app.nupixel.layers.ShapeParams
import app.nupixel.tools.ShapeDraft
import app.nupixel.tools.Tool
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

object ShapeRenderer {
    fun normalized(d: ShapeDraft) = RectF(min(d.x0, d.x1), min(d.y0, d.y1), max(d.x0, d.x1), max(d.y0, d.y1))

    fun toParams(d: ShapeDraft, color: Int, opacity: Float, stroke: Float, filled: Boolean) = ShapeParams(
        kind = when (d.tool) { Tool.LINE -> "line"; Tool.RECT -> "rect"; else -> "ellipse" },
        x0 = d.x0, y0 = d.y0, x1 = d.x1, y1 = d.y1,
        color = color, stroke = stroke, filled = filled && d.tool != Tool.LINE, opacity = opacity,
    )

    /** Draws a shape and returns the document rectangle it touched. */
    fun drawParams(canvas: Canvas, p: ShapeParams): Rect {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = (p.color and 0x00FFFFFF) or ((p.opacity * 255f).roundToInt().coerceIn(0, 255) shl 24)
            style = if (p.filled && p.kind != "line") Paint.Style.FILL else Paint.Style.STROKE
            strokeWidth = p.stroke
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }
        val r = RectF(min(p.x0, p.x1), min(p.y0, p.y1), max(p.x0, p.x1), max(p.y0, p.y1))
        when (p.kind) {
            "line" -> canvas.drawLine(p.x0, p.y0, p.x1, p.y1, paint)
            "rect" -> canvas.drawRect(r, paint)
            else -> canvas.drawOval(r, paint)
        }
        return dirtyRect(p)
    }

    fun dirtyRect(p: ShapeParams): Rect {
        val pad = p.stroke + 2f
        return Rect(
            floor(min(p.x0, p.x1) - pad).toInt(), floor(min(p.y0, p.y1) - pad).toInt(),
            ceil(max(p.x0, p.x1) + pad).toInt(), ceil(max(p.y0, p.y1) + pad).toInt(),
        )
    }
}
