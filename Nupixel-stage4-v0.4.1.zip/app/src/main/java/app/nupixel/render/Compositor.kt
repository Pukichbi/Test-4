package app.nupixel.render

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Rect
import app.nupixel.layers.Blend
import app.nupixel.layers.Layer
import app.nupixel.layers.LayerType
import kotlin.math.roundToInt

/**
 * Flattens the layer stack (bottom to top) into one bitmap: visibility, masks, opacity, blend modes
 * and one level of groups. Works on any sub-rectangle so painting only recomposes what changed.
 */
object Compositor {
    private fun mode(b: Blend): PorterDuff.Mode? = when (b) {
        Blend.NORMAL -> null
        Blend.MULTIPLY -> PorterDuff.Mode.MULTIPLY
        Blend.SCREEN -> PorterDuff.Mode.SCREEN
        Blend.OVERLAY -> PorterDuff.Mode.OVERLAY
        Blend.DARKEN -> PorterDuff.Mode.DARKEN
        Blend.LIGHTEN -> PorterDuff.Mode.LIGHTEN
        Blend.ADD -> PorterDuff.Mode.ADD
    }

    private fun layerPaint(l: Layer) = Paint().apply {
        alpha = (l.opacity * 255f).roundToInt().coerceIn(0, 255)
        mode(l.blend)?.let { xfermode = PorterDuffXfermode(it) }
    }

    /** Recomposes [region] (whole bitmap when null) of [out] from [layers]. */
    fun composite(layers: List<Layer>, out: Bitmap, region: Rect?) {
        val r = Rect(0, 0, out.width, out.height)
        if (region != null && !r.intersect(region)) return
        val c = Canvas(out)
        c.save()
        c.clipRect(r)
        c.drawColor(0, PorterDuff.Mode.CLEAR)
        drawChildren(c, layers, null, r)
        c.restore()
    }

    private fun drawChildren(c: Canvas, all: List<Layer>, parent: String?, r: Rect) {
        for (l in all) if (l.parentId == parent && l.visible) drawLayer(c, all, l, r)
    }

    private fun drawLayer(c: Canvas, all: List<Layer>, l: Layer, r: Rect) {
        if (l.type != LayerType.GROUP) {
            drawBitmapLayer(c, l, r)
            return
        }
        if (l.opacity <= 0f) return
        val tmp = try {
            Bitmap.createBitmap(r.width(), r.height(), Bitmap.Config.ARGB_8888)
        } catch (e: OutOfMemoryError) {
            return
        }
        val tc = Canvas(tmp)
        tc.translate(-r.left.toFloat(), -r.top.toFloat())
        drawChildren(tc, all, l.id, r)
        c.drawBitmap(tmp, r.left.toFloat(), r.top.toFloat(), layerPaint(l))
        tmp.recycle()
    }

    /** Draws one raster-backed layer (with its mask, opacity and blend mode) over [r] of [c]. */
    fun drawBitmapLayer(c: Canvas, l: Layer, r: Rect) {
        val bmp = l.bitmap ?: return
        val mask = if (l.maskEnabled) l.mask else null
        if (mask == null) {
            c.drawBitmap(bmp, r, r, layerPaint(l))
            return
        }
        val tmp = try {
            Bitmap.createBitmap(r.width(), r.height(), Bitmap.Config.ARGB_8888)
        } catch (e: OutOfMemoryError) {
            return
        }
        val tc = Canvas(tmp)
        val dst = Rect(0, 0, r.width(), r.height())
        tc.drawBitmap(bmp, r, dst, null)
        tc.drawBitmap(mask, r, dst, Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN) })
        c.drawBitmap(tmp, r.left.toFloat(), r.top.toFloat(), layerPaint(l))
        tmp.recycle()
    }

    /** Draws [upper] into [lower]'s own pixels (Merge down). Returns the changed area. */
    fun mergeInto(lower: Bitmap, upper: Layer): Rect {
        val r = Rect(0, 0, lower.width, lower.height)
        drawBitmapLayer(Canvas(lower), upper, r)
        return r
    }
}
