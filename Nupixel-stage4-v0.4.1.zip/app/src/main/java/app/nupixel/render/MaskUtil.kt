package app.nupixel.render

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint

/** Layer masks are ALPHA_8 bitmaps (255 = visible). PNG storage uses white ARGB with the mask as alpha. */
object MaskUtil {
    fun newMask(w: Int, h: Int, visible: Boolean): Bitmap {
        val m = Bitmap.createBitmap(w, h, Bitmap.Config.ALPHA_8)
        m.eraseColor(if (visible) 0xFF000000.toInt() else 0)
        return m
    }

    fun toArgb(mask: Bitmap): Bitmap {
        val out = Bitmap.createBitmap(mask.width, mask.height, Bitmap.Config.ARGB_8888)
        Canvas(out).drawBitmap(mask, 0f, 0f, Paint().apply { color = Color.WHITE })
        return out
    }

    fun fromArgb(argb: Bitmap): Bitmap {
        val out = Bitmap.createBitmap(argb.width, argb.height, Bitmap.Config.ALPHA_8)
        Canvas(out).drawBitmap(argb, 0f, 0f, null)
        return out
    }

    fun copy(mask: Bitmap): Bitmap = mask.copy(Bitmap.Config.ALPHA_8, true)
}
