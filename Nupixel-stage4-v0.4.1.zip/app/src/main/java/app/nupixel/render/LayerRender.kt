package app.nupixel.render

import android.graphics.Canvas
import android.graphics.Rect
import app.nupixel.layers.Layer
import app.nupixel.layers.LayerType

/** Text and shape layers are derived data: their bitmap is always redrawn from the parameters. */
object LayerRender {
    fun render(l: Layer) {
        val bmp = l.bitmap ?: return
        when (l.type) {
            LayerType.TEXT -> {
                bmp.eraseColor(0)
                l.text?.let { TextRenderer.draw(Canvas(bmp), it) }
            }
            LayerType.SHAPE -> {
                bmp.eraseColor(0)
                l.shape?.let { ShapeRenderer.drawParams(Canvas(bmp), it) }
            }
            else -> Unit
        }
    }

    /** Area covered by a text/shape layer's content, for partial recomposition. */
    fun contentBounds(l: Layer): Rect? = when (l.type) {
        LayerType.TEXT -> l.text?.let { TextRenderer.dirtyRect(it) }
        LayerType.SHAPE -> l.shape?.let { ShapeRenderer.dirtyRect(it) }
        else -> null
    }
}
