package app.nupixel.layers

import android.graphics.Bitmap

enum class LayerType(val key: String) {
    RASTER("raster"), TEXT("text"), SHAPE("shape"), GROUP("group");

    companion object {
        fun fromKey(k: String): LayerType = entries.firstOrNull { it.key == k } ?: RASTER
    }
}

enum class Blend(val key: String) {
    NORMAL("normal"), MULTIPLY("multiply"), SCREEN("screen"), OVERLAY("overlay"),
    DARKEN("darken"), LIGHTEN("lighten"), ADD("add");

    companion object {
        fun fromKey(k: String): Blend = entries.firstOrNull { it.key == k } ?: NORMAL
    }
}

/** Parameters of an editable text layer. Pixels are always re-rendered from these. */
data class TextParams(
    val text: String,
    val x: Float,
    val y: Float,
    val size: Float,
    val color: Int,
    val bold: Boolean = false,
    val italic: Boolean = false,
    val font: String = "sans", // sans | serif | mono
) {
    fun shifted(dx: Float, dy: Float) = copy(x = x + dx, y = y + dy)
    fun scaled(sx: Float, sy: Float) = copy(x = x * sx, y = y * sy, size = size * (sx + sy) / 2f)
}

/** Parameters of a shape layer. [kind] = line | rect | ellipse. */
data class ShapeParams(
    val kind: String,
    val x0: Float,
    val y0: Float,
    val x1: Float,
    val y1: Float,
    val color: Int,
    val stroke: Float,
    val filled: Boolean,
    val opacity: Float,
) {
    fun shifted(dx: Float, dy: Float) = copy(x0 = x0 + dx, y0 = y0 + dy, x1 = x1 + dx, y1 = y1 + dy)
    fun scaled(sx: Float, sy: Float) = copy(x0 = x0 * sx, y0 = y0 * sy, x1 = x1 * sx, y1 = y1 * sy, stroke = stroke * (sx + sy) / 2f)
}

/**
 * One layer. Raster, text and shape layers own a document-sized ARGB [bitmap] (text and shape bitmaps are
 * caches rendered from their parameters); groups have none. [mask] is an ALPHA_8 bitmap, 255 = visible.
 * [parentId] points to a group; groups cannot be nested.
 */
data class Layer(
    val id: String,
    val name: String,
    val type: LayerType,
    val visible: Boolean = true,
    val locked: Boolean = false,
    val opacity: Float = 1f,
    val blend: Blend = Blend.NORMAL,
    val bitmap: Bitmap? = null,
    val mask: Bitmap? = null,
    val maskEnabled: Boolean = true,
    val parentId: String? = null,
    val expanded: Boolean = true,
    val text: TextParams? = null,
    val shape: ShapeParams? = null,
)

/** Pure list operations. The list is ordered bottom to top; z-order is the order among siblings. */
object LayerTree {
    data class Row(val layer: Layer, val depth: Int)

    fun indexOf(layers: List<Layer>, id: String) = layers.indexOfFirst { it.id == id }

    /** Removes [id] and, for a group, everything inside it. */
    fun remove(layers: List<Layer>, id: String): List<Layer> {
        val target = layers.firstOrNull { it.id == id } ?: return layers
        return layers.filter { it.id != id && !(target.type == LayerType.GROUP && it.parentId == id) }
    }

    /** Swap with the next sibling above ([up]) or below. Null when already at the end. */
    fun move(layers: List<Layer>, id: String, up: Boolean): List<Layer>? {
        val me = layers.firstOrNull { it.id == id } ?: return null
        val sib = layers.indices.filter { layers[it].parentId == me.parentId }
        val pos = sib.indexOfFirst { layers[it].id == id }
        val other = if (up) pos + 1 else pos - 1
        if (pos < 0 || other !in sib.indices) return null
        val out = layers.toMutableList()
        val a = sib[pos]
        val b = sib[other]
        val t = out[a]
        out[a] = out[b]
        out[b] = t
        return out
    }

    /** Wraps layer [id] in [group] (same z-position). Null when the layer is already inside a group. */
    fun group(layers: List<Layer>, id: String, group: Layer): List<Layer>? {
        val i = indexOf(layers, id)
        if (i < 0) return null
        val l = layers[i]
        if (l.parentId != null || l.type == LayerType.GROUP) return null
        val out = layers.toMutableList()
        out[i] = l.copy(parentId = group.id)
        out.add(i + 1, group.copy(parentId = null))
        return out
    }

    /** Replaces the group by its children at the group's position, so the picture does not change. */
    fun ungroup(layers: List<Layer>, groupId: String): List<Layer> {
        val out = ArrayList<Layer>()
        for (l in layers) {
            when {
                l.id == groupId -> layers.filter { it.parentId == groupId }.forEach { out.add(it.copy(parentId = l.parentId)) }
                l.parentId == groupId -> Unit
                else -> out.add(l)
            }
        }
        return out
    }

    fun addToGroup(layers: List<Layer>, id: String, groupId: String): List<Layer>? {
        val me = layers.firstOrNull { it.id == id } ?: return null
        val g = layers.firstOrNull { it.id == groupId } ?: return null
        if (me.type == LayerType.GROUP || g.type != LayerType.GROUP || g.parentId != null) return null
        return layers.map { if (it.id == id) it.copy(parentId = groupId) else it }
    }

    /** Moves the layer out of its group, directly above the group. */
    fun removeFromGroup(layers: List<Layer>, id: String): List<Layer>? {
        val me = layers.firstOrNull { it.id == id } ?: return null
        val gid = me.parentId ?: return null
        val without = layers.filter { it.id != id }
        val gi = without.indexOfFirst { it.id == gid }
        if (gi < 0) return null
        val out = without.toMutableList()
        out.add(gi + 1, me.copy(parentId = without[gi].parentId))
        return out
    }

    /** Layer panel order: top first, children of expanded groups indented under their group. */
    fun rows(layers: List<Layer>): List<Row> {
        val out = ArrayList<Row>()
        for (r in layers.filter { it.parentId == null }.asReversed()) {
            out.add(Row(r, 0))
            if (r.type == LayerType.GROUP && r.expanded) {
                layers.filter { it.parentId == r.id }.asReversed().forEach { out.add(Row(it, 1)) }
            }
        }
        return out
    }

    /** Which layer to select after [removedId] was deleted from [old] giving [new]. */
    fun nextActive(old: List<Layer>, removedId: String, new: List<Layer>): String? {
        if (new.isEmpty()) return null
        val i = indexOf(old, removedId)
        val candidate = new[(i - 1).coerceIn(0, new.lastIndex)]
        return (if (candidate.type == LayerType.GROUP) new.firstOrNull { it.type != LayerType.GROUP } ?: candidate else candidate).id
    }
}
