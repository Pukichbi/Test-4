package app.nupixel.data

import app.nupixel.core.Guide
import app.nupixel.layers.ShapeParams
import app.nupixel.layers.TextParams
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

const val CURRENT_FORMAT_VERSION = 2
const val MANIFEST_ENTRY = "manifest.json"
private const val FORMAT_ID = "nupixel-project"
private val SAFE_ID = Regex("[A-Za-z0-9_-]{1,64}")

/**
 * One layer in the manifest. [type] = raster | text | shape | group. Raster layers store a PNG ([file]);
 * text and shape layers store only their parameters and are redrawn on load; groups store neither.
 * [maskFile] is a PNG whose alpha channel is the mask.
 */
data class LayerEntry(
    val id: String,
    val name: String,
    val type: String,
    val file: String?,
    val visible: Boolean = true,
    val locked: Boolean = false,
    val opacity: Float = 1f,
    val blend: String = "normal",
    val maskFile: String? = null,
    val maskEnabled: Boolean = true,
    val parentId: String? = null,
    val expanded: Boolean = true,
    val text: TextParams? = null,
    val shape: ShapeParams? = null,
)

data class ProjectManifest(
    val formatVersion: Int = CURRENT_FORMAT_VERSION,
    val appVersion: String,
    val name: String,
    val width: Int,
    val height: Int,
    val colorSpace: String = "sRGB",
    val createdAt: Long,
    val modifiedAt: Long,
    val layers: List<LayerEntry>,
    val guides: List<Guide> = emptyList(),
    val activeLayerId: String? = null,
    /** Format version found in the file before migration (equals [formatVersion] for current files). Not stored. */
    val sourceVersion: Int = CURRENT_FORMAT_VERSION,
)

open class ProjectFormatException(message: String) : Exception(message)
class ProjectTooNewException(val version: Int) : ProjectFormatException("Project format $version is newer than supported $CURRENT_FORMAT_VERSION")

/** Reads and writes manifest.json; upgrades older format versions step by step. */
object ManifestCodec {
    /** migrations[n] upgrades a version-n document to version n+1. */
    private val migrations: Map<Int, (JSONObject) -> JSONObject> = mapOf(
        // v1 -> v2: layers gained "locked" and "blend" (plus masks, groups, text and shape layers, all optional).
        1 to { j: JSONObject ->
            val arr = j.getJSONArray("layers")
            for (i in 0 until arr.length()) {
                val l = arr.getJSONObject(i)
                if (!l.has("locked")) l.put("locked", false)
                if (!l.has("blend")) l.put("blend", "normal")
            }
            j
        },
    )

    fun encode(m: ProjectManifest): String {
        val layers = JSONArray()
        m.layers.forEach { e ->
            val o = JSONObject()
                .put("id", e.id).put("name", e.name).put("type", e.type)
                .put("visible", e.visible).put("locked", e.locked)
                .put("opacity", e.opacity.toDouble()).put("blend", e.blend)
                .put("maskEnabled", e.maskEnabled).put("expanded", e.expanded)
            e.file?.let { o.put("file", it) }
            e.maskFile?.let { o.put("maskFile", it) }
            e.parentId?.let { o.put("parent", it) }
            e.text?.let { t ->
                o.put(
                    "textParams",
                    JSONObject().put("text", t.text).put("x", t.x.toDouble()).put("y", t.y.toDouble())
                        .put("size", t.size.toDouble()).put("color", t.color).put("bold", t.bold)
                        .put("italic", t.italic).put("font", t.font),
                )
            }
            e.shape?.let { s ->
                o.put(
                    "shapeParams",
                    JSONObject().put("kind", s.kind).put("x0", s.x0.toDouble()).put("y0", s.y0.toDouble())
                        .put("x1", s.x1.toDouble()).put("y1", s.y1.toDouble()).put("color", s.color)
                        .put("stroke", s.stroke.toDouble()).put("filled", s.filled).put("opacity", s.opacity.toDouble()),
                )
            }
            layers.put(o)
        }
        val root = JSONObject()
            .put("format", FORMAT_ID)
            .put("formatVersion", m.formatVersion)
            .put("appVersion", m.appVersion)
            .put("name", m.name)
            .put("canvas", JSONObject().put("width", m.width).put("height", m.height).put("colorSpace", m.colorSpace))
            .put("createdAt", m.createdAt)
            .put("modifiedAt", m.modifiedAt)
            .put("layers", layers)
            .put("guides", JSONArray().also { arr ->
                m.guides.forEach { arr.put(JSONObject().put("o", if (it.vertical) "v" else "h").put("p", it.position)) }
            })
        m.activeLayerId?.let { root.put("activeLayer", it) }
        return root.toString(2)
    }

    private fun checkPath(p: String) {
        if (!p.startsWith("layers/") || p.contains("..")) throw ProjectFormatException("Invalid layer path")
    }

    fun decode(text: String): ProjectManifest {
        try {
            var json = JSONObject(text)
            if (json.optString("format") != FORMAT_ID) throw ProjectFormatException("Not a Nupixel project")
            var version = json.optInt("formatVersion", -1)
            val sourceVersion = version
            if (version < 1) throw ProjectFormatException("Missing format version")
            if (version > CURRENT_FORMAT_VERSION) throw ProjectTooNewException(version)
            while (version < CURRENT_FORMAT_VERSION) {
                val step = migrations[version] ?: throw ProjectFormatException("No migration from v$version")
                json = step(json)
                version++
                json.put("formatVersion", version)
            }
            val canvas = json.getJSONObject("canvas")
            val width = canvas.getInt("width")
            val height = canvas.getInt("height")
            if (width < 1 || height < 1) throw ProjectFormatException("Invalid canvas size")
            val arr = json.getJSONArray("layers")
            val layers = (0 until arr.length()).map {
                val l = arr.getJSONObject(it)
                val id = l.getString("id")
                if (!SAFE_ID.matches(id)) throw ProjectFormatException("Invalid layer id")
                val type = l.getString("type")
                if (type !in setOf("raster", "text", "shape", "group")) throw ProjectFormatException("Unknown layer type")
                val file = if (l.has("file")) l.getString("file") else null
                val maskFile = if (l.has("maskFile")) l.getString("maskFile") else null
                file?.let { f -> checkPath(f) }
                maskFile?.let { f -> checkPath(f) }
                if (type == "raster" && file == null) throw ProjectFormatException("Raster layer without image")
                val tp = l.optJSONObject("textParams")?.let { t ->
                    TextParams(
                        text = t.getString("text"), x = t.getDouble("x").toFloat(), y = t.getDouble("y").toFloat(),
                        size = t.getDouble("size").toFloat(), color = t.getInt("color"),
                        bold = t.optBoolean("bold", false), italic = t.optBoolean("italic", false), font = t.optString("font", "sans"),
                    )
                }
                val sp = l.optJSONObject("shapeParams")?.let { s ->
                    ShapeParams(
                        kind = s.getString("kind"), x0 = s.getDouble("x0").toFloat(), y0 = s.getDouble("y0").toFloat(),
                        x1 = s.getDouble("x1").toFloat(), y1 = s.getDouble("y1").toFloat(), color = s.getInt("color"),
                        stroke = s.getDouble("stroke").toFloat(), filled = s.optBoolean("filled", false),
                        opacity = s.optDouble("opacity", 1.0).toFloat().coerceIn(0f, 1f),
                    )
                }
                if (type == "text" && tp == null) throw ProjectFormatException("Text layer without parameters")
                if (type == "shape" && sp == null) throw ProjectFormatException("Shape layer without parameters")
                LayerEntry(
                    id = id, name = l.getString("name"), type = type, file = file,
                    visible = l.optBoolean("visible", true), locked = l.optBoolean("locked", false),
                    opacity = l.optDouble("opacity", 1.0).toFloat().coerceIn(0f, 1f),
                    blend = l.optString("blend", "normal"),
                    maskFile = maskFile, maskEnabled = l.optBoolean("maskEnabled", true),
                    parentId = if (l.has("parent")) l.getString("parent") else null,
                    expanded = l.optBoolean("expanded", true), text = tp, shape = sp,
                )
            }
            if (layers.none { it.type != "group" }) throw ProjectFormatException("Project has no image layers")
            val guides = json.optJSONArray("guides")?.let { ga ->
                (0 until ga.length()).map {
                    val g = ga.getJSONObject(it)
                    Guide(vertical = g.getString("o") == "v", position = g.getInt("p"))
                }
            } ?: emptyList()
            return ProjectManifest(
                formatVersion = version,
                appVersion = json.optString("appVersion", ""),
                name = json.optString("name", ""),
                width = width, height = height,
                colorSpace = canvas.optString("colorSpace", "sRGB"),
                createdAt = json.optLong("createdAt", 0L),
                modifiedAt = json.optLong("modifiedAt", 0L),
                layers = layers,
                guides = guides,
                activeLayerId = if (json.has("activeLayer")) json.getString("activeLayer") else null,
                sourceVersion = sourceVersion,
            )
        } catch (e: JSONException) {
            throw ProjectFormatException("Malformed manifest: ${e.message}")
        }
    }
}
