package app.nupixel.data

import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.OutputStream

/**
 * Crash-safe file replacement. The new content goes to `<name>.tmp`, is checked, and only then replaces the
 * target; the previous version is kept as `<name>.bak` until the swap succeeded. On any failure the target
 * is left exactly as it was. Pure JVM so it can be unit-tested.
 */
object SafeWriter {
    /**
     * [producer] must write the whole content and may call `finish()` on wrappers, but must NOT close the stream.
     * [verify] gets the finished temp file and returns false when it is not a valid result.
     */
    @Throws(IOException::class)
    fun write(target: File, verify: (File) -> Boolean, producer: (OutputStream) -> Unit) {
        val dir = target.absoluteFile.parentFile ?: throw IOException("No parent directory")
        if (!dir.isDirectory && !dir.mkdirs()) throw IOException("Cannot create directory")
        val tmp = File(dir, target.name + ".tmp")
        val bak = File(dir, target.name + ".bak")
        try {
            FileOutputStream(tmp).use { fos ->
                val out = BufferedOutputStream(fos)
                producer(out)
                out.flush()
                try { fos.fd.sync() } catch (_: IOException) { /* best effort */ }
            }
            if (!verify(tmp)) throw IOException("Written file failed verification")
            if (target.exists()) {
                bak.delete()
                if (!target.renameTo(bak)) throw IOException("Cannot move the previous version aside")
            }
            if (!tmp.renameTo(target)) {
                if (bak.exists()) bak.renameTo(target)
                throw IOException("Cannot move the new version into place")
            }
            bak.delete()
        } finally {
            if (tmp.exists()) tmp.delete()
        }
    }

    /**
     * Cleans up after a crash during [write]: temp files are discarded; a `.bak` whose target is missing is
     * the last good version and is put back.
     */
    fun recover(dir: File) {
        for (f in dir.listFiles().orEmpty()) {
            when {
                f.name.endsWith(".tmp") -> f.delete()
                f.name.endsWith(".bak") -> {
                    val target = File(dir, f.name.removeSuffix(".bak"))
                    if (target.exists()) f.delete() else f.renameTo(target)
                }
            }
        }
    }
}
