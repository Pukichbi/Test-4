package app.nupixel.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import app.nupixel.core.Limits
import app.nupixel.render.MaskUtil
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID
import java.util.zip.Deflater
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

data class ProjectInfo(
    val id: String,
    val name: String,
    val width: Int,
    val height: Int,
    val modifiedAt: Long,
    val sizeBytes: Long,
    val thumbnail: File?,
)

/** An unsaved project found after a restart: the autosave copy of a document that was open with changes. */
data class RecoverInfo(val id: String, val name: String, val savedAt: Long, val width: Int, val height: Int)

/** [migratedFrom] is the older format version the file was upgraded from in memory, or null. */
class LoadedProject(val id: String, val manifest: ProjectManifest, val images: Map<String, Bitmap>, val migratedFrom: Int? = null)

/**
 * Library of projects in filesDir/projects as `<id>.nupixel`; autosave copies live in filesDir/recovery.
 * Files from older versions (`<id>.npx`, same container) are still read and are replaced by a `.nupixel`
 * file on the next successful save; the old file is untouched until then. All writes go through [SafeWriter].
 */
class ProjectStore(context: Context) {
    private val dir = File(context.filesDir, "projects").apply { mkdirs() }
    private val recoveryDir = File(context.filesDir, "recovery").apply { mkdirs() }

    init {
        SafeWriter.recover(dir)
        SafeWriter.recover(recoveryDir)
    }

    private fun file(id: String) = File(dir, id + ProjectArchive.EXTENSION)
    private fun legacyFile(id: String) = File(dir, id + ProjectArchive.LEGACY_EXTENSION)
    private fun thumbFile(id: String) = File(dir, "$id.thumb.jpg")
    private fun recoveryFile(id: String) = File(recoveryDir, id + ProjectArchive.EXTENSION)

    /** The file to read for [id]: the current format file if present, else the legacy one. */
    private fun existing(id: String): File? = file(id).takeIf { it.isFile } ?: legacyFile(id).takeIf { it.isFile }

    fun newId(): String = UUID.randomUUID().toString()

    fun list(): List<ProjectInfo> {
        val files = dir.listFiles { f ->
            f.name.endsWith(ProjectArchive.EXTENSION) || f.name.endsWith(ProjectArchive.LEGACY_EXTENSION)
        }.orEmpty()
        val ids = files.map { it.name.substringBeforeLast('.') }.distinct()
        return ids.mapNotNull { id -> existing(id)?.let { readInfo(id, it) } }.sortedByDescending { it.modifiedAt }
    }

    private fun readInfo(id: String, f: File): ProjectInfo? = try {
        val m = ProjectArchive.readManifest(f, checkEntries = false)
        ProjectInfo(id, m.name, m.width, m.height, m.modifiedAt, f.length(), thumbFile(id).takeIf { it.exists() })
    } catch (e: Exception) {
        null
    }

    // ------------------------------------------------------------------ writing

    private fun writeArchive(out: OutputStream, manifest: ProjectManifest, images: Map<String, Bitmap>) {
        val zip = ZipOutputStream(out)
        zip.putNextEntry(ZipEntry(MANIFEST_ENTRY))
        zip.write(ManifestCodec.encode(manifest).toByteArray(Charsets.UTF_8))
        zip.closeEntry()
        zip.setLevel(Deflater.NO_COMPRESSION) // PNG is already compressed
        for ((name, bmp) in images) {
            zip.putNextEntry(ZipEntry(name))
            val src = if (bmp.config == Bitmap.Config.ALPHA_8) MaskUtil.toArgb(bmp) else bmp
            val ok = src.compress(Bitmap.CompressFormat.PNG, 100, zip)
            if (src !== bmp) src.recycle()
            if (!ok) throw IOException("PNG encode failed")
            zip.closeEntry()
        }
        zip.finish()
    }

    /**
     * Writes the project. [images] maps archive paths (as used by the manifest) to bitmaps; ALPHA_8 masks are
     * stored as white ARGB PNGs. [preview] is the flattened picture used for the thumbnail.
     */
    @Throws(IOException::class)
    fun save(id: String, manifest: ProjectManifest, images: Map<String, Bitmap>, preview: Bitmap) {
        SafeWriter.write(file(id), verify = { ProjectArchive.isValid(it) }) { writeArchive(it, manifest, images) }
        // The upgraded copy is safely in place: the pre-0.4.0 file is no longer needed.
        legacyFile(id).delete()
        File(dir, legacyFile(id).name + ".bak").delete()
        writeThumbnail(id, preview)
    }

    /** Autosave: a full copy of the open document in the recovery folder. Never touches the project file. */
    @Throws(IOException::class)
    fun autosave(id: String, manifest: ProjectManifest, images: Map<String, Bitmap>) {
        SafeWriter.write(recoveryFile(id), verify = { ProjectArchive.isValid(it) }) { writeArchive(it, manifest, images) }
    }

    fun deleteRecovery(id: String) {
        recoveryFile(id).delete()
    }

    fun listRecoverable(): List<RecoverInfo> =
        recoveryDir.listFiles { f -> f.name.endsWith(ProjectArchive.EXTENSION) }.orEmpty().mapNotNull { f ->
            try {
                val m = ProjectArchive.readManifest(f, checkEntries = false)
                RecoverInfo(f.name.removeSuffix(ProjectArchive.EXTENSION), m.name, f.lastModified(), m.width, m.height)
            } catch (e: Exception) {
                f.delete() // an unreadable recovery copy is useless
                null
            }
        }.sortedByDescending { it.savedAt }

    fun writeThumbnail(id: String, bitmap: Bitmap) {
        try {
            val longest = maxOf(bitmap.width, bitmap.height)
            val s = 256f / longest
            val w = (bitmap.width * s).toInt().coerceAtLeast(1)
            val h = (bitmap.height * s).toInt().coerceAtLeast(1)
            val small = Bitmap.createScaledBitmap(bitmap, w, h, true)
            val flat = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            android.graphics.Canvas(flat).apply {
                drawColor(0xFF2A3350.toInt())
                drawBitmap(small, 0f, 0f, null)
            }
            FileOutputStream(thumbFile(id)).use { flat.compress(Bitmap.CompressFormat.JPEG, 85, it) }
            if (small !== bitmap) small.recycle()
            flat.recycle()
        } catch (_: Exception) {
            // Thumbnails are cosmetic; never fail a save because of them.
        }
    }

    // ------------------------------------------------------------------ reading

    @Throws(ProjectFormatException::class, IOException::class)
    fun load(id: String): LoadedProject {
        val f = existing(id) ?: throw ProjectFormatException("Project file not found")
        return loadFile(id, f)
    }

    @Throws(ProjectFormatException::class, IOException::class)
    fun loadRecovery(id: String): LoadedProject {
        val f = recoveryFile(id)
        if (!f.isFile) throw ProjectFormatException("Recovery file not found")
        return loadFile(id, f)
    }

    private fun loadFile(id: String, f: File): LoadedProject {
        val manifest = ProjectArchive.readManifest(f)
        if (manifest.width > Limits.MAX_SIDE || manifest.height > Limits.MAX_SIDE ||
            manifest.width.toLong() * manifest.height > Limits.maxPixels()
        ) throw OutOfMemoryError("Project larger than this device can hold")
        val bytesPerPixel = manifest.layers.sumOf { (if (it.type != "group") 4L else 0L) + (if (it.maskFile != null) 1L else 0L) }
        if (!Limits.fitsBytes(manifest.width, manifest.height, bytesPerPixel)) throw OutOfMemoryError("Too many layers for this device")
        return try {
            ZipFile(f).use { zip ->
                val images = LinkedHashMap<String, Bitmap>()
                for (e in manifest.layers) {
                    e.file?.let { images[it] = decodeEntry(zip, it, manifest.width, manifest.height, mask = false) }
                    e.maskFile?.let { images[it] = decodeEntry(zip, it, manifest.width, manifest.height, mask = true) }
                }
                LoadedProject(id, manifest, images, migratedFrom = manifest.sourceVersion.takeIf { it < CURRENT_FORMAT_VERSION })
            }
        } catch (e: java.util.zip.ZipException) {
            throw ProjectFormatException("Not a valid project archive")
        }
    }

    private fun decodeEntry(zip: ZipFile, name: String, w: Int, h: Int, mask: Boolean): Bitmap {
        val entry = zip.getEntry(name) ?: throw ProjectFormatException("Missing layer data")
        val opts = BitmapFactory.Options().apply {
            inPreferredConfig = Bitmap.Config.ARGB_8888
            inMutable = true
        }
        val bmp = zip.getInputStream(entry).use { BitmapFactory.decodeStream(it, null, opts) }
            ?: throw ProjectFormatException("Layer image is unreadable")
        if (bmp.width != w || bmp.height != h) throw ProjectFormatException("Layer size does not match canvas")
        if (!mask) return bmp
        val m = MaskUtil.fromArgb(bmp)
        bmp.recycle()
        return m
    }

    /** Copies an external project file into the library under a new id after validating it. */
    @Throws(ProjectFormatException::class, IOException::class)
    fun importFile(input: InputStream): String {
        val id = newId()
        val target = file(id)
        SafeWriter.write(target, verify = { ProjectArchive.isValid(it) }) { out -> input.copyTo(out) }
        return id
    }

    @Throws(IOException::class)
    fun copyTo(id: String, out: OutputStream) {
        val f = existing(id) ?: throw IOException("Project file not found")
        f.inputStream().use { it.copyTo(out) }
    }

    fun delete(id: String): Boolean {
        val a = !file(id).exists() || file(id).delete()
        val b = !legacyFile(id).exists() || legacyFile(id).delete()
        thumbFile(id).delete()
        recoveryFile(id).delete()
        return a && b
    }
}
