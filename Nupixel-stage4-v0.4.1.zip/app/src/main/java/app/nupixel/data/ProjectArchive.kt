package app.nupixel.data

import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.util.zip.ZipException
import java.util.zip.ZipFile

/** Reading and validating `.nupixel` archives (zip: manifest.json + PNG layer files). Pure JVM. */
object ProjectArchive {
    const val EXTENSION = ".nupixel"
    const val LEGACY_EXTENSION = ".npx" // same container, written by versions before 0.4.0
    private const val MAX_MANIFEST_BYTES = 4 * 1024 * 1024

    /**
     * Reads the manifest and, when [checkEntries], verifies that every referenced file is in the archive.
     * Throws [ProjectFormatException] (broken, empty, foreign or incomplete file) or [ProjectTooNewException].
     */
    @Throws(ProjectFormatException::class, IOException::class)
    fun readManifest(file: File, checkEntries: Boolean = true): ProjectManifest {
        if (!file.isFile || file.length() == 0L) throw ProjectFormatException("Empty or missing file")
        return try {
            ZipFile(file).use { zip ->
                val entry = zip.getEntry(MANIFEST_ENTRY) ?: throw ProjectFormatException("No manifest")
                val text = zip.getInputStream(entry).use { readLimited(it) }
                val manifest = ManifestCodec.decode(text)
                if (checkEntries) {
                    for (l in manifest.layers) {
                        for (name in listOfNotNull(l.file, l.maskFile)) {
                            if (zip.getEntry(name) == null) throw ProjectFormatException("Missing layer data: $name")
                        }
                    }
                }
                manifest
            }
        } catch (e: ZipException) {
            throw ProjectFormatException("Not a valid project archive")
        }
    }

    fun isValid(file: File): Boolean = try {
        readManifest(file)
        true
    } catch (e: ProjectTooNewException) {
        throw e
    } catch (e: Exception) {
        false
    }

    private fun readLimited(input: InputStream): String {
        val out = ByteArrayOutputStream()
        val buf = ByteArray(8192)
        var total = 0
        while (true) {
            val n = input.read(buf)
            if (n < 0) break
            total += n
            if (total > MAX_MANIFEST_BYTES) throw ProjectFormatException("Manifest too large")
            out.write(buf, 0, n)
        }
        return out.toString("UTF-8")
    }
}
