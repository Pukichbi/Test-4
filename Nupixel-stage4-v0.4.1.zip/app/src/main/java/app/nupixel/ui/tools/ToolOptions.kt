package app.nupixel.ui.tools

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import app.nupixel.AppViewModel
import app.nupixel.R
import app.nupixel.layers.LayerType
import app.nupixel.tools.Tool
import app.nupixel.tools.ToolController
import app.nupixel.ui.components.NxChip
import app.nupixel.ui.components.NxSegmented
import app.nupixel.ui.components.NxSliderRow
import kotlin.math.roundToInt

private fun pct(v: Float) = "${(v * 100).roundToInt()}%"

/** Contextual options for the active tool. Only controls that really work are shown. */
@Composable
fun ToolOptions(vm: AppViewModel, controller: ToolController, onPickColor: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val t = vm.tool
    val tool = vm.activeTool

    Column(
        Modifier.fillMaxWidth().background(cs.surfaceContainer).heightIn(max = 230.dp)
            .verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 6.dp),
    ) {
        when (tool) {
            Tool.VIEW -> Hint(R.string.hint_view)
            Tool.BRUSH -> {
                ColorRow(t.color, onPickColor)
                NxSliderRow(stringResource(R.string.opt_size), t.brushSize, 1f..300f, "${t.brushSize.roundToInt()}") { t.brushSize = it }
                NxSliderRow(stringResource(R.string.opt_opacity), t.brushOpacity, 0.01f..1f, pct(t.brushOpacity)) { t.brushOpacity = it }
                NxSliderRow(stringResource(R.string.opt_hardness), t.brushHardness, 0f..1f, pct(t.brushHardness)) { t.brushHardness = it }
            }
            Tool.ERASER -> {
                NxSliderRow(stringResource(R.string.opt_size), t.eraserSize, 1f..300f, "${t.eraserSize.roundToInt()}") { t.eraserSize = it }
                NxSliderRow(stringResource(R.string.opt_opacity), t.eraserOpacity, 0.01f..1f, pct(t.eraserOpacity)) { t.eraserOpacity = it }
                NxSliderRow(stringResource(R.string.opt_hardness), t.eraserHardness, 0f..1f, pct(t.eraserHardness)) { t.eraserHardness = it }
            }
            Tool.FILL -> {
                ColorRow(t.color, onPickColor)
                NxSliderRow(stringResource(R.string.opt_tolerance), t.fillTolerance.toFloat(), 0f..128f, "${t.fillTolerance}") { t.fillTolerance = it.roundToInt() }
                NxSliderRow(stringResource(R.string.opt_opacity), t.fillOpacity, 0.01f..1f, pct(t.fillOpacity)) { t.fillOpacity = it }
                SwitchRow(stringResource(R.string.opt_contiguous), t.fillContiguous) { t.fillContiguous = it }
            }
            Tool.EYEDROPPER -> {
                ColorRow(t.color, onPickColor)
                Hint(R.string.hint_picker)
            }
            Tool.MAGIC_ERASER -> {
                Hint(R.string.hint_bg)
                NxSliderRow(stringResource(R.string.opt_tolerance), t.bgTolerance.toFloat(), 0f..128f, "${t.bgTolerance}") { t.bgTolerance = it.roundToInt() }
                SwitchRow(stringResource(R.string.opt_contiguous), t.bgContiguous) { t.bgContiguous = it }
            }
            Tool.LINE, Tool.RECT, Tool.ELLIPSE -> {
                ColorRow(t.color, onPickColor)
                NxSliderRow(stringResource(R.string.opt_stroke), t.shapeStroke, 1f..100f, "${t.shapeStroke.roundToInt()}") { t.shapeStroke = it }
                NxSliderRow(stringResource(R.string.opt_opacity), t.shapeOpacity, 0.01f..1f, pct(t.shapeOpacity)) { t.shapeOpacity = it }
                if (tool != Tool.LINE) SwitchRow(stringResource(R.string.opt_filled), t.shapeFilled) { t.shapeFilled = it }
            }
            Tool.SELECT_RECT, Tool.SELECT_FREE -> SelectionActions(vm, controller, onPickColor)
            Tool.MOVE -> MoveOptions(vm, controller)
            Tool.TEXT -> TextOptions(controller, vm, onPickColor)
        }
    }
}

@Composable
private fun Hint(res: Int) {
    Text(stringResource(res), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(vertical = 8.dp))
}

@Composable
private fun ColorRow(color: Int, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(stringResource(R.string.opt_color), Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
        Text("#" + String.format("%06X", color and 0xFFFFFF), style = MaterialTheme.typography.labelLarge, modifier = Modifier.padding(end = 10.dp))
        Box(Modifier.size(32.dp).clip(RoundedCornerShape(8.dp)).background(Color(color or 0xFF000000.toInt())).border(1.dp, cs.outlineVariant, RoundedCornerShape(8.dp)))
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().heightIn(min = 40.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun SelectionActions(vm: AppViewModel, controller: ToolController, onPickColor: () -> Unit) {
    val has = vm.selection != null
    Hint(R.string.hint_select)
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(bottom = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        NxChip(stringResource(R.string.sel_all), { controller.selectAll() })
        NxChip(stringResource(R.string.sel_none), { controller.deselect() }, enabled = has)
        NxChip(stringResource(R.string.sel_transform), { controller.selectTool(Tool.MOVE) }, enabled = has, primary = has)
        NxChip(stringResource(R.string.sel_clear), { controller.clearSelectionPixels() }, enabled = has)
        NxChip(stringResource(R.string.sel_fill), { controller.fillSelection() }, enabled = has)
        NxChip(stringResource(R.string.sel_crop), { controller.cropToSelection() }, enabled = has)
    }
    ColorRow(vm.tool.color, onPickColor)
}

@Composable
private fun MoveOptions(vm: AppViewModel, controller: ToolController) {
    val f = controller.floating
    if (f == null) {
        Hint(if (vm.selection == null) R.string.hint_move_empty else R.string.hint_move_ready)
        return
    }
    NxSliderRow(stringResource(R.string.opt_scale), f.scale, 0.1f..4f, pct(f.scale)) { f.scale = it }
    NxSliderRow(stringResource(R.string.opt_rotation), f.rotation, -180f..180f, "${f.rotation.roundToInt()}°") { f.rotation = it }
    Row(Modifier.padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        NxChip(stringResource(R.string.action_apply), { controller.applyFloating() }, primary = true)
        NxChip(stringResource(R.string.action_cancel), { controller.cancelFloating() })
    }
}

@Composable
private fun TextOptions(controller: ToolController, vm: AppViewModel, onPickColor: () -> Unit) {
    val l = vm.activeLayer
    val p = l?.text
    if (l == null || l.type != LayerType.TEXT || p == null) {
        Hint(R.string.hint_text)
        return
    }
    ColorRow(p.color, onPickColor)
    NxSliderRow(stringResource(R.string.opt_size), p.size, 8f..600f, "${p.size.roundToInt()}") { v -> vm.updateActiveText { it.copy(size = v) } }
    NxSegmented(
        options = listOf("sans" to stringResource(R.string.font_sans), "serif" to stringResource(R.string.font_serif), "mono" to stringResource(R.string.font_mono)),
        selected = p.font, onSelect = { f -> vm.updateActiveText { it.copy(font = f) } },
    )
    Row(Modifier.padding(top = 8.dp, bottom = 6.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        NxChip(stringResource(R.string.opt_bold), { vm.updateActiveText { it.copy(bold = !it.bold) } }, primary = p.bold)
        NxChip(stringResource(R.string.opt_italic), { vm.updateActiveText { it.copy(italic = !it.italic) } }, primary = p.italic)
        NxChip(stringResource(R.string.text_edit), { controller.editingText = true })
        NxChip(stringResource(R.string.action_delete), { controller.deleteText() })
    }
}
