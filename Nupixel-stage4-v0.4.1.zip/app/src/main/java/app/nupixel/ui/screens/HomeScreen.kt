package app.nupixel.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import android.text.format.DateUtils
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import app.nupixel.AppViewModel
import app.nupixel.R
import app.nupixel.ui.components.NxButton
import app.nupixel.ui.theme.LocalNx

@Composable
fun HomeScreen(
    vm: AppViewModel,
    onNewProject: () -> Unit,
    onProjects: () -> Unit,
    onSettings: () -> Unit,
    onOpenEditor: () -> Unit,
) {
    val fallbackName = stringResource(R.string.default_project_name)
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.importImage(uri, fallbackName, onOpenEditor)
    }
    val projectPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importProjectFile(uri, onOpenEditor)
    }
    val glow = LocalNx.current.homeGlow

    val rec = vm.recoverable.firstOrNull()
    if (rec != null) {
        val whenText = DateUtils.getRelativeTimeSpanString(rec.savedAt, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS).toString()
        AlertDialog(
            onDismissRequest = {}, // must be answered: restore or discard
            title = { Text(stringResource(R.string.recover_title)) },
            text = { Text(stringResource(R.string.recover_text, rec.name.ifBlank { fallbackName }, whenText)) },
            confirmButton = { TextButton(onClick = { vm.restoreRecovery(rec.id, onOpenEditor) }) { Text(stringResource(R.string.recover_restore)) } },
            dismissButton = {
                TextButton(onClick = { vm.discardRecovery(rec.id) }) {
                    Text(stringResource(R.string.recover_discard), color = MaterialTheme.colorScheme.error)
                }
            },
        )
    }

    Box(
        Modifier.fillMaxSize()
            .background(Brush.radialGradient(listOf(glow.copy(alpha = 0.22f), Color.Transparent), center = androidx.compose.ui.geometry.Offset(540f, 300f), radius = 900f))
    ) {
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Spacer(Modifier.weight(1f))
            Image(painterResource(R.drawable.nupixel_logo), contentDescription = null, modifier = Modifier.size(112.dp))
            Spacer(Modifier.height(12.dp))
            Text("Nupixel", style = MaterialTheme.typography.headlineLarge)
            Spacer(Modifier.height(8.dp))
            Text(
                stringResource(R.string.tagline),
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.weight(1f))
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                NxButton(stringResource(R.string.home_new_project), onNewProject, icon = Icons.Rounded.Add)
                NxButton(
                    stringResource(R.string.home_open_image),
                    { imagePicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                    icon = Icons.Rounded.Image, primary = false,
                )
                NxButton(
                    stringResource(R.string.home_open_project),
                    { projectPicker.launch(arrayOf("*/*")) },
                    icon = Icons.Rounded.FolderOpen, primary = false,
                )
            }
            Spacer(Modifier.height(20.dp))
            Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                BottomNavItem(Icons.Rounded.Folder, stringResource(R.string.nav_projects), onProjects)
                BottomNavItem(Icons.Rounded.Settings, stringResource(R.string.nav_settings), onSettings)
            }
        }
    }
}

@Composable
private fun BottomNavItem(icon: ImageVector, label: String, onClick: () -> Unit) {
    Column(
        Modifier.clickable(onClick = onClick).padding(horizontal = 24.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
