package app.nupixel.ui.screens

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateRotation
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Layers
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Undo
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import app.nupixel.AppViewModel
import app.nupixel.R
import app.nupixel.core.ViewTransform
import app.nupixel.data.ExportFormat
import app.nupixel.render.TilePyramid
import app.nupixel.layers.LayerType
import app.nupixel.tools.Tool
import app.nupixel.tools.ToolController
import app.nupixel.ui.canvas.DocumentLayer
import app.nupixel.ui.canvas.OverlayLayer
import app.nupixel.ui.canvas.ToolOverlay
import app.nupixel.ui.components.NxButton
import app.nupixel.ui.components.NxChip
import app.nupixel.ui.components.NxSectionLabel
import app.nupixel.ui.components.NxSegmented
import app.nupixel.ui.theme.LocalNx
import app.nupixel.ui.layers.LayersSheet
import app.nupixel.ui.tools.ColorPickerSheet
import app.nupixel.ui.tools.ToolOptions
import app.nupixel.ui.tools.ToolRail
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt

private class PendingExport(val format: ExportFormat, val quality: Int, val scale: Float)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(vm: AppViewModel, onLeave: () -> Unit) {
    val s = vm.session
    if (s == null) {
        // Session lost (e.g. process recreated): nothing to edit, go back.
        LaunchedEffect(Unit) { onLeave() }
        return
    }

    val controller = remember { ToolController(vm) }
    val pyramid = remember(s.bitmap) { TilePyramid(s.bitmap) }
    SideEffect { vm.pyramid = pyramid }
    DisposableEffect(Unit) { onDispose { controller.release(); vm.pyramid = null } }

    val density = LocalDensity.current
    val padPx = with(density) { 24.dp.toPx() }
    var viewSize by remember { mutableStateOf(IntSize.Zero) }
    var view by remember(s.id) { mutableStateOf(ViewTransform()) }
    var fitted by remember(s.id, s.bitmap.width, s.bitmap.height) { mutableStateOf(false) }
    var showExport by remember { mutableStateOf(false) }
    var showCanvas by remember { mutableStateOf(false) }
    var showGuidesSheet by remember { mutableStateOf(false) }
    var showColor by remember { mutableStateOf(false) }
    var showLayers by remember { mutableStateOf(false) }
    var showSaveAs by remember { mutableStateOf(false) }
    var showMenu by remember { mutableStateOf(false) }
    var showGrid by rememberSaveable { mutableStateOf(false) }
    var showGuides by rememberSaveable { mutableStateOf(true) }
    var showUnsaved by remember { mutableStateOf(false) }
    var pending by remember { mutableStateOf<PendingExport?>(null) }

    val docW = s.bitmap.width.toFloat()
    val docH = s.bitmap.height.toFloat()
    fun fitView() = ViewTransform.fit(viewSize.width.toFloat(), viewSize.height.toFloat(), docW, docH, padPx)
    SideEffect { controller.tapSlop = with(density) { 8.dp.toPx() } / view.scale }

    LaunchedEffect(viewSize, s.id, s.bitmap.width, s.bitmap.height) {
        if (viewSize != IntSize.Zero && !fitted) { view = fitView(); fitted = true }
    }

    val requestLeave: () -> Unit = {
        controller.finishPending()
        if (vm.session?.dirty == true) {
            showUnsaved = true
        } else {
            onLeave()
        }
    }
    BackHandler { requestLeave() }

    val pngLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument(ExportFormat.PNG.mime)) { uri ->
        val p = pending
        if (uri != null && p != null) vm.exportImage(uri, p.format, p.quality, p.scale)
        pending = null
    }
    val jpgLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument(ExportFormat.JPEG.mime)) { uri ->
        val p = pending
        if (uri != null && p != null) vm.exportImage(uri, p.format, p.quality, p.scale)
        pending = null
    }

    val cs = MaterialTheme.colorScheme
    val nx = LocalNx.current
    val tool = vm.activeTool

    Column(Modifier.fillMaxSize().background(cs.background)) {
        // Top bar
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().height(56.dp).padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = requestLeave) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, stringResource(R.string.cd_back)) }
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(s.name, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                    if (s.dirty) {
                        Spacer(Modifier.width(8.dp))
                        Box(Modifier.size(8.dp).background(nx.warning, CircleShape))
                    }
                }
                Text("${s.bitmap.width} × ${s.bitmap.height} px", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            }
            IconButton(
                enabled = s.undo != null || controller.floating != null,
                onClick = { if (controller.floating != null) controller.cancelFloating() else vm.undo() },
            ) { Icon(Icons.Rounded.Undo, stringResource(R.string.editor_undo)) }
            IconButton(onClick = { controller.finishPending(); vm.saveSession() }) { Icon(Icons.Rounded.Save, stringResource(R.string.editor_save)) }
            IconButton(onClick = { controller.finishPending(); showExport = true }) { Icon(Icons.Rounded.Share, stringResource(R.string.editor_export)) }
            Box {
                IconButton(onClick = { showMenu = true }) { Icon(Icons.Rounded.MoreVert, stringResource(R.string.cd_more)) }
                DropdownMenu(expanded = showMenu, onDismissRequest = { showMenu = false }) {
                    DropdownMenuItem(text = { Text(stringResource(R.string.editor_fit)) }, onClick = { showMenu = false; view = fitView() })
                    DropdownMenuItem(text = { Text(stringResource(R.string.editor_actual)) }, onClick = {
                        showMenu = false
                        view = view.zoomAround(viewSize.width / 2f, viewSize.height / 2f, 1f / view.scale)
                    })
                    DropdownMenuItem(text = { Text(stringResource(R.string.menu_reset_rotation)) }, onClick = {
                        showMenu = false
                        view = view.rotateAround(viewSize.width / 2f, viewSize.height / 2f, -view.rotation)
                    })
                    DropdownMenuItem(text = { Text(stringResource(R.string.editor_guides)) }, onClick = { showMenu = false; showGuidesSheet = true })
                    DropdownMenuItem(text = { Text(stringResource(R.string.editor_canvas)) }, onClick = { showMenu = false; controller.finishPending(); showCanvas = true })
                    DropdownMenuItem(text = { Text(stringResource(R.string.menu_save_as)) }, onClick = { showMenu = false; showSaveAs = true })
                }
            }
        }

        // Canvas. One finger drives the active tool; two fingers always pan / zoom / rotate the view.
        Box(
            Modifier.weight(1f).fillMaxWidth().background(nx.canvasBackground).clipToBounds()
                .onSizeChanged { viewSize = it }
                .pointerInput(s.id, s.bitmap, tool) {
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        var viewGesture = tool == Tool.VIEW
                        var toolActive = false
                        if (!viewGesture) {
                            val d = view.screenToDoc(down.position.x, down.position.y)
                            toolActive = controller.onDown(d.x, d.y)
                            if (!toolActive) viewGesture = true
                        }
                        do {
                            val event = awaitPointerEvent()
                            val pressed = event.changes.count { it.pressed }
                            if (pressed >= 2 || viewGesture) {
                                if (!viewGesture) {
                                    viewGesture = true
                                    if (toolActive) controller.onCancel()
                                    toolActive = false
                                }
                                val zoom = event.calculateZoom()
                                val rotationDeg = event.calculateRotation()
                                val pan = event.calculatePan()
                                val c = event.calculateCentroid()
                                if (zoom != 1f || rotationDeg != 0f || pan != Offset.Zero) {
                                    view = view.transformBy(c.x, c.y, pan.x, pan.y, zoom, Math.toRadians(rotationDeg.toDouble()).toFloat())
                                }
                                event.changes.forEach { if (it.positionChanged()) it.consume() }
                            } else if (toolActive) {
                                val ch = event.changes.firstOrNull { it.id == down.id } ?: event.changes.first()
                                if (ch.pressed) {
                                    val d = view.screenToDoc(ch.position.x, ch.position.y)
                                    controller.onMove(d.x, d.y)
                                    ch.consume()
                                }
                            }
                        } while (event.changes.any { it.pressed })
                        if (toolActive && !viewGesture) controller.onUp()
                    }
                }
                .then(
                    if (tool == Tool.VIEW) Modifier.pointerInput(s.id, s.bitmap, viewSize) {
                        detectTapGestures(onDoubleTap = { p ->
                            view = if (abs(view.scale - 1f) < 0.01f) fitView() else view.zoomAround(p.x, p.y, 1f / view.scale)
                        })
                    } else Modifier
                )
        ) {
            DocumentLayer(pyramid, view)
            ToolOverlay(view, controller, vm.selection, vm.tool)
            OverlayLayer(s.bitmap.width, s.bitmap.height, view, showGrid, showGuides, s.guides)

            Row(Modifier.align(Alignment.BottomStart).padding(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                NxChip("${(view.scale * 100).roundToInt()}%", { view = fitView() })
                if (vm.maskEditing) NxChip(stringResource(R.string.mask_editing), { vm.setMaskEditing(false) }, primary = true)
                val degrees = Math.toDegrees(view.rotation.toDouble()).let { d -> ((d % 360.0) + 540.0) % 360.0 - 180.0 }
                if (abs(degrees) > 0.5) {
                    NxChip("↺ " + stringResource(R.string.editor_rotation, degrees.roundToInt()), {
                        view = view.rotateAround(viewSize.width / 2f, viewSize.height / 2f, -view.rotation)
                    })
                }
            }
        }

        // Tool options + tool rail
        Column(Modifier.fillMaxWidth().background(cs.surfaceContainer).navigationBarsPadding()) {
            ToolOptions(vm, controller, onPickColor = { showColor = true })
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    onClick = { controller.finishPending(); showLayers = true },
                    shape = MaterialTheme.shapes.small,
                    color = cs.surfaceContainerHigh,
                    modifier = Modifier.padding(start = 8.dp).size(48.dp),
                ) {
                    Box(contentAlignment = Alignment.Center) { Icon(Icons.Rounded.Layers, stringResource(R.string.editor_layers)) }
                }
                Box(Modifier.weight(1f)) { ToolRail(tool, onSelect = { controller.selectTool(it) }) }
            }
        }
    }

    if (showColor) {
        val activeText = vm.activeLayer?.takeIf { it.type == LayerType.TEXT && tool == Tool.TEXT }?.text
        ModalBottomSheet(onDismissRequest = { showColor = false }, containerColor = cs.surfaceContainer) {
            ColorPickerSheet(
                initial = activeText?.color ?: vm.tool.color,
                onColor = { c ->
                    vm.tool.color = c
                    if (activeText != null) vm.updateActiveText { it.copy(color = c) }
                },
            )
        }
    }

    val textLayer = vm.activeLayer?.takeIf { it.type == LayerType.TEXT }
    if (controller.editingText && textLayer != null) {
        var value by remember(textLayer.id) { mutableStateOf(textLayer.text?.text ?: "") }
        AlertDialog(
            onDismissRequest = { controller.setText(value) },
            title = { Text(stringResource(R.string.text_dialog_title)) },
            text = {
                OutlinedTextField(
                    value = value, onValueChange = { value = it },
                    placeholder = { Text(stringResource(R.string.text_dialog_hint)) },
                    modifier = Modifier.fillMaxWidth(),
                )
            },
            confirmButton = { TextButton(onClick = { controller.setText(value) }) { Text(stringResource(R.string.action_ok)) } },
            dismissButton = { TextButton(onClick = { controller.deleteText() }) { Text(stringResource(R.string.action_delete), color = cs.error) } },
        )
    }

    if (showSaveAs) {
        var newName by remember { mutableStateOf(s.name) }
        AlertDialog(
            onDismissRequest = { showSaveAs = false },
            title = { Text(stringResource(R.string.save_as_title)) },
            text = {
                OutlinedTextField(
                    value = newName, onValueChange = { newName = it.take(60) },
                    label = { Text(stringResource(R.string.save_as_name)) }, singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
            },
            confirmButton = {
                TextButton(onClick = { showSaveAs = false; controller.finishPending(); vm.saveSessionAs(newName) }) {
                    Text(stringResource(R.string.action_save))
                }
            },
            dismissButton = { TextButton(onClick = { showSaveAs = false }) { Text(stringResource(R.string.action_cancel)) } },
        )
    }

    if (showLayers) {
        ModalBottomSheet(onDismissRequest = { showLayers = false }, containerColor = cs.surfaceContainer) {
            LayersSheet(vm, controller, onClose = { showLayers = false })
        }
    }

    if (showExport) {
        ModalBottomSheet(onDismissRequest = { showExport = false }, containerColor = cs.surfaceContainer) {
            ExportSheet(
                projectName = s.name, width = s.bitmap.width, height = s.bitmap.height,
                onExport = { format, quality, scale ->
                    showExport = false
                    pending = PendingExport(format, quality, scale)
                    val fileName = "${s.name.replace(Regex("[\\\\/:*?\"<>|]"), "_").ifBlank { "image" }}.${format.extension}"
                    if (format == ExportFormat.PNG) pngLauncher.launch(fileName) else jpgLauncher.launch(fileName)
                },
            )
        }
    }

    if (showCanvas) {
        ModalBottomSheet(onDismissRequest = { showCanvas = false }, containerColor = cs.surfaceContainer) {
            CanvasSheet(
                docW = s.bitmap.width, docH = s.bitmap.height,
                onCrop = { x, y, w, h -> showCanvas = false; vm.cropCanvas(x, y, w, h) },
                onResizeCanvas = { w, h, ax, ay, fill -> showCanvas = false; vm.resizeCanvas(w, h, ax, ay, fill) },
                onResample = { w, h -> showCanvas = false; vm.resample(w, h) },
            )
        }
    }

    if (showGuidesSheet) {
        ModalBottomSheet(onDismissRequest = { showGuidesSheet = false }, containerColor = cs.surfaceContainer) {
            GuidesSheet(
                showGrid = showGrid, showGuides = showGuides, guides = s.guides,
                onShowGrid = { showGrid = it }, onShowGuides = { showGuides = it },
                onAdd = { vertical, pos -> vm.addGuide(vertical, pos); showGuides = true },
                onAddCenter = { vm.addCenterGuides(); showGuides = true },
                onRemove = { vm.removeGuide(it) },
                onClear = { vm.clearGuides() },
                onCenterView = { view = view.centerOn(viewSize.width.toFloat(), viewSize.height.toFloat(), docW, docH); showGuidesSheet = false },
            )
        }
    }

    if (showUnsaved) {
        AlertDialog(
            onDismissRequest = { showUnsaved = false },
            title = { Text(stringResource(R.string.unsaved_title)) },
            text = { Text(stringResource(R.string.unsaved_text, s.name)) },
            confirmButton = {
                TextButton(onClick = { showUnsaved = false; vm.saveSession { ok -> if (ok) onLeave() } }) {
                    Text(stringResource(R.string.action_save))
                }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = { showUnsaved = false; onLeave() }) {
                        Text(stringResource(R.string.action_discard), color = cs.error)
                    }
                    TextButton(onClick = { showUnsaved = false }) { Text(stringResource(R.string.action_cancel)) }
                }
            },
        )
    }
}

@Composable
private fun ExportSheet(projectName: String, width: Int, height: Int, onExport: (ExportFormat, Int, Float) -> Unit) {
    var format by remember { mutableStateOf(ExportFormat.PNG) }
    var quality by remember { mutableStateOf(92f) }
    var scalePercent by remember { mutableStateOf(100) }
    val cs = MaterialTheme.colorScheme

    Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 16.dp).navigationBarsPadding()) {
        Text(stringResource(R.string.export_title), style = MaterialTheme.typography.titleLarge)

        NxSectionLabel(stringResource(R.string.export_format))
        NxSegmented(
            options = listOf("png" to "PNG", "jpeg" to "JPEG"),
            selected = if (format == ExportFormat.PNG) "png" else "jpeg",
            onSelect = { format = if (it == "png") ExportFormat.PNG else ExportFormat.JPEG },
        )
        Text(
            stringResource(if (format == ExportFormat.PNG) R.string.export_png_note else R.string.export_jpeg_note),
            style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, modifier = Modifier.padding(top = 8.dp),
        )

        if (format == ExportFormat.JPEG) {
            NxSectionLabel(stringResource(R.string.export_quality))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Slider(value = quality, onValueChange = { quality = it }, valueRange = 40f..100f, modifier = Modifier.weight(1f))
                Text("${quality.roundToInt()}%", style = MaterialTheme.typography.labelLarge, modifier = Modifier.width(48.dp))
            }
        }

        NxSectionLabel(stringResource(R.string.export_size))
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(100, 75, 50, 25).forEach { pct ->
                val w = max(1, (width * pct / 100f).roundToInt())
                val h = max(1, (height * pct / 100f).roundToInt())
                val on = scalePercent == pct
                Surface(
                    onClick = { scalePercent = pct },
                    shape = MaterialTheme.shapes.small,
                    color = if (on) cs.primary.copy(alpha = 0.14f) else cs.surfaceContainerHigh,
                    border = androidx.compose.foundation.BorderStroke(if (on) 1.5.dp else 1.dp, if (on) cs.primary else cs.outlineVariant),
                    modifier = Modifier.fillMaxWidth().heightIn48(),
                ) {
                    Box(Modifier.padding(horizontal = 14.dp), contentAlignment = Alignment.CenterStart) {
                        Text(stringResource(R.string.export_size_option, pct, w, h), style = MaterialTheme.typography.bodyLarge)
                    }
                }
            }
        }

        Spacer(Modifier.height(20.dp))
        NxButton(stringResource(R.string.export_button), onClick = { onExport(format, quality.roundToInt(), scalePercent / 100f) }, icon = Icons.Rounded.Share)
    }
}

private fun Modifier.heightIn48(): Modifier = this.then(Modifier.height(48.dp))
