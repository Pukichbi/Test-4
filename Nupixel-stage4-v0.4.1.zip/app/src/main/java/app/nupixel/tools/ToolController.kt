package app.nupixel.tools

import android.graphics.Bitmap
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import android.graphics.Rect
import app.nupixel.AppViewModel
import app.nupixel.R
import app.nupixel.layers.LayerType
import app.nupixel.layers.TextParams
import app.nupixel.render.BrushStamp
import app.nupixel.render.PixelOps
import app.nupixel.render.SelectionOps
import app.nupixel.render.ShapeRenderer
import app.nupixel.render.StrokeRenderer
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Turns pointer events (already converted to document coordinates) into edits of the active layer.
 * Painting tools work on the active raster layer (or its mask); shapes and text create their own layers.
 * Whole-bitmap edits take a snapshot first, which becomes the one-step undo (full history: stage 5).
 */
class ToolController(private val vm: AppViewModel) {
    /** Movement below this many document pixels counts as a tap. Set by the editor from the zoom level. */
    var tapSlop: Float = 6f

    var draft by mutableStateOf<ShapeDraft?>(null); private set
    var lasso by mutableStateOf<List<Pair<Float, Float>>>(emptyList()); private set
    var floating by mutableStateOf<Floating?>(null); private set

    /** True while the text dialog should be shown for the active text layer. */
    var editingText by mutableStateOf(false)

    private var strokeLayer: Bitmap? = null
    private var stroke: StrokeRenderer? = null
    private var snapshot: Bitmap? = null
    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var textDrag = false
    private var textMoved = false
    private var layerDrag = false

    private val tool get() = vm.activeTool

    private fun refresh(r: Rect?) { if (r != null) vm.refresh(r) }

    // ---------------------------------------------------------------- pointer events

    /** Returns true when the tool takes this gesture (otherwise the editor treats it as a view gesture). */
    fun onDown(x: Float, y: Float): Boolean {
        val session = vm.session ?: return false
        downX = x; downY = y; lastX = x; lastY = y
        return when (tool) {
            Tool.VIEW -> false
            Tool.BRUSH, Tool.ERASER -> startStroke(x, y)
            Tool.EYEDROPPER -> { pick(session.composite, x, y); true }
            Tool.FILL, Tool.MAGIC_ERASER -> true
            Tool.LINE, Tool.RECT, Tool.ELLIPSE, Tool.SELECT_RECT -> { draft = ShapeDraft(tool, x, y, x, y); true }
            Tool.SELECT_FREE -> { lasso = listOf(x to y); true }
            Tool.MOVE -> startMove()
            Tool.TEXT -> startText(x, y)
        }
    }

    fun onMove(x: Float, y: Float) {
        val session = vm.session ?: return
        when (tool) {
            Tool.BRUSH, Tool.ERASER -> stroke?.moveTo(x, y)?.let { refresh(it) }
            Tool.EYEDROPPER -> pick(session.composite, x, y)
            Tool.LINE, Tool.RECT, Tool.ELLIPSE, Tool.SELECT_RECT -> draft = draft?.copy(x1 = x, y1 = y)
            Tool.SELECT_FREE -> lasso = lasso + (x to y)
            Tool.MOVE -> {
                if (layerDrag) vm.moveActiveLayerBy(x - lastX, y - lastY)
                else floating?.let { it.cx += x - lastX; it.cy += y - lastY }
            }
            Tool.TEXT -> if (textDrag) {
                vm.moveActiveLayerBy(x - lastX, y - lastY)
                if (hypot(x - downX, y - downY) > tapSlop) textMoved = true
            }
            else -> Unit
        }
        lastX = x; lastY = y
    }

    fun onUp() {
        when (tool) {
            Tool.BRUSH, Tool.ERASER -> finishStroke()
            Tool.FILL -> {
                val t = vm.tool
                val x = lastX.toInt(); val y = lastY.toInt()
                vm.editPixels({ bmp, sel -> PixelOps.floodFill(bmp, x, y, t.color, t.fillOpacity, t.fillTolerance, t.fillContiguous, sel) }, ::refresh)
            }
            Tool.MAGIC_ERASER -> {
                val t = vm.tool
                val x = lastX.toInt(); val y = lastY.toInt()
                vm.editPixels({ bmp, sel -> PixelOps.removeColor(bmp, x, y, t.bgTolerance, t.bgContiguous, sel) }, ::refresh)
            }
            Tool.LINE, Tool.RECT, Tool.ELLIPSE -> {
                draft?.let { commitShape(it) }
                draft = null
            }
            Tool.SELECT_RECT -> {
                val d = draft
                draft = null
                val r = d?.let { ShapeRenderer.normalized(it) }
                vm.selection = if (r != null && r.width() >= 2f && r.height() >= 2f) SelectionOps.rectSelection(r.left, r.top, r.right, r.bottom) else null
            }
            Tool.SELECT_FREE -> {
                vm.selection = if (lasso.size >= 3) SelectionOps.polygonSelection(lasso) else null
                lasso = emptyList()
            }
            Tool.MOVE -> {
                if (layerDrag) vm.endLiveEdit()
                layerDrag = false
            }
            Tool.TEXT -> {
                if (!textMoved && vm.activeLayer?.type == LayerType.TEXT) editingText = true
                if (textDrag) vm.endLiveEdit()
                textDrag = false
            }
            else -> Unit
        }
    }

    /** A second finger arrived: undo whatever this one-finger gesture started. */
    fun onCancel() {
        when (tool) {
            Tool.BRUSH, Tool.ERASER -> {
                val r = stroke?.cancel()
                stroke = null
                snapshot?.recycle(); snapshot = null
                refresh(r)
            }
            Tool.LINE, Tool.RECT, Tool.ELLIPSE, Tool.SELECT_RECT -> draft = null
            Tool.SELECT_FREE -> lasso = emptyList()
            Tool.MOVE -> { layerDrag = false; vm.endLiveEdit() }
            Tool.TEXT -> {
                textDrag = false
                vm.endLiveEdit()
                vm.deleteBlankTextLayer()
            }
            else -> Unit
        }
    }

    // ---------------------------------------------------------------- brush and eraser

    private fun ensureLayer(w: Int, h: Int): Bitmap? {
        strokeLayer?.let { if (it.width == w && it.height == h) return it }
        strokeLayer?.recycle()
        strokeLayer = null
        return try {
            Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888).also { strokeLayer = it }
        } catch (e: OutOfMemoryError) {
            vm.reportMemoryError()
            null
        }
    }

    private fun startStroke(x: Float, y: Float): Boolean {
        val target = vm.paintTarget(true) ?: return false
        val t = vm.tool
        val eraser = tool == Tool.ERASER
        val size = if (eraser) t.eraserSize else t.brushSize
        val opacity = if (eraser) t.eraserOpacity else t.brushOpacity
        val hardness = if (eraser) t.eraserHardness else t.brushHardness
        val snap = vm.beginEdit() ?: return false
        val layer = ensureLayer(target.width, target.height)
        if (layer == null) { snap.recycle(); return false }
        val stamp = try {
            BrushStamp.create(size.roundToInt(), hardness, if (eraser) 0xFF000000.toInt() else t.color)
        } catch (e: OutOfMemoryError) {
            vm.reportMemoryError(); snap.recycle(); return false
        }
        snapshot = snap
        stroke = StrokeRenderer(target, snap, layer, stamp, size, opacity, eraser, vm.selection?.path)
        stroke?.begin(x, y)?.let { refresh(it) }
        return true
    }

    private fun finishStroke() {
        val r = stroke?.end()
        val snap = snapshot
        stroke = null
        snapshot = null
        if (r != null && snap != null) {
            vm.commitEdit(snap)
            refresh(r)
        } else snap?.recycle()
    }

    // ---------------------------------------------------------------- eyedropper, shapes

    private fun pick(bmp: Bitmap, x: Float, y: Float) {
        val px = x.toInt().coerceIn(0, bmp.width - 1)
        val py = y.toInt().coerceIn(0, bmp.height - 1)
        vm.tool.color = bmp.getPixel(px, py) or 0xFF000000.toInt()
    }

    /** Every finished shape becomes its own shape layer. */
    private fun commitShape(d: ShapeDraft) {
        if (hypot(d.x1 - d.x0, d.y1 - d.y0) < 1f) return
        val t = vm.tool
        vm.addShapeLayer(ShapeRenderer.toParams(d, t.color, t.shapeOpacity, t.shapeStroke, t.shapeFilled))
    }

    // ---------------------------------------------------------------- selection actions

    fun selectAll() {
        val s = vm.session ?: return
        finishPending()
        vm.selection = SelectionOps.rectSelection(0f, 0f, s.composite.width.toFloat(), s.composite.height.toFloat())
    }

    fun deselect() { finishPending(); vm.selection = null }

    fun clearSelectionPixels() {
        val sel = vm.selection ?: return
        val target = vm.paintTarget(true) ?: return
        val snap = vm.beginEdit() ?: return
        SelectionOps.clear(target, sel)
        vm.commitEdit(snap)
        refresh(SelectionOps.clippedBounds(sel, target.width, target.height)?.also { it.inset(-2, -2) })
    }

    fun fillSelection() {
        val sel = vm.selection ?: return
        val target = vm.paintTarget(true) ?: return
        val snap = vm.beginEdit() ?: return
        val t = vm.tool
        val color = (t.color and 0x00FFFFFF) or ((t.fillOpacity * 255f).roundToInt().coerceIn(0, 255) shl 24)
        SelectionOps.fill(target, sel, color)
        vm.commitEdit(snap)
        refresh(SelectionOps.clippedBounds(sel, target.width, target.height)?.also { it.inset(-2, -2) })
    }

    fun cropToSelection() {
        val s = vm.session ?: return
        val sel = vm.selection ?: return
        val b = SelectionOps.clippedBounds(sel, s.composite.width, s.composite.height) ?: return
        vm.cropCanvas(b.left, b.top, b.width(), b.height())
    }

    // ---------------------------------------------------------------- move / scale / rotate

    private fun startMove(): Boolean {
        if (floating != null) return true
        val layer = vm.activeLayer ?: return false
        val s = vm.session ?: return false
        if (vm.selection == null) {
            when (layer.type) {
                LayerType.TEXT, LayerType.SHAPE -> {
                    if (layer.locked) { vm.showMessage(R.string.err_layer_locked); return false }
                    layerDrag = true
                    return true
                }
                LayerType.RASTER -> vm.selection = SelectionOps.rectSelection(0f, 0f, s.composite.width.toFloat(), s.composite.height.toFloat())
                LayerType.GROUP -> return false
            }
        }
        val sel = vm.selection ?: return false
        val target = vm.paintTarget(true) ?: return false
        val snap = vm.beginEdit() ?: return false
        val f = SelectionOps.lift(target, sel)
        if (f == null) { snap.recycle(); return false }
        snapshot = snap
        floating = f
        refresh(f.origin)
        return true
    }

    fun applyFloating() {
        val f = floating ?: return
        val target = vm.paintTarget(true) ?: return
        val snap = snapshot
        val r = SelectionOps.drawFloating(target, f)
        r.union(f.origin)
        vm.selection = SelectionOps.floatingSelection(f)
        if (snap != null) vm.commitEdit(snap)
        floating = null
        snapshot = null
        refresh(r)
    }

    fun cancelFloating() {
        if (floating == null) return
        snapshot?.let { vm.restoreFrom(it); it.recycle() }
        floating = null
        snapshot = null
        vm.refresh(null)
    }

    // ---------------------------------------------------------------- text layers

    private fun startText(x: Float, y: Float): Boolean {
        val s = vm.session ?: return false
        textMoved = false
        textDrag = false
        val hit = vm.hitTextLayer(x, y)
        if (hit != null) {
            vm.selectLayer(hit)
            if (vm.activeLayer?.locked == true) { vm.showMessage(R.string.err_layer_locked); return false }
            textDrag = true
            return true
        }
        val size = (min(s.composite.width, s.composite.height) / 10f).coerceIn(24f, 400f)
        vm.addTextLayer(TextParams("", x, y, size, vm.tool.color))
        return true
    }

    /** Called by the text dialog. Empty text removes the layer. */
    fun setText(value: String) {
        editingText = false
        if (value.isBlank()) vm.deleteBlankTextLayerOrClear() else vm.updateActiveText { it.copy(text = value) }
    }

    fun deleteText() {
        editingText = false
        val l = vm.activeLayer ?: return
        if (l.type == LayerType.TEXT) vm.deleteLayer(l.id)
    }

    // ---------------------------------------------------------------- tool switching

    /** Applies anything still floating. Call before switching tools, layers, saving or exporting. */
    fun finishPending() {
        applyFloating()
    }

    fun selectTool(t: Tool) {
        if (t != tool) finishPending()
        vm.activeTool = t
    }

    fun release() {
        strokeLayer?.recycle()
        strokeLayer = null
    }
}
