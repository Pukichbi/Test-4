# Architecture (0.4.0)

```
ui/            Compose screens, sheets, tool options, canvas layers (no document logic)
tools/         ToolController: pointer events -> edits of the active layer
AppViewModel   the document (Session) and every operation on it; autosave; recovery
layers/        Layer, LayerType, Blend, TextParams, ShapeParams, LayerTree (pure list operations)
render/        Compositor (flatten layers), BrushEngine, SelectionOps, PixelOps, text/shape renderers, TilePyramid
data/          ManifestCodec (JSON <-> model, versioned), ProjectArchive (read+validate), SafeWriter (atomic write),
               ProjectStore (library, recovery folder, PNG layer I/O), ImageIO (import/export of pictures)
core/          Pure maths: ViewTransform, TileGrid, FloodFill, limits
```

Data flow of an edit: gesture -> `ToolController` -> bitmap of the active layer (or its mask) -> `vm.refresh(rect)`
recomposes that rectangle of `Session.composite` -> `TilePyramid.invalidate(rect)` -> canvas redraws the tiles.

Files: `filesDir/projects/<id>.nupixel` (+ `.thumb.jpg`), `filesDir/recovery/<id>.nupixel` (autosave copy).
All writes use `SafeWriter`; `ProjectStore` runs `SafeWriter.recover` for both folders at start.

Rules: reading never modifies a file; the document model holds no UI state except `maskEditing`/tool settings in the
ViewModel; every write to the store goes through one `Mutex`.
