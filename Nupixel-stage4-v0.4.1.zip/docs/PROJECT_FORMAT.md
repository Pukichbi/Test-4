# Nupixel project format (`.nupixel`), version 2

A ZIP archive (extension `.nupixel`; files from before 0.4.0 use `.npx` with the same container and are still read).

```
manifest.json            UTF-8 JSON, see below
layers/<id>.png          one PNG per raster layer (ARGB, canvas size)
layers/<id>-mask.png     optional mask: white ARGB PNG, the alpha channel is the mask (255 = visible)
```
Text and shape layers store only parameters; their pixels are redrawn on load. Groups store neither.

```json
{
  "format": "nupixel-project", "formatVersion": 2, "appVersion": "0.4.0", "name": "Poster",
  "canvas": { "width": 1920, "height": 1080, "colorSpace": "sRGB" },
  "createdAt": 1760000000000, "modifiedAt": 1760000000000,
  "activeLayer": "ab12cd34",
  "guides": [ { "o": "v", "p": 960 } ],
  "layers": [
    { "id": "ab12cd34", "name": "Background", "type": "raster", "file": "layers/ab12cd34.png",
      "visible": true, "locked": false, "opacity": 1.0, "blend": "normal",
      "maskFile": "layers/ab12cd34-mask.png", "maskEnabled": true, "parent": "grp1", "expanded": true },
    { "id": "t1", "name": "Text", "type": "text",
      "textParams": { "text": "Hi", "x": 10, "y": 20, "size": 48, "color": -16777216, "bold": false, "italic": false, "font": "sans" } },
    { "id": "s1", "name": "Shape", "type": "shape",
      "shapeParams": { "kind": "rect", "x0": 0, "y0": 0, "x1": 50, "y1": 50, "color": -65536, "stroke": 6, "filled": false, "opacity": 1 } },
    { "id": "grp1", "name": "Group", "type": "group", "opacity": 1.0, "blend": "normal" }
  ]
}
```
Layers are listed bottom to top. `parent` points to a group (one level). `blend`: normal, multiply, screen, overlay,
darken, lighten, add (unknown values are read as normal).

## Reading rules
1. Empty, truncated, non-zip, manifest-less or foreign files give a "damaged file" error.
2. `formatVersion` greater than the app supports gives "created in a newer version"; the file is not interpreted.
3. Older versions are upgraded step by step in memory (`ManifestCodec.migrations`); the file on disk is not changed.
   An upgraded project opens as unsaved; saving writes the current format.
4. Layer ids must match `[A-Za-z0-9_-]{1,64}`; file paths must start with `layers/` and contain no `..`.
5. Every referenced PNG must exist and match the canvas size.

## Versions
| Version | Introduced | Notes |
|---------|-----------|-------|
| 1 | 0.1.0 | one raster layer (`layers/layer-1.png`), guides added in 0.2.0 without a version bump |
| 2 | 0.4.0 | layer properties (locked, blend), masks, groups, text and shape layers, active layer; v1 → v2 sets `locked=false`, `blend=normal` |

## Safe writing
`SafeWriter`: write `<name>.tmp` → flush/sync → verify (`ProjectArchive.isValid`) → move the old file to `<name>.bak` →
move the temp file in → delete `.bak`. Any failure leaves the previous file in place. After a crash `SafeWriter.recover`
restores a lone `.bak` and deletes leftover `.tmp` files. Autosave writes the same format to `recovery/<id>.nupixel`.
